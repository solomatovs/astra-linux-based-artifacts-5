import chainlit as cl


@cl.on_chat_start
async def on_chat_start():
    await cl.Message(content="Window message test ready").send()


@cl.on_window_message
async def window_message(message: str):
    if message.startswith("Client: "):
        await cl.send_window_message("Server: World")


@cl.on_message
async def message(message: str):
    await cl.Message(content="ok").send()
