#!/bin/bash
# added 2021-11-05 by Theo Bertin, released under ASL 2.0

export USE_VALGRIND="YES"
source ${srcdir:-.}/rscript_faup_query_string.sh
