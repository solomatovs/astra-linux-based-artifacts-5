package backup

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"net/url"
	"os"
	"path"
	"regexp"
	"strings"
	"sync"

	"github.com/Altinity/clickhouse-backup/v2/pkg/common"
	"github.com/Altinity/clickhouse-backup/v2/pkg/metadata"
	"github.com/Altinity/clickhouse-backup/v2/pkg/utils"
	"github.com/eapache/go-resiliency/retrier"
	"github.com/pkg/errors"

	"github.com/Altinity/clickhouse-backup/v2/pkg/clickhouse"
	"github.com/Altinity/clickhouse-backup/v2/pkg/config"
	"github.com/Altinity/clickhouse-backup/v2/pkg/resumable"
	"github.com/Altinity/clickhouse-backup/v2/pkg/storage"
	"github.com/rs/zerolog/log"
)

const DirectoryFormat = "directory"

var errShardOperationUnsupported = errors.New("sharded operations are not supported")

// versioner is an interface for determining the version of Clickhouse
type versioner interface {
	CanShardOperation(ctx context.Context) error
}

type BackuperOpt func(*Backuper)

type Backuper struct {
	cfg                    *config.Config
	ch                     *clickhouse.ClickHouse
	vers                   versioner
	bs                     backupSharder
	dst                    *storage.BackupDestination
	DiskToPathMap          map[string]string
	DefaultDataPath        string
	EmbeddedBackupDataPath string
	embeddedClusterPrefix  string // "shards/{shard_num}/replicas/{replica_num}" when UseEmbeddedBackupRestoreCluster is set, otherwise ""
	isEmbedded             bool
	resume                 bool
	resumableState         *resumable.State
	shadowBackupUUIDs      []string
	shadowBackupUUIDsMutex sync.Mutex
	fileManifest           *storage.ManifestWriter
}

func NewBackuper(cfg *config.Config, opts ...BackuperOpt) *Backuper {
	ch := clickhouse.NewClickHouse(&cfg.ClickHouse)
	b := &Backuper{
		cfg:  cfg,
		ch:   ch,
		vers: ch,
		bs:   nil,
	}
	for _, opt := range opts {
		opt(b)
	}
	return b
}

// Classify need to log retries
func (b *Backuper) Classify(err error) retrier.Action {
	if err == nil {
		return retrier.Succeed
	}
	// canceled/expired context can't succeed on retry, fail fast so /backup/kill and SIGTERM unwind promptly
	if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		return retrier.Fail
	}
	log.Warn().Err(err).Msgf("Will wait near %s and retry", common.AddRandomJitter(b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter))
	return retrier.Retry
}

func WithVersioner(v versioner) BackuperOpt {
	return func(b *Backuper) {
		b.vers = v
	}
}

func WithBackupSharder(s backupSharder) BackuperOpt {
	return func(b *Backuper) {
		b.bs = s
	}
}

func (b *Backuper) initDisksPathsAndBackupDestination(ctx context.Context, disks []clickhouse.Disk, backupName string) error {
	var err error
	if disks == nil {
		disks, err = b.ch.GetDisks(ctx, true)
		if err != nil {
			return errors.Wrap(err, "b.ch.GetDisks")
		}
	}
	b.DefaultDataPath, err = b.ch.GetDefaultPath(disks)
	if err != nil {
		return ErrUnknownClickhouseDataPath
	}
	diskMap := map[string]string{}
	for _, disk := range disks {
		diskMap[disk.Name] = disk.Path
		if b.cfg.ClickHouse.UseEmbeddedBackupRestore && (disk.IsBackup || disk.Name == b.cfg.ClickHouse.EmbeddedBackupDisk) {
			b.EmbeddedBackupDataPath = disk.Path
		}
	}
	if b.cfg.ClickHouse.UseEmbeddedBackupRestore && b.EmbeddedBackupDataPath == "" {
		b.EmbeddedBackupDataPath = b.DefaultDataPath
	}
	b.DiskToPathMap = diskMap
	if b.cfg.General.RemoteStorage != "none" && b.cfg.General.RemoteStorage != "custom" {
		if err = b.CalculateMaxSize(ctx); err != nil {
			return errors.Wrap(err, "b.CalculateMaxSize")
		}
		b.dst, err = storage.NewBackupDestination(ctx, b.cfg, b.ch, backupName)
		if err != nil {
			return errors.Wrap(err, "storage.NewBackupDestination")
		}
		if err := b.dst.Connect(ctx); err != nil {
			return errors.Wrapf(err, "can't connect to %s", b.dst.Kind())
		}
	}
	return nil
}

// CalculateMaxSize https://github.com/Altinity/clickhouse-backup/issues/404
func (b *Backuper) CalculateMaxSize(ctx context.Context) error {
	maxFileSize, err := b.ch.CalculateMaxFileSize(ctx, b.cfg)
	if err != nil {
		return errors.Wrap(err, "b.ch.CalculateMaxFileSize")
	}
	if b.cfg.General.MaxFileSize > 0 && b.cfg.General.MaxFileSize < maxFileSize {
		log.Warn().Msgf("MAX_FILE_SIZE=%d is less than actual %d, please remove general->max_file_size section from your config", b.cfg.General.MaxFileSize, maxFileSize)
	}
	if b.cfg.General.MaxFileSize <= 0 || b.cfg.General.MaxFileSize < maxFileSize {
		b.cfg.General.MaxFileSize = maxFileSize
	}
	return nil
}

func (b *Backuper) getLocalBackupDataPathForTable(backupName string, disk string, dbAndTablePath string) string {
	backupPath := path.Join(b.DiskToPathMap[disk], "backup", backupName, "shadow", dbAndTablePath, disk)
	if b.isEmbedded {
		backupPath = path.Join(b.DiskToPathMap[disk], backupName, b.embeddedClusterPrefix, "data", dbAndTablePath)
	}
	return backupPath
}

// resolveEmbeddedClusterShardReplica resolves the shard/replica prefix for embedded backups with ON CLUSTER mode.
// When UseEmbeddedBackupRestoreCluster is set, ClickHouse stores backup content under
// backup_name/shards/{shard_num}/replicas/{replica_num}/ instead of directly under backup_name/.
func (b *Backuper) resolveEmbeddedClusterShardReplica(ctx context.Context) error {
	if b.cfg.ClickHouse.UseEmbeddedBackupRestoreCluster == "" {
		b.embeddedClusterPrefix = ""
		return nil
	}
	clusterName, err := b.ch.ApplyMacros(ctx, b.cfg.ClickHouse.UseEmbeddedBackupRestoreCluster)
	if err != nil {
		return errors.Wrap(err, "ApplyMacros for UseEmbeddedBackupRestoreCluster")
	}
	type clusterReplica struct {
		ShardNum   uint32 `ch:"shard_num"`
		ReplicaNum uint32 `ch:"replica_num"`
	}
	var result []clusterReplica
	query := fmt.Sprintf("SELECT shard_num, replica_num FROM system.clusters WHERE is_local AND cluster='%s' LIMIT 1", clusterName)
	if err := b.ch.SelectContext(ctx, &result, query); err != nil {
		return errors.Wrap(err, "resolve shard_num and replica_num from system.clusters")
	}
	if len(result) == 0 {
		return errors.Errorf("no local replica found in system.clusters for cluster '%s'", clusterName)
	}
	b.embeddedClusterPrefix = path.Join("shards", fmt.Sprintf("%d", result[0].ShardNum), "replicas", fmt.Sprintf("%d", result[0].ReplicaNum))
	log.Debug().Msgf("resolved embedded cluster prefix: %s", b.embeddedClusterPrefix)
	return nil
}

// populateBackupShardField populates the BackupShard field for a slice of Table structs
func (b *Backuper) populateBackupShardField(ctx context.Context, tables []clickhouse.Table) error {
	// By default, have all fields populated to full backup unless the table is to be skipped
	for i := range tables {
		tables[i].BackupType = clickhouse.ShardBackupFull
		if tables[i].Skip {
			tables[i].BackupType = clickhouse.ShardBackupNone
		}
	}
	if !doesShard(b.cfg.General.ShardedOperationMode) {
		return nil
	}
	if err := b.vers.CanShardOperation(ctx); err != nil {
		return errors.Wrap(err, "b.vers.CanShardOperation")
	}

	if b.bs == nil {
		// Parse shard config here to avoid error return in NewBackuper
		shardFunc, err := shardFuncByName(b.cfg.General.ShardedOperationMode)
		if err != nil {
			return errors.Wrap(err, "could not determine shards for tables")
		}
		b.bs = newReplicaDeterminer(b.ch, shardFunc)
	}
	assignment, err := b.bs.determineShards(ctx)
	if err != nil {
		return errors.Wrap(err, "b.bs.determineShards")
	}
	for i, t := range tables {
		if t.Skip {
			continue
		}
		fullBackup, err := assignment.inShard(t.Database, t.Name)
		if err != nil {
			return errors.Wrap(err, "assignment.inShard")
		}
		if !fullBackup {
			tables[i].BackupType = clickhouse.ShardBackupSchema
		}
	}
	return nil
}

func (b *Backuper) isDiskTypeObject(diskType string) bool {
	return diskType == "s3" || diskType == "azure_blob_storage" || diskType == "azure"
}

func (b *Backuper) isDiskTypeEncryptedObject(disk clickhouse.Disk, disks []clickhouse.Disk) bool {
	if disk.Type != "encrypted" {
		return false
	}
	underlyingIdx := -1
	underlyingPath := ""
	for i, d := range disks {
		if d.Name != disk.Name && strings.HasPrefix(disk.Path, d.Path) && b.isDiskTypeObject(d.Type) {
			if d.Path > underlyingPath {
				underlyingIdx = i
				underlyingPath = d.Path
			}
		}
	}
	return underlyingIdx >= 0
}

// checkDisksConsistency verifies clickhouse-backup sees the same local disks as clickhouse-server.
// It guards against silently producing schema-only backups / partial restores (issue #1037) when
// clickhouse.host is remote or the server data volumes are not mounted into the clickhouse-backup
// container. Disk paths already have disk_mapping applied by GetDisks.
func (b *Backuper) checkDisksConsistency(disks []clickhouse.Disk) error {
	var problems []string
	for _, disk := range disks {
		if disk.IsBackup || b.shouldSkipByDiskNameOrType(disk) {
			continue
		}
		st, err := os.Stat(disk.Path)
		if err != nil {
			if os.IsNotExist(err) {
				problems = append(problems, fmt.Sprintf("disk %q (type %q) path %q is not exists locally", disk.Name, disk.Type, disk.Path))
				continue
			}
			return errors.Wrapf(err, "checkDisksConsistency: os.Stat %s", disk.Path)
		}
		if !st.IsDir() {
			problems = append(problems, fmt.Sprintf("disk %q (type %q) path %q is not a directory", disk.Name, disk.Type, disk.Path))
			continue
		}
		// non-local (object storage) and non-default disks: existence of the path is enough.
		// Secondary storage-policy disks legitimately stay empty until parts land on them, so we
		// only require the well-known "default" disk to look like a real ClickHouse disk.
		if disk.Name != "default" {
			continue
		}
		if b.isDiskTypeObject(disk.Type) || b.isDiskTypeEncryptedObject(disk, disks) {
			continue
		}
		if !hasClickHouseDiskMarker(disk.Path) {
			problems = append(problems, fmt.Sprintf("disk %q (type %q) path %q exists but contains none of store/data/metadata", disk.Name, disk.Type, disk.Path))
		}
	}
	if len(problems) > 0 {
		return fmt.Errorf("clickhouse-backup can't access clickhouse-server data disks "+
			"(check clickhouse.host, mount the same volumes, or set clickhouse.disk_mapping / clickhouse.skip_disks): %s",
			strings.Join(problems, "; "))
	}
	return nil
}

// hasClickHouseDiskMarker reports whether diskPath contains a directory created by clickhouse-server
// on any version since 1.1.54394 (data+metadata since 18.x, store since 20.5).
func hasClickHouseDiskMarker(diskPath string) bool {
	for _, marker := range []string{"store", "data", "metadata"} {
		if st, err := os.Stat(path.Join(diskPath, marker)); err == nil && st.IsDir() {
			return true
		}
	}
	return false
}

// getEmbeddedRestoreSettings - different with getEmbeddedBackupSettings, cause https://github.com/ClickHouse/ClickHouse/issues/69053
func (b *Backuper) getEmbeddedRestoreSettings(version int) []string {
	settings := make([]string, 0)
	if (b.cfg.General.RemoteStorage == "s3" || b.cfg.General.RemoteStorage == "gcs") && version >= 23007000 {
		settings = append(settings, "allow_s3_native_copy=1")
		if err := b.ch.Query("SET s3_request_timeout_ms=600000"); err != nil {
			log.Fatal().Stack().Msgf("SET s3_request_timeout_ms=600000 error: %v", err)
		}

	}
	if (b.cfg.General.RemoteStorage == "s3" || b.cfg.General.RemoteStorage == "gcs") && version >= 23011000 {
		if err := b.ch.Query("SET s3_use_adaptive_timeouts=0"); err != nil {
			log.Fatal().Stack().Msgf("SET s3_use_adaptive_timeouts=0 error: %v", err)
		}
	}
	// embedded RESTORE moves data inside ClickHouse, so our io.Reader throttle can't apply.
	// Pass download_max_bytes_per_second as the server-side max_backup_bandwidth query setting via the
	// RESTORE ... SETTINGS clause (see getEmbeddedBackupSettings for why not `SET`).
	// max_backup_bandwidth is honored there since ClickHouse 25.1 (PR #72665).
	// fix https://github.com/Altinity/clickhouse-backup/issues/1377
	if b.cfg.General.DownloadMaxBytesPerSecond > 0 && version >= 25001000 {
		settings = append(settings, fmt.Sprintf("max_backup_bandwidth=%d", b.cfg.General.DownloadMaxBytesPerSecond))
	}
	return settings
}

func (b *Backuper) getEmbeddedBackupSettings(version int) []string {
	settings := make([]string, 0)
	if (b.cfg.General.RemoteStorage == "s3" || b.cfg.General.RemoteStorage == "gcs") && version >= 23007000 {
		settings = append(settings, "allow_s3_native_copy=1")
		if err := b.ch.Query("SET s3_request_timeout_ms=600000"); err != nil {
			log.Fatal().Stack().Msgf("SET s3_request_timeout_ms=600000 error: %v", err)
		}

	}
	if (b.cfg.General.RemoteStorage == "s3" || b.cfg.General.RemoteStorage == "gcs") && version >= 23011000 {
		if err := b.ch.Query("SET s3_use_adaptive_timeouts=0"); err != nil {
			log.Fatal().Stack().Msgf("SET s3_use_adaptive_timeouts=0 error: %v", err)
		}
	}
	if b.cfg.General.RemoteStorage == "azblob" && version >= 24005000 && b.cfg.ClickHouse.EmbeddedBackupDisk == "" {
		settings = append(settings, "allow_azure_native_copy=1")
	}
	// embedded BACKUP moves data inside ClickHouse, so our io.Reader throttle can't apply.
	// Pass upload_max_bytes_per_second as the server-side max_backup_bandwidth query setting via the
	// BACKUP ... SETTINGS clause, NOT via `SET`: our clickhouse-go pool keeps no idle connections
	// (MaxIdleConns=0), so a session-level SET may not reach the BACKUP query's connection. Settings in
	// the BACKUP/RESTORE SETTINGS clause travel with the query and are applied to its context.
	// max_backup_bandwidth is honored there since ClickHouse 25.1 (PR #72665).
	// fix https://github.com/Altinity/clickhouse-backup/issues/1377
	if b.cfg.General.UploadMaxBytesPerSecond > 0 && version >= 25001000 {
		settings = append(settings, fmt.Sprintf("max_backup_bandwidth=%d", b.cfg.General.UploadMaxBytesPerSecond))
	}
	return settings
}

func (b *Backuper) getEmbeddedBackupLocation(ctx context.Context, backupName string) (string, error) {
	if b.cfg.ClickHouse.EmbeddedBackupDisk != "" {
		return fmt.Sprintf("Disk('%s','%s')", b.cfg.ClickHouse.EmbeddedBackupDisk, backupName), nil
	}
	if b.cfg.General.RemoteStorage == "s3" {
		s3Endpoint := b.buildEmbeddedLocationS3(ctx)
		if b.cfg.S3.AccessKey != "" {
			return fmt.Sprintf("S3('%s/%s/','%s','%s')", s3Endpoint, backupName, b.cfg.S3.AccessKey, b.cfg.S3.SecretKey), nil
		}
		if os.Getenv("AWS_ACCESS_KEY_ID") != "" {
			return fmt.Sprintf("S3('%s/%s/','%s','%s')", s3Endpoint, backupName, os.Getenv("AWS_ACCESS_KEY_ID"), os.Getenv("AWS_SECRET_ACCESS_KEY")), nil
		}
		return "", errors.WithStack(errors.New("provide s3->access_key and s3->secret_key in config to allow embedded backup without `clickhouse->embedded_backup_disk`"))
	}
	if b.cfg.General.RemoteStorage == "gcs" {
		gcsEndpoint := b.buildEmbeddedLocationGCS(ctx)
		if b.cfg.GCS.EmbeddedAccessKey != "" {
			return fmt.Sprintf("S3('%s/%s/','%s','%s')", gcsEndpoint, backupName, b.cfg.GCS.EmbeddedAccessKey, b.cfg.GCS.EmbeddedSecretKey), nil
		}
		if os.Getenv("AWS_ACCESS_KEY_ID") != "" {
			return fmt.Sprintf("S3('%s/%s/','%s','%s')", gcsEndpoint, backupName, os.Getenv("AWS_ACCESS_KEY_ID"), os.Getenv("AWS_SECRET_ACCESS_KEY")), nil
		}
		return "", errors.New("provide gcs->embedded_access_key and gcs->embedded_secret_key in config to allow embedded backup without `clickhouse->embedded_backup_disk`")
	}
	if b.cfg.General.RemoteStorage == "azblob" {
		azblobEndpoint := b.buildEmbeddedLocationAZBLOB()
		azblobPath, err := b.ch.ApplyMacros(ctx, b.cfg.AzureBlob.ObjectDiskPath)
		if err != nil {
			return "", errors.Wrap(err, "b.ch.ApplyMacros")
		}
		if b.cfg.AzureBlob.Container != "" {
			return fmt.Sprintf("AzureBlobStorage('%s','%s','%s/%s/')", azblobEndpoint, b.cfg.AzureBlob.Container, azblobPath, backupName), nil
		}
		return "", errors.New("provide azblob->container and azblob->account_name, azblob->account_key in config to allow embedded backup without `clickhouse->embedded_backup_disk`")
	}
	return "", errors.Errorf("empty clickhouse->embedded_backup_disk and invalid general->remote_storage: %s", b.cfg.General.RemoteStorage)
}

func (b *Backuper) buildEmbeddedLocationS3(ctx context.Context) string {
	s3backupURL := url.URL{}
	s3backupURL.Scheme = "https"
	s3Path, err := b.ch.ApplyMacros(ctx, b.cfg.S3.ObjectDiskPath)
	if err != nil {
		log.Error().Stack().Err(err).Send()
		return ""
	}
	if strings.HasPrefix(b.cfg.S3.Endpoint, "http") {
		newUrl, _ := s3backupURL.Parse(b.cfg.S3.Endpoint)
		s3backupURL = *newUrl
		s3backupURL.Path = path.Join(b.cfg.S3.Bucket, s3Path)
	} else {
		s3backupURL.Host = b.cfg.S3.Endpoint
		s3backupURL.Path = path.Join(b.cfg.S3.Bucket, s3Path)
	}
	if b.cfg.S3.DisableSSL {
		s3backupURL.Scheme = "http"
	}
	if s3backupURL.Host == "" && b.cfg.S3.Region != "" && b.cfg.S3.ForcePathStyle {
		s3backupURL.Host = "s3." + b.cfg.S3.Region + ".amazonaws.com"
		s3backupURL.Path = path.Join(b.cfg.S3.Bucket, s3Path)
	}
	if s3backupURL.Host == "" && b.cfg.S3.Bucket != "" && !b.cfg.S3.ForcePathStyle {
		s3backupURL.Host = b.cfg.S3.Bucket + "." + "s3." + b.cfg.S3.Region + ".amazonaws.com"
		s3backupURL.Path = s3Path
	}
	return s3backupURL.String()
}

func (b *Backuper) buildEmbeddedLocationGCS(ctx context.Context) string {
	gcsBackupURL := url.URL{}
	gcsBackupURL.Scheme = "https"
	if b.cfg.GCS.ForceHttp {
		gcsBackupURL.Scheme = "http"
	}
	if b.cfg.GCS.Endpoint != "" {
		if !strings.HasPrefix(b.cfg.GCS.Endpoint, "http") {
			gcsBackupURL.Host = b.cfg.GCS.Endpoint
		} else {
			newUrl, err := gcsBackupURL.Parse(b.cfg.GCS.Endpoint)
			if err != nil {
				log.Error().Err(err).Stack().Send()
				return ""
			}
			gcsBackupURL = *newUrl
		}
	}
	if gcsBackupURL.Host == "" {
		gcsBackupURL.Host = "storage.googleapis.com"
	}
	gcsPath, err := b.ch.ApplyMacros(ctx, b.cfg.GCS.ObjectDiskPath)
	if err != nil {
		log.Error().Err(err).Stack().Send()
		return ""
	}

	gcsBackupURL.Path = path.Join(b.cfg.GCS.Bucket, gcsPath)
	return gcsBackupURL.String()
}

func (b *Backuper) buildEmbeddedLocationAZBLOB() string {
	azblobBackupURL := url.URL{}
	azblobBackupURL.Scheme = b.cfg.AzureBlob.EndpointSchema
	// https://github.com/Altinity/clickhouse-backup/issues/1031
	if b.cfg.AzureBlob.EndpointSuffix == "core.windows.net" {
		azblobBackupURL.Host = b.cfg.AzureBlob.AccountName + ".blob." + b.cfg.AzureBlob.EndpointSuffix
	} else {
		azblobBackupURL.Host = b.cfg.AzureBlob.EndpointSuffix
		azblobBackupURL.Path = b.cfg.AzureBlob.AccountName
	}
	return fmt.Sprintf("DefaultEndpointsProtocol=%s;AccountName=%s;AccountKey=%s;BlobEndpoint=%s;", b.cfg.AzureBlob.EndpointSchema, b.cfg.AzureBlob.AccountName, b.cfg.AzureBlob.AccountKey, azblobBackupURL.String())
}

func (b *Backuper) getBackupPath() (string, error) {
	switch b.cfg.General.RemoteStorage {
	case "s3":
		return b.cfg.S3.Path, nil
	case "azblob":
		return b.cfg.AzureBlob.Path, nil
	case "gcs":
		return b.cfg.GCS.Path, nil
	case "cos":
		return b.cfg.COS.Path, nil
	case "ftp":
		return b.cfg.FTP.Path, nil
	case "sftp":
		return b.cfg.SFTP.Path, nil
	}
	return "", errors.Errorf("getBackupPath: unsupported remote_storage: %s", b.cfg.General.RemoteStorage)
}

func (b *Backuper) getObjectDiskPath() (string, error) {
	if b.cfg.General.RemoteStorage == "s3" {
		return b.cfg.S3.ObjectDiskPath, nil
	} else if b.cfg.General.RemoteStorage == "azblob" {
		return b.cfg.AzureBlob.ObjectDiskPath, nil
	} else if b.cfg.General.RemoteStorage == "gcs" {
		return b.cfg.GCS.ObjectDiskPath, nil
	} else if b.cfg.General.RemoteStorage == "cos" {
		return b.cfg.COS.ObjectDiskPath, nil
	} else if b.cfg.General.RemoteStorage == "ftp" {
		return b.cfg.FTP.ObjectDiskPath, nil
	} else if b.cfg.General.RemoteStorage == "sftp" {
		return b.cfg.SFTP.ObjectDiskPath, nil
	}

	return "", errors.Errorf("cleanBackupObjectDisks: request object disks path but have unsupported remote_storage: %s", b.cfg.General.RemoteStorage)
}

func (b *Backuper) getTablesDiffFromLocal(ctx context.Context, diffFrom string, tablePattern string) (tablesForUploadFromDiff map[metadata.TableTitle]metadata.TableMetadata, err error) {
	tablesForUploadFromDiff = make(map[metadata.TableTitle]metadata.TableMetadata)
	diffFromBackup, err := b.ReadBackupMetadataLocal(ctx, diffFrom)
	if err != nil {
		return nil, errors.Wrap(err, "b.ReadBackupMetadataLocal")
	}
	if len(diffFromBackup.Tables) != 0 {
		metadataPath := path.Join(b.DefaultDataPath, "backup", diffFrom, "metadata")
		// empty partitions, because we don't want filter
		diffTablesList, _, err := b.getTableListByPatternLocal(ctx, metadataPath, tablePattern, false, []string{})
		if err != nil {
			return nil, errors.Wrap(err, "b.getTableListByPatternLocal")
		}
		for _, t := range diffTablesList {
			tablesForUploadFromDiff[metadata.TableTitle{
				Database: t.Database,
				Table:    t.Table,
			}] = *t
		}
	}
	return tablesForUploadFromDiff, nil
}

func (b *Backuper) getTablesDiffFromRemote(ctx context.Context, diffFromRemote string, tablePattern string) (tablesForUploadFromDiff map[metadata.TableTitle]metadata.TableMetadata, err error) {
	tablesForUploadFromDiff = make(map[metadata.TableTitle]metadata.TableMetadata)
	backupList, err := b.dst.BackupList(ctx, true, diffFromRemote)
	if err != nil {
		return nil, errors.Wrap(err, "b.dst.BackupList return error")
	}
	var diffRemoteMetadata *metadata.BackupMetadata
	for _, backup := range backupList {
		if backup.BackupName == diffFromRemote {
			diffRemoteMetadata = &backup.BackupMetadata
			break
		}
	}
	if diffRemoteMetadata == nil {
		return nil, errors.Errorf("%s not found on remote storage", diffFromRemote)
	}

	if len(diffRemoteMetadata.Tables) != 0 {
		diffTablesList, tableListErr := getTableListByPatternRemote(ctx, b, diffRemoteMetadata, tablePattern, false)
		if tableListErr != nil {
			return nil, errors.Wrap(tableListErr, "getTableListByPatternRemote return error")
		}
		for _, t := range diffTablesList {
			tablesForUploadFromDiff[metadata.TableTitle{
				Database: t.Database,
				Table:    t.Table,
			}] = *t
		}
	}
	return tablesForUploadFromDiff, nil
}

func (b *Backuper) GetLocalDataSize(ctx context.Context) (float64, error) {
	localDataSize := float64(0)
	if !b.ch.IsOpen {
		if connectErr := b.ch.Connect(); connectErr != nil {
			return 0, errors.WithStack(connectErr)
		}
		defer b.ch.Close()
	}
	err := b.ch.SelectSingleRow(ctx, &localDataSize, "SELECT value FROM system.asynchronous_metrics WHERE metric='TotalBytesOfMergeTreeTables'")
	return localDataSize, err
}

func (b *Backuper) GetStateDir() string {
	if b.isEmbedded && b.EmbeddedBackupDataPath != "" {
		return b.EmbeddedBackupDataPath
	}
	return b.DefaultDataPath
}

func (b *Backuper) adjustResumeFlag(resume bool) {
	if !resume && b.cfg.General.UseResumableState {
		resume = true
	}
	b.resume = resume
}

func (b *Backuper) addShadowBackupUUID(uuid string) {
	b.shadowBackupUUIDsMutex.Lock()
	b.shadowBackupUUIDs = append(b.shadowBackupUUIDs, uuid)
	b.shadowBackupUUIDsMutex.Unlock()
}

// recordUploadedFile records a single file in the backup manifest (thread-safe).
// remotePath should be the full remote path including the backupName prefix.
func (b *Backuper) recordUploadedFile(backupName, remotePath string) {
	if b.fileManifest == nil {
		return
	}
	b.fileManifest.AddFile(strings.TrimPrefix(remotePath, backupName+"/"))
}

// recordUploadedFiles records multiple files in the backup manifest (thread-safe).
// remotePath is the remote directory (including backupName prefix), files are
// relative to it.
func (b *Backuper) recordUploadedFiles(backupName, remotePath string, files []string) {
	if b.fileManifest == nil {
		return
	}
	for _, f := range files {
		b.fileManifest.AddFile(strings.TrimPrefix(path.Join(remotePath, f), backupName+"/"))
	}
}

// CheckDisksUsage - https://github.com/Altinity/clickhouse-backup/issues/878
func (b *Backuper) CheckDisksUsage(backup storage.Backup, disks []clickhouse.Disk, isResumeExists bool, tablePattern string) error {
	if tablePattern != "" && tablePattern != "*.*" && tablePattern != "*" {
		return nil
	}
	freeSize := uint64(0)
	for _, d := range disks {
		freeSize += d.FreeSpace
	}
	if freeSize <= backup.CompressedSize || freeSize <= backup.DataSize {
		errMsg := fmt.Sprintf("%s requires %s free space, but total free space is %s", backup.BackupName, utils.FormatBytes(max(backup.CompressedSize, backup.DataSize)), utils.FormatBytes(freeSize))
		if !isResumeExists {
			return errors.New(errMsg)
		}
		log.Warn().Msg(errMsg)
	}
	return nil
}

// filterPartsAndFilesByDisk - https://github.com/Altinity/clickhouse-backup/issues/908
func (b *Backuper) filterPartsAndFilesByDisk(tables ListOfTables, disks []clickhouse.Disk) {
	for i, table := range tables {
		//skipped table
		if table == nil {
			continue
		}
		filteredParts := make(map[string][]metadata.Part)
		for diskName := range tables[i].Parts {
			if b.shouldDiskNameSkipByNameOrType(diskName, disks) {
				log.Warn().Str("database", table.Database).Str("table", table.Table).Str("disk.Name", diskName).Msg("skipped")
				continue
			}
			filteredParts[diskName] = tables[i].Parts[diskName]
		}
		tables[i].Parts = filteredParts

		filteredFiles := make(map[string][]string)
		for diskName := range tables[i].Files {
			if b.shouldDiskNameSkipByNameOrType(diskName, disks) {
				log.Warn().Str("database", table.Database).Str("table", table.Table).Str("disk.Name", diskName).Msg("skipped")
				continue
			}
			filteredFiles[diskName] = tables[i].Files[diskName]
		}
		tables[i].Files = filteredFiles
	}
}

// filterEmptyTables - https://github.com/Altinity/clickhouse-backup/issues/1265
func (b *Backuper) filterEmptyTables(tables ListOfTables) ListOfTables {
	filteredTables := make(ListOfTables, 0, len(tables))
	for _, table := range tables {
		if table == nil {
			continue
		}
		// Check if table has any parts or files (data)
		hasParts := false
		for _, parts := range table.Parts {
			if len(parts) > 0 {
				hasParts = true
				break
			}
		}
		hasFiles := false
		for _, files := range table.Files {
			if len(files) > 0 {
				hasFiles = true
				break
			}
		}
		if hasParts || hasFiles {
			filteredTables = append(filteredTables, table)
		} else {
			log.Info().Str("database", table.Database).Str("table", table.Table).Msg("skipped empty table with --skip-empty-tables")
		}
	}
	return filteredTables
}

// filterTablesWithoutPartitions - filter out tables that don't have any matching partitions
// https://github.com/Altinity/clickhouse-backup/issues/1265
func (b *Backuper) filterTablesWithoutPartitions(tables ListOfTables, partitionsNames map[metadata.TableTitle][]string) ListOfTables {
	filteredTables := make(ListOfTables, 0, len(tables))
	for _, table := range tables {
		if table == nil {
			continue
		}
		tableTitle := metadata.TableTitle{Database: table.Database, Table: table.Table}
		if partitions, exists := partitionsNames[tableTitle]; exists && len(partitions) > 0 {
			filteredTables = append(filteredTables, table)
		} else {
			log.Info().Str("database", table.Database).Str("table", table.Table).Msg("skipped table without matching partitions")
		}
	}
	return filteredTables
}

// https://github.com/Altinity/clickhouse-backup/issues/1127
var dbEngineRE = regexp.MustCompile(`(?m)ENGINE\s*=\s*(\w+\([^)]*\))`)

func (b *Backuper) prepareDatabaseEnginesMap(databases []metadata.DatabasesMeta) map[string]string {
	databaseEngines := make(map[string]string)
	for _, database := range databases {
		engine := database.Engine
		// old clickhouse versions doesn't contain engine_full
		if matches := dbEngineRE.FindAllStringSubmatch(database.Query, 1); matches != nil && len(matches) > 0 {
			engine = matches[0][1]
		}
		// https://github.com/Altinity/clickhouse-backup/issues/1146
		if targetDB, isMapped := b.cfg.General.RestoreDatabaseMapping[database.Name]; isMapped {
			databaseEngines[targetDB] = engine
		}
		databaseEngines[database.Name] = engine
	}
	return databaseEngines
}

func (b *Backuper) calculateChecksum(disk *clickhouse.Disk, partName string) (uint64, error) {
	checksumsFilePath := path.Join(disk.Path, partName, "checksums.txt")
	content, err := os.ReadFile(checksumsFilePath)
	if err != nil {
		return 0, errors.Wrapf(err, "could not read %s", checksumsFilePath)
	}

	hash := sha256.Sum256(content)
	return binary.LittleEndian.Uint64(hash[:8]), nil
}
