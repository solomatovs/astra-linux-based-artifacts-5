package backup

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/sync/errgroup"

	"github.com/Altinity/clickhouse-backup/v2/pkg/clickhouse"
	"github.com/Altinity/clickhouse-backup/v2/pkg/common"
	"github.com/Altinity/clickhouse-backup/v2/pkg/config"
	"github.com/Altinity/clickhouse-backup/v2/pkg/custom"
	"github.com/Altinity/clickhouse-backup/v2/pkg/filesystemhelper"
	"github.com/Altinity/clickhouse-backup/v2/pkg/metadata"
	"github.com/Altinity/clickhouse-backup/v2/pkg/partition"
	"github.com/Altinity/clickhouse-backup/v2/pkg/pidlock"
	"github.com/Altinity/clickhouse-backup/v2/pkg/resumable"
	"github.com/Altinity/clickhouse-backup/v2/pkg/status"
	"github.com/Altinity/clickhouse-backup/v2/pkg/storage"
	"github.com/Altinity/clickhouse-backup/v2/pkg/utils"
	"github.com/eapache/go-resiliency/retrier"
	"github.com/pkg/errors"
	"github.com/rs/zerolog"

	"github.com/rs/zerolog/log"
)

var (
	ErrBackupIsAlreadyExists = errors.New("backup is already exists")
)

func (b *Backuper) resumeExistingBackup(backupName string) error {
	_, checkDownloadErr := os.Stat(path.Join(b.DefaultDataPath, "backup", backupName, "download.state2"))
	if errors.Is(checkDownloadErr, os.ErrNotExist) {
		// wrap ErrBackupIsAlreadyExists so RestoreFromRemote keeps reusing an already complete local backup (issue #625),
		// while a standalone `download --resume` surfaces the guidance below instead of a bare "backup is already exists"
		return fmt.Errorf("%w: local backup '%s' exists but resumable state 'download.state2' is missing, so it is unknown which parts are complete and resuming on top of partial data risks silent corruption; run `clickhouse-backup delete local %s` and retry the download, or investigate why the resumable state was lost", ErrBackupIsAlreadyExists, backupName, backupName)
	}
	log.Warn().Msgf("%s already exists will try to resume download", backupName)
	return nil
}

func isRemoteMetadataNotFound(err error) bool {
	if err == nil {
		return false
	}
	message := strings.ToLower(err.Error())
	// Every remote storage backend phrases "object is missing" differently, so we
	// match the known permanent-not-found markers across S3/GCS/Azure/FTP/SFTP/FS.
	for _, marker := range []string{
		"doesn't exist",             // GCS
		"does not exist",            // SFTP ("file does not exist"), Azure ("the specified blob does not exist")
		"no such file or directory", // FTP (550), local filesystem
		"key not found",
		"nosuchkey",      // S3
		"blobnotfound",   // Azure Blob (x-ms-error-code)
		"statuscode 404", // S3 SDK v2
		"statuscode: 404",
		"status: 404", // Azure ("RESPONSE Status: 404")
	} {
		if strings.Contains(message, marker) {
			return true
		}
	}
	return false
}

func (b *Backuper) Download(backupName string, tablePattern string, partitions []string, schemaOnly, rbacOnly, configsOnly, namedCollectionsOnly, resume bool, hardlinkExistsFiles bool, backupVersion string, commandId int) error {
	if pidCheckErr := pidlock.CheckAndCreatePidFile(backupName, "download"); pidCheckErr != nil {
		return errors.Wrap(pidCheckErr, "CheckAndCreatePidFile")
	}
	defer pidlock.RemovePidFile(backupName)

	ctx, cancel, err := status.Current.GetContextWithCancel(commandId)
	if err != nil {
		return errors.Wrap(err, "GetContextWithCancel")
	}
	defer cancel()
	backupName = utils.CleanBackupNameRE.ReplaceAllString(backupName, "")

	if err := b.ch.Connect(); err != nil {
		return errors.Wrap(err, "can't connect to clickhouse")
	}
	defer b.ch.Close()

	if b.cfg.General.RemoteStorage == "none" {
		return errors.New("general->remote_storage shall not be \"none\" for download, change you config or use REMOTE_STORAGE environment variable")
	}
	if b.cfg.General.DownloadConcurrency == 0 {
		return errors.New("`download_concurrency` shall be more than zero")
	}
	b.adjustResumeFlag(resume)

	if backupName == "" {
		remoteBackups := b.CollectRemoteBackups(ctx, "all")
		_ = b.PrintBackup(remoteBackups, "text")
		return errors.New("select backup for download")
	}
	localBackups, disks, err := b.GetLocalBackups(ctx, nil)
	if err != nil {
		return errors.Wrap(err, "GetLocalBackups")
	}
	b.DefaultDataPath, err = b.ch.GetDefaultPath(disks)
	if err != nil {
		return errors.Wrap(err, "GetDefaultPath")
	}
	isResumeExists := false
	for i := range localBackups {
		if backupName == localBackups[i].BackupName {
			if strings.Contains(localBackups[i].Tags, "embedded") || b.cfg.General.RemoteStorage == "custom" {
				return ErrBackupIsAlreadyExists
			}
			if !b.resume {
				return ErrBackupIsAlreadyExists
			}
			if resumeErr := b.resumeExistingBackup(backupName); resumeErr != nil {
				return resumeErr
			}
			isResumeExists = true
		}
	}
	startDownload := time.Now()
	if b.cfg.General.RemoteStorage == "custom" {
		return custom.Download(ctx, b, b.cfg, backupName, tablePattern, partitions, schemaOnly)
	}
	if err := b.initDisksPathsAndBackupDestination(ctx, disks, ""); err != nil {
		return errors.Wrap(err, "initDisksPathsAndBackupDestination")
	}
	if !schemaOnly && !rbacOnly && !configsOnly && !namedCollectionsOnly {
		if err := b.checkDisksConsistency(disks); err != nil {
			return err
		}
	}
	defer func() {
		if err := b.dst.Close(ctx); err != nil {
			log.Warn().Msgf("can't close BackupDestination error: %v", err)
		}
	}()

	remoteBackups, err := b.dst.BackupList(ctx, true, backupName)
	if err != nil {
		return errors.Wrap(err, "BackupList")
	}
	found := false
	var remoteBackup storage.Backup
	for _, r := range remoteBackups {
		if backupName == r.BackupName {
			remoteBackup = r
			found = true
			break
		}
	}
	if !found {
		return errors.Errorf("'%s' is not found on remote storage", backupName)
	}
	// Download file manifest for Walk-free restore (falls back gracefully if not present)
	backupManifest := b.dst.DownloadManifest(ctx, backupName)
	defer backupManifest.Close()

	if len(remoteBackup.Tables) == 0 && remoteBackup.RBACSize == 0 && remoteBackup.ConfigSize == 0 && remoteBackup.NamedCollectionsSize == 0 && !b.cfg.General.AllowEmptyBackups {
		return errors.Errorf("'%s' is empty backup", backupName)
	}
	// if using hardlink then disable this check, if not use then check disk size
	if !hardlinkExistsFiles && !schemaOnly && !rbacOnly && !configsOnly {
		// https://github.com/Altinity/clickhouse-backup/issues/878
		if freeSizeErr := b.CheckDisksUsage(remoteBackup, disks, isResumeExists, tablePattern); freeSizeErr != nil {
			return errors.Wrap(freeSizeErr, "CheckDisksUsage")
		}
	}
	tablesForDownload := parseTablePatternForDownload(remoteBackup.Tables, tablePattern)

	if !schemaOnly && !b.cfg.General.DownloadByPart && remoteBackup.RequiredBackup != "" {
		// The recursive Download reuses this *Backuper and its initDisksPathsAndBackupDestination
		// overwrites b.dst, then closes it via the child's deferred Close on return. Save and
		// restore our own BackupDestination so the parent keeps using its still-open b.dst for
		// the rest of the download, otherwise GCS/FTP/SFTP fail with use-after-close while
		// S3/Azure only mask it because their Close is a no-op. See issue #1384.
		parentDst := b.dst
		err := b.Download(remoteBackup.RequiredBackup, tablePattern, partitions, schemaOnly, rbacOnly, configsOnly, namedCollectionsOnly, b.resume, hardlinkExistsFiles, backupVersion, commandId)
		b.dst = parentDst
		if err != nil && !errors.Is(err, ErrBackupIsAlreadyExists) {
			return errors.Wrap(err, "download RequiredBackup")
		}
	}

	dataSize := uint64(0)
	metadataSize := uint64(0)
	b.isEmbedded = strings.Contains(remoteBackup.Tags, "embedded")
	if b.isEmbedded {
		if err = b.resolveEmbeddedClusterShardReplica(ctx); err != nil {
			return errors.Wrap(err, "resolveEmbeddedClusterShardReplica")
		}
	}
	localBackupDir := path.Join(b.DefaultDataPath, "backup", backupName)
	if b.isEmbedded {
		// will ignore partitions cause can't manipulate .backup
		partitions = make([]string, 0)
		localBackupDir = path.Join(b.EmbeddedBackupDataPath, backupName)
	}
	err = os.MkdirAll(localBackupDir, 0750)
	if err != nil && !resume {
		return errors.Wrap(err, "MkdirAll localBackupDir")
	}
	if b.resume {
		b.resumableState = resumable.NewState(b.GetStateDir(), backupName, "download", map[string]interface{}{
			"tablePattern": tablePattern,
			"partitions":   partitions,
			"schemaOnly":   schemaOnly,
		})
		defer b.resumableState.Close()
	}

	log.Debug().Str("backup", backupName).Msgf("prepare table METADATA concurrent semaphore with concurrency=%d len(tablesForDownload)=%d", b.cfg.General.DownloadConcurrency, len(tablesForDownload))
	tableMetadataAfterDownload := make(ListOfTables, len(tablesForDownload))
	doDownloadData := !schemaOnly && !rbacOnly && !configsOnly && !namedCollectionsOnly
	if doDownloadData || schemaOnly {
		metadataGroup, metadataCtx := errgroup.WithContext(ctx)
		metadataGroup.SetLimit(int(b.cfg.General.DownloadConcurrency))
		for i, t := range tablesForDownload {
			metadataLogger := log.With().Str("table_metadata", fmt.Sprintf("%s.%s", t.Database, t.Table)).Logger()
			idx := i
			tableTitle := t
			metadataGroup.Go(func() error {
				downloadedMetadata, size, downloadMetadataErr := b.downloadTableMetadata(metadataCtx, backupName, disks, tableTitle, schemaOnly, partitions, b.resume, metadataLogger)
				if downloadMetadataErr != nil {
					return errors.Wrap(downloadMetadataErr, "downloadTableMetadata")
				}
				tableMetadataAfterDownload[idx] = downloadedMetadata
				atomic.AddUint64(&metadataSize, size)
				return nil
			})
		}
		if err := metadataGroup.Wait(); err != nil {
			return errors.Wrap(err, "one of Download Metadata go-routine return error")
		}
	}
	// download, missed .inner. tables, https://github.com/Altinity/clickhouse-backup/issues/765
	var missedInnerTableErr error
	tableMetadataAfterDownload, tablesForDownload, metadataSize, missedInnerTableErr = b.downloadMissedInnerTablesMetadata(ctx, backupName, metadataSize, tablesForDownload, tableMetadataAfterDownload, disks, schemaOnly, partitions)
	if missedInnerTableErr != nil {
		return errors.Wrap(missedInnerTableErr, "b.downloadMissedInnerTablesMetadata error")
	}

	if doDownloadData {
		if reBalanceErr := b.reBalanceTablesMetadataIfDiskNotExists(tableMetadataAfterDownload, disks, remoteBackup); reBalanceErr != nil {
			return errors.Wrap(reBalanceErr, "reBalanceTablesMetadataIfDiskNotExists")
		}
		b.filterPartsAndFilesByDisk(tableMetadataAfterDownload, disks)
		// https://github.com/Altinity/clickhouse-backup/issues/1268
		// precise check after table metadata is downloaded and filtered by --tables and --partitions,
		// counts only parts which really will be downloaded (hardlinkable parts are free)
		if !b.isEmbedded {
			if freeSpaceErr := b.checkFreeSpaceForDownload(ctx, remoteBackup, tableMetadataAfterDownload, disks, hardlinkExistsFiles, isResumeExists); freeSpaceErr != nil {
				return errors.Wrap(freeSpaceErr, "checkFreeSpaceForDownload")
			}
		}
		log.Debug().Str("backupName", backupName).Msgf("prepare table DATA concurrent semaphore with concurrency=%d len(tableMetadataAfterDownload)=%d", b.cfg.General.DownloadConcurrency, len(tableMetadataAfterDownload))
		dataGroup, dataCtx := errgroup.WithContext(ctx)
		dataGroup.SetLimit(int(b.cfg.General.DownloadConcurrency))

		for i, tableMetadata := range tableMetadataAfterDownload {
			if tableMetadata == nil || tableMetadata.MetadataOnly {
				continue
			}
			idx := i
			dataGroup.Go(func() error {
				start := time.Now()
				log.Info().Fields(map[string]interface{}{
					"backup_name": backupName,
					"table":       fmt.Sprintf("%s.%s", tableMetadataAfterDownload[idx].Database, tableMetadataAfterDownload[idx].Table),
					"progress":    fmt.Sprintf("%d/%d", idx+1, len(tableMetadataAfterDownload)),
					"version":     backupVersion,
				}).Msg("download table start")
				var downloadDataErr error
				var downloadDataSize uint64
				downloadDataSize, downloadDataErr = b.downloadTableData(dataCtx, remoteBackup.BackupMetadata, *tableMetadataAfterDownload[idx], disks, hardlinkExistsFiles, backupManifest)
				if downloadDataErr != nil {
					return errors.Wrap(downloadDataErr, "downloadTableData")
				}
				atomic.AddUint64(&dataSize, downloadDataSize)
				tableMetadataAfterDownload[idx].TotalBytes = downloadDataSize
				log.Info().Fields(map[string]interface{}{
					"backup_name": backupName,
					"table":       fmt.Sprintf("%s.%s", tableMetadataAfterDownload[idx].Database, tableMetadataAfterDownload[idx].Table),
					"progress":    fmt.Sprintf("%d/%d", idx+1, len(tableMetadataAfterDownload)),
					"duration":    utils.HumanizeDuration(time.Since(start)),
					"size":        utils.FormatBytes(tableMetadataAfterDownload[idx].TotalBytes),
					"version":     backupVersion,
				}).Msg("download table finish")
				return nil
			})
		}
		if err := dataGroup.Wait(); err != nil {
			return errors.Wrap(err, "one of Download go-routine return error")
		}
	}
	var rbacSize, configSize, namedCollectionsSize uint64
	if rbacOnly || rbacOnly == configsOnly == namedCollectionsOnly == false {
		rbacSize, err = b.downloadRBACData(ctx, remoteBackup)
		if err != nil {
			return errors.Wrap(err, "download RBAC error")
		}
	}

	if configsOnly || rbacOnly == configsOnly == namedCollectionsOnly == false {
		configSize, err = b.downloadConfigData(ctx, remoteBackup)
		if err != nil {
			return errors.Wrap(err, "download CONFIGS error")
		}
	}

	if namedCollectionsOnly || rbacOnly == configsOnly == namedCollectionsOnly == false {
		namedCollectionsSize, err = b.downloadNamedCollectionsData(ctx, remoteBackup)
		if err != nil {
			return errors.Wrap(err, "download NAMED COLLECTIONS error")
		}
	}

	backupMetadata := remoteBackup.BackupMetadata
	backupMetadata.Tables = tablesForDownload

	if doDownloadData && b.isEmbedded && b.cfg.ClickHouse.EmbeddedBackupDisk != "" && backupMetadata.Tables != nil && len(backupMetadata.Tables) > 0 {
		localClickHouseBackupFile := path.Join(b.EmbeddedBackupDataPath, backupName, ".backup")
		remoteClickHouseBackupFile := path.Join(backupName, ".backup")
		localEmbeddedMetadataSize := int64(0)
		if localEmbeddedMetadataSize, err = b.downloadSingleBackupFile(ctx, remoteClickHouseBackupFile, localClickHouseBackupFile, disks); err != nil {
			return errors.Wrap(err, "downloadSingleBackupFile for embedded backup")
		}
		metadataSize += uint64(localEmbeddedMetadataSize)
	}

	backupMetadata.CompressedSize = 0
	backupMetadata.DataFormat = ""
	backupMetadata.DataSize = dataSize
	backupMetadata.MetadataSize = metadataSize
	backupMetadata.ConfigSize = configSize
	backupMetadata.RBACSize = rbacSize
	backupMetadata.ClickhouseBackupVersion = backupVersion
	backupMetafileLocalPath := path.Join(b.DefaultDataPath, "backup", backupName, "metadata.json")
	if b.isEmbedded && b.cfg.ClickHouse.EmbeddedBackupDisk != "" {
		backupMetafileLocalPath = path.Join(b.EmbeddedBackupDataPath, backupName, "metadata.json")
	}
	if err := backupMetadata.Save(backupMetafileLocalPath); err != nil {
		return errors.Wrap(err, "save backup metadata")
	}
	for _, disk := range disks {
		if disk.IsBackup {
			if err = filesystemhelper.Chown(path.Join(disk.Path, backupName), b.ch, disks, true); err != nil {
				return errors.Wrap(err, "Chown backup disk")
			}
		}
	}

	//clean partially downloaded requiredBackup
	if remoteBackup.RequiredBackup != "" {
		if err = b.cleanPartialRequiredBackup(ctx, disks, remoteBackup.BackupName); err != nil {
			return errors.Wrap(err, "cleanPartialRequiredBackup")
		}
	}

	log.Info().Fields(map[string]interface{}{
		"backup":           backupName,
		"operation":        "download",
		"duration":         utils.HumanizeDuration(time.Since(startDownload)),
		"download_size":    utils.FormatBytes(dataSize + metadataSize + rbacSize + configSize + namedCollectionsSize),
		"object_disk_size": utils.FormatBytes(backupMetadata.ObjectDiskSize),
		"version":          backupVersion,
	}).Msg("done")

	return nil
}

func (b *Backuper) reBalanceTablesMetadataIfDiskNotExists(tableMetadataAfterDownload ListOfTables, disks []clickhouse.Disk, remoteBackup storage.Backup) error {
	var disksByStoragePolicyAndType map[string]map[string][]clickhouse.Disk
	filterDisksByTypeAndStoragePolicies := func(disk string, diskType string, disks []clickhouse.Disk, remoteBackup storage.Backup, t metadata.TableMetadata) (string, []clickhouse.Disk, error) {
		_, ok := remoteBackup.DiskTypes[disk]
		if !ok {
			return "", nil, errors.Errorf("disk: %s not found in disk_types section %#v in %s/metadata.json", disk, remoteBackup.DiskTypes, remoteBackup.BackupName)
		}
		storagePolicy := b.ch.ExtractStoragePolicy(t.Query)
		if len(disksByStoragePolicyAndType) == 0 {
			disksByStoragePolicyAndType = b.splitDisksByTypeAndStoragePolicy(disks)
		}
		if _, isTypeExists := disksByStoragePolicyAndType[diskType]; !isTypeExists {
			return "", nil, errors.Errorf("disk: %s, diskType: %s not found in system.disks", disk, diskType)
		}
		filteredDisks, isPolicyExists := disksByStoragePolicyAndType[diskType][storagePolicy]
		if !isPolicyExists || len(filteredDisks) == 0 {
			return "", nil, errors.Errorf("storagePolicy: %s with diskType: %s not found in system.disks", storagePolicy, diskType)
		}
		return storagePolicy, filteredDisks, nil
	}

	updateDiskFreeSize := func(downloadDisk, diskType, storagePolicy string, newFreeSpace uint64) {
		for dIdx := range disksByStoragePolicyAndType[diskType][storagePolicy] {
			if disksByStoragePolicyAndType[diskType][storagePolicy][dIdx].Name == downloadDisk {
				disksByStoragePolicyAndType[diskType][storagePolicy][dIdx].FreeSpace = newFreeSpace
			}
		}
	}

	for i, t := range tableMetadataAfterDownload {
		if t == nil || t.TotalBytes == 0 {
			continue
		}
		isRebalanced := false
		totalFiles := 0
		for disk := range t.Files {
			totalFiles += len(t.Files[disk])
		}
		totalParts := 0
		for disk := range t.Parts {
			totalParts += len(t.Parts[disk])
		}
		if totalFiles == 0 && totalParts == 0 {
			continue
		}
		partSize := t.TotalBytes / uint64(totalParts)
		//re-balance parts
		for disk := range t.Parts {
			// force_rebalance allows rebalancing even when the disk exists (e.g. "default"),
			// enabling distribution across JBOD disks under the same storage policy
			if _, diskExists := b.DiskToPathMap[disk]; (!diskExists || b.cfg.ClickHouse.ForceRebalance) && disk != b.cfg.ClickHouse.EmbeddedBackupDisk {
				diskType := remoteBackup.DiskTypes[disk]
				storagePolicy, filteredDisks, err := filterDisksByTypeAndStoragePolicies(disk, diskType, disks, remoteBackup, *t)
				if err != nil {
					return errors.Wrap(err, "filterDisksByTypeAndStoragePolicies")
				}
				rebalancedDisks := common.EmptyMap{}
				for j := range t.Parts[disk] {
					// When resuming, keep the RebalancedDisk from the previous run
					// to avoid mismatch between metadata and already-downloaded files
					if t.Parts[disk][j].RebalancedDisk != "" {
						existingDisk := t.Parts[disk][j].RebalancedDisk
						rebalancedDisks[existingDisk] = struct{}{}
						isRebalanced = true
						// Rebuild RebalancedFiles map for already-rebalanced parts
						if t.Files != nil && len(t.Files[disk]) > 0 {
							for _, fileName := range t.Files[disk] {
								if strings.HasPrefix(fileName, disk+"_"+t.Parts[disk][j].Name+".") {
									if tableMetadataAfterDownload[i].RebalancedFiles == nil {
										tableMetadataAfterDownload[i].RebalancedFiles = map[string]string{}
									}
									tableMetadataAfterDownload[i].RebalancedFiles[fileName] = existingDisk
								}
							}
						}
						continue
					}
					isObjectDisk, downloadDisk, newFreeSpace, reBalanceErr := b.getDownloadDiskForNonExistsDisk(diskType, filteredDisks, partSize)
					if reBalanceErr != nil {
						return errors.Wrap(reBalanceErr, "getDownloadDiskForNonExistsDisk")
					}
					rebalancedDisks[downloadDisk] = struct{}{}
					tableMetadataAfterDownload[i].Parts[disk][j].RebalancedDisk = downloadDisk
					isRebalanced = true
					if !isObjectDisk {
						updateDiskFreeSize(downloadDisk, diskType, storagePolicy, newFreeSpace)
					}
					//re-balance file depend on part
					if t.Files != nil && len(t.Files) > 0 {
						if len(t.Files[disk]) == 0 {
							return errors.Errorf("table: `%s`.`%s` part.Name: %s, part.RebalancedDisk: %s, non empty `files` can't find disk: %s", t.Table, t.Database, t.Parts[disk][j].Name, t.Parts[disk][j].RebalancedDisk, disk)
						}
						for _, fileName := range t.Files[disk] {
							if strings.HasPrefix(fileName, disk+"_"+t.Parts[disk][j].Name+".") {
								if tableMetadataAfterDownload[i].RebalancedFiles == nil {
									tableMetadataAfterDownload[i].RebalancedFiles = map[string]string{}
								}
								tableMetadataAfterDownload[i].RebalancedFiles[fileName] = downloadDisk
							}
						}
					}
				}
				rebalancedDisksStr := strings.TrimPrefix(
					strings.Replace(fmt.Sprintf("%v", rebalancedDisks), ":{}", "", -1), "map",
				)
				log.Warn().Msgf("table '%s.%s' require disk '%s' that not found in system.disks, you can add nonexistent disks to `disk_mapping` in `clickhouse` config section, data will download to %v", t.Database, t.Table, disk, rebalancedDisksStr)
			}
		}
		if isRebalanced {
			if _, saveErr := t.Save(t.LocalFile, false); saveErr != nil {
				return errors.Wrap(saveErr, "save rebalanced table metadata")
			}
		}
	}

	return nil
}

func (b *Backuper) downloadTableMetadataIfNotExists(ctx context.Context, backupName string, tableTitle metadata.TableTitle) (*metadata.TableMetadata, error) {
	metadataLocalFile := path.Join(b.DefaultDataPath, "backup", backupName, "metadata", common.TablePathEncode(tableTitle.Database), fmt.Sprintf("%s.json", common.TablePathEncode(tableTitle.Table)))
	tm := &metadata.TableMetadata{}
	if _, err := tm.Load(metadataLocalFile); err == nil {
		return tm, nil
	}
	// we always download full metadata in this case without filter by partitions
	logger := log.With().Fields(map[string]interface{}{"operation": "downloadTableMetadataIfNotExists", "backupName": backupName, "table_metadata_diff": fmt.Sprintf("%s.%s", tableTitle.Database, tableTitle.Table)}).Logger()
	tm, _, err := b.downloadTableMetadata(ctx, backupName, nil, tableTitle, false, nil, false, logger)
	return tm, err
}

func (b *Backuper) downloadTableMetadata(ctx context.Context, backupName string, disks []clickhouse.Disk, tableTitle metadata.TableTitle, schemaOnly bool, partitions []string, resume bool, logger zerolog.Logger) (*metadata.TableMetadata, uint64, error) {
	start := time.Now()
	size := uint64(0)
	metadataFiles := map[string]string{}
	remoteMedataPrefix := path.Join(backupName, "metadata", common.TablePathEncode(tableTitle.Database), common.TablePathEncode(tableTitle.Table))
	metadataFiles[fmt.Sprintf("%s.json", remoteMedataPrefix)] = path.Join(b.DefaultDataPath, "backup", backupName, "metadata", common.TablePathEncode(tableTitle.Database), fmt.Sprintf("%s.json", common.TablePathEncode(tableTitle.Table)))
	partitionsIdMap := make(map[metadata.TableTitle]common.EmptyMap)
	if b.isEmbedded && b.cfg.ClickHouse.EmbeddedBackupDisk != "" {
		remoteSqlPrefix := path.Join(backupName, b.embeddedClusterPrefix, "metadata", common.TablePathEncode(tableTitle.Database), common.TablePathEncode(tableTitle.Table))
		metadataFiles[fmt.Sprintf("%s.sql", remoteSqlPrefix)] = path.Join(b.EmbeddedBackupDataPath, backupName, b.embeddedClusterPrefix, "metadata", common.TablePathEncode(tableTitle.Database), fmt.Sprintf("%s.sql", common.TablePathEncode(tableTitle.Table)))
		metadataFiles[fmt.Sprintf("%s.json", remoteMedataPrefix)] = path.Join(b.EmbeddedBackupDataPath, backupName, "metadata", common.TablePathEncode(tableTitle.Database), fmt.Sprintf("%s.json", common.TablePathEncode(tableTitle.Table)))
	}
	var tableMetadata metadata.TableMetadata
	for remoteMetadataFile, localMetadataFile := range metadataFiles {
		if resume {
			isProcessed, processedSize, resumeErr := b.resumableState.IsAlreadyProcessed(localMetadataFile)
			if resumeErr != nil {
				return nil, 0, errors.Wrap(resumeErr, "resumableState.IsAlreadyProcessed")
			}
			if isProcessed && strings.HasSuffix(localMetadataFile, ".json") {
				tmBody, err := os.ReadFile(localMetadataFile)
				if err != nil {
					return nil, 0, errors.Wrap(err, "ReadFile localMetadataFile")
				}
				if err = json.Unmarshal(tmBody, &tableMetadata); err != nil {
					return nil, 0, errors.Wrap(err, "Unmarshal tableMetadata")
				}
				partitionsIdMap, _ = partition.ConvertPartitionsToIdsMapAndNamesList(ctx, b.ch, nil, ListOfTables{&tableMetadata}, partitions)
				filterPartsAndFilesByPartitionsFilter(tableMetadata, partitionsIdMap[metadata.TableTitle{Database: tableMetadata.Database, Table: tableMetadata.Table}])
				tableMetadata.LocalFile = localMetadataFile
			}
			if isProcessed {
				size += uint64(processedSize)
				continue
			}
		}
		var tmBody []byte
		metadataNotFound := false
		retry := retrier.New(retrier.ExponentialBackoff(b.cfg.General.RetriesOnFailure, common.AddRandomJitter(b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter)), b)
		err := retry.RunCtx(ctx, func(ctx context.Context) error {
			tmReader, err := b.dst.GetFileReader(ctx, remoteMetadataFile)
			if err != nil {
				if isRemoteMetadataNotFound(err) {
					metadataNotFound = true
					return nil
				}
				return errors.Wrapf(err, "can't GetFileReader(%s) error", remoteMetadataFile)
			}
			tmBody, err = io.ReadAll(tmReader)
			if err != nil {
				return errors.Wrapf(err, "can't io.ReadAll(%s) error", remoteMetadataFile)
			}
			err = tmReader.Close()
			if err != nil {
				return errors.Wrapf(err, "can't Close(%s) error", remoteMetadataFile)
			}
			return nil
		})
		// Missing metadata is permanent: a 404 will never become available, so we
		// detect it inside the retry closure and break out without burning the
		// exponential backoff. A missing table .json means the backup is broken,
		// so fail fast with a clear error. The optional .sql (incremental/embedded
		// metadata) may legitimately be absent, so it is still skipped.
		if metadataNotFound {
			if strings.HasSuffix(localMetadataFile, ".json") {
				return nil, 0, errors.Errorf("remote metadata file %s not found on remote storage, backup is broken", remoteMetadataFile)
			}
			logger.Warn().Str("remoteMetadataFile", remoteMetadataFile).Msg("metadata file not found on remote, skipping")
			continue
		}
		// sql file could be not present in incremental backup
		if err != nil && strings.HasSuffix(localMetadataFile, ".sql") {
			log.Warn().Str("localMetadataFile", localMetadataFile).Err(err).Send()
			continue
		}
		if err != nil {
			return nil, 0, err
		}

		if err = os.MkdirAll(path.Dir(localMetadataFile), 0755); err != nil {
			return nil, 0, errors.Wrap(err, "MkdirAll metadata dir")
		}
		var written int64
		if strings.HasSuffix(localMetadataFile, ".sql") {
			if err = os.WriteFile(localMetadataFile, tmBody, 0640); err != nil {
				return nil, 0, errors.Wrap(err, "WriteFile localMetadataFile")
			}
			if err = filesystemhelper.Chown(localMetadataFile, b.ch, disks, false); err != nil {
				return nil, 0, errors.Wrap(err, "Chown localMetadataFile")
			}
			written = int64(len(tmBody))
			size += uint64(len(tmBody))
		} else {
			if err = json.Unmarshal(tmBody, &tableMetadata); err != nil {
				return nil, 0, errors.Wrapf(err, "can't json.Unmarshal(%s) error", remoteMetadataFile)
			}
			if b.shouldSkipByTableEngine(tableMetadata) || b.shouldSkipByTableName(fmt.Sprintf("%s.%s", tableMetadata.Database, tableMetadata.Table)) {
				return nil, 0, nil
			}
			partitionsIdMap, _ = partition.ConvertPartitionsToIdsMapAndNamesList(ctx, b.ch, nil, ListOfTables{&tableMetadata}, partitions)
			filterPartsAndFilesByPartitionsFilter(tableMetadata, partitionsIdMap[metadata.TableTitle{Database: tableMetadata.Database, Table: tableMetadata.Table}])
			// save metadata
			jsonSize := uint64(0)
			jsonSize, err = tableMetadata.Save(localMetadataFile, schemaOnly)
			if err != nil {
				return nil, 0, errors.Wrap(err, "save tableMetadata")
			}
			written = int64(jsonSize)
			size += jsonSize
			tableMetadata.LocalFile = localMetadataFile
		}
		if resume {
			if err = b.resumableState.AppendToState(localMetadataFile, written); err != nil {
				return nil, 0, errors.Wrap(err, "resumableState.AppendToState")
			}
		}
	}
	logger.Info().Fields(map[string]string{
		"operation": "download_metadata",
		"backup":    backupName,
		"duration":  utils.HumanizeDuration(time.Since(start)),
		"size":      utils.FormatBytes(size),
	}).Msg("done")
	return &tableMetadata, size, nil
}

// downloadMissedInnerTablesMetadata - download, missed .inner. tables if materialized view query not contains `TO db.table` clause, https://github.com/Altinity/clickhouse-backup/issues/765
// @todo think about parallel download if sequentially will slow
func (b *Backuper) downloadMissedInnerTablesMetadata(ctx context.Context, backupName string, metadataSize uint64, tablesForDownload []metadata.TableTitle, tableMetadataAfterDownload ListOfTables, disks []clickhouse.Disk, schemaOnly bool, partitions []string) (ListOfTables, []metadata.TableTitle, uint64, error) {
	if b.isEmbedded {
		return tableMetadataAfterDownload, tablesForDownload, metadataSize, nil
	}
	for _, t := range tableMetadataAfterDownload {
		if t == nil {
			continue
		}
		if strings.HasPrefix(t.Query, "ATTACH MATERIALIZED") || strings.HasPrefix(t.Query, "CREATE MATERIALIZED") {
			if strings.Contains(t.Query, " TO ") && !strings.Contains(t.Query, " TO INNER UUID") {
				continue
			}
			var innerTableName string
			if matches := uuidRE.FindStringSubmatch(t.Query); len(matches) > 0 {
				innerTableName = fmt.Sprintf(".inner_id.%s", matches[1])
			} else {
				innerTableName = fmt.Sprintf(".inner.%s", t.Table)
			}
			innerTableExists := false
			for _, existsTable := range tablesForDownload {
				if existsTable.Table == innerTableName && existsTable.Database == t.Database {
					innerTableExists = true
					break
				}
			}
			if !innerTableExists {
				innerTableTitle := metadata.TableTitle{Database: t.Database, Table: innerTableName}
				metadataLogger := log.With().Str("missed_inner_metadata", fmt.Sprintf("%s.%s", innerTableTitle.Database, innerTableTitle.Table)).Logger()
				innerTableMetadata, size, err := b.downloadTableMetadata(ctx, backupName, disks, innerTableTitle, schemaOnly, partitions, b.resume, metadataLogger)
				if err != nil {
					return tableMetadataAfterDownload, tablesForDownload, metadataSize, errors.Wrap(err, "downloadTableMetadata for inner table")
				}
				metadataSize += size
				tablesForDownload = append(tablesForDownload, innerTableTitle)
				tableMetadataAfterDownload = append(tableMetadataAfterDownload, innerTableMetadata)
			}
		}
	}
	return tableMetadataAfterDownload, tablesForDownload, metadataSize, nil
}

func (b *Backuper) downloadRBACData(ctx context.Context, remoteBackup storage.Backup) (uint64, error) {
	return b.downloadBackupRelatedDir(ctx, remoteBackup, "access")
}

func (b *Backuper) downloadConfigData(ctx context.Context, remoteBackup storage.Backup) (uint64, error) {
	return b.downloadBackupRelatedDir(ctx, remoteBackup, "configs")
}

func (b *Backuper) downloadNamedCollectionsData(ctx context.Context, remoteBackup storage.Backup) (uint64, error) {
	return b.downloadBackupRelatedDir(ctx, remoteBackup, "named_collections")
}

func (b *Backuper) downloadBackupRelatedDir(ctx context.Context, remoteBackup storage.Backup, prefix string) (uint64, error) {
	localDir := path.Join(b.DefaultDataPath, "backup", remoteBackup.BackupName, prefix)

	if remoteBackup.DataFormat != DirectoryFormat {
		prefix = fmt.Sprintf("%s.%s", prefix, config.ArchiveExtensions[remoteBackup.DataFormat])
	}
	remoteSource := path.Join(remoteBackup.BackupName, prefix)

	if b.resume {
		isProcessed, processedSize, resumeErr := b.resumableState.IsAlreadyProcessed(remoteSource)
		if resumeErr != nil {
			return 0, errors.Wrap(resumeErr, "resumableState.IsAlreadyProcessed")
		}
		if isProcessed {
			return uint64(processedSize), nil
		}
	}
	var downloadErr error
	downloadedBytes := int64(0)
	if remoteBackup.DataFormat == DirectoryFormat {
		if downloadedBytes, downloadErr = b.dst.DownloadPath(ctx, remoteSource, localDir, b.cfg.General.RetriesOnFailure, b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter, b, b.cfg.General.DownloadMaxBytesPerSecond); downloadErr != nil {
			//SFTP can't walk on non exists paths and return error
			if !strings.Contains(downloadErr.Error(), "not exist") {
				return 0, errors.Wrap(downloadErr, "DownloadPath")
			}
		}
		if _, err := os.Stat(localDir); err != nil && os.IsNotExist(err) {
			return 0, nil
		}
		if b.resume {
			if err := b.resumableState.AppendToState(remoteSource, downloadedBytes); err != nil {
				return 0, errors.Wrap(err, "resumableState.AppendToState")
			}
		}
		log.Debug().Str("remoteSource", remoteSource).Str("operation", "downloadBackupRelatedDir").Msg("done")
		return uint64(downloadedBytes), nil
	}
	remoteFileInfo, err := b.dst.StatFile(ctx, remoteSource)
	if err != nil {
		log.Debug().Msgf("%s not exists on remote storage, skip download", remoteSource)
		return 0, nil
	}
	retry := retrier.New(retrier.ExponentialBackoff(b.cfg.General.RetriesOnFailure, common.AddRandomJitter(b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter)), b)
	err = retry.RunCtx(ctx, func(ctx context.Context) error {
		downloadedBytes, downloadErr = b.dst.DownloadCompressedStream(ctx, remoteSource, localDir, b.cfg.General.DownloadMaxBytesPerSecond)
		return downloadErr
	})
	if err != nil {
		return 0, errors.Wrap(err, "DownloadCompressedStream")
	}
	if b.resume {
		if err := b.resumableState.AppendToState(remoteSource, remoteFileInfo.Size()); err != nil {
			return 0, errors.Wrap(err, "resumableState.AppendToState")
		}
	}
	log.Debug().Str("remoteSource", remoteSource).Str("operation", "downloadBackupRelatedDir").Msg("done")
	return uint64(remoteFileInfo.Size()), nil
}

func (b *Backuper) downloadTableData(ctx context.Context, remoteBackup metadata.BackupMetadata, table metadata.TableMetadata, disks []clickhouse.Disk, hardlinkExistsFiles bool, manifest *storage.ManifestReader) (uint64, error) {
	dbAndTableDir := path.Join(common.TablePathEncode(table.Database), common.TablePathEncode(table.Table))
	dataGroup, dataCtx := errgroup.WithContext(ctx)
	dataGroup.SetLimit(int(b.cfg.General.DownloadConcurrency))
	downloadedSize := uint64(0)
	var isRebalancedAfterHardLinks atomic.Bool

	if remoteBackup.DataFormat != DirectoryFormat {
		capacity := 0
		downloadOffset := make(map[string]int)
		for disk := range table.Files {
			capacity += len(table.Files[disk])
			downloadOffset[disk] = 0
		}
		log.Debug().Msgf("start %s.%s with concurrency=%d len(table.Files[...])=%d", table.Database, table.Table, b.cfg.General.DownloadConcurrency, capacity)
		for common.SumMapValuesInt(downloadOffset) < capacity {
			for disk := range table.Files {
				if downloadOffset[disk] >= len(table.Files[disk]) {
					continue
				}
				archiveFile := table.Files[disk][downloadOffset[disk]]
				capturedDisk := disk
				isRebalanced := false
				if capturedDisk, isRebalanced = table.RebalancedFiles[archiveFile]; !isRebalanced {
					capturedDisk = disk
				}
				capturedParts := table.Parts[capturedDisk]
				tableLocalDir := b.getLocalBackupDataPathForTable(remoteBackup.BackupName, capturedDisk, dbAndTableDir)
				downloadOffset[disk] += 1
				tableRemoteFile := path.Join(remoteBackup.BackupName, "shadow", common.TablePathEncode(table.Database), common.TablePathEncode(table.Table), archiveFile)
				dataGroup.Go(func() error {
					log.Debug().Msgf("start download %s", tableRemoteFile)
					if b.resume {
						isProcessed, downloadedFileSize, resumeErr := b.resumableState.IsAlreadyProcessed(tableRemoteFile)
						if resumeErr != nil {
							return errors.Wrap(resumeErr, "resumableState.IsAlreadyProcessed")
						}
						if isProcessed {
							atomic.AddUint64(&downloadedSize, uint64(downloadedFileSize))
							return nil
						}
					}
					if hardlinkExistsFiles {
						ext := "." + config.ArchiveExtensions[remoteBackup.DataFormat]
						// Archive files are named with the original disk prefix (e.g. "default_part1.tar.gz"),
						// not the rebalanced disk name, so use `disk` for the trim
						partName := strings.TrimPrefix(strings.TrimSuffix(archiveFile, ext), disk+"_")
						var foundPart *metadata.Part
						var idx int
						for i, part := range capturedParts {
							if part.Name == partName {
								foundPart = &part
								idx = i
								break
							}
						}
						if foundPart != nil {
							found, size, err := b.hardlinkIfLocalPartExistsAndChecksumEqual(remoteBackup.BackupName, table, foundPart, disks, capturedDisk, dbAndTableDir)
							if err != nil {
								return errors.Wrap(err, "hardlinkIfLocalPartExistsAndChecksumEqual")
							}
							if found {
								if foundPart.RebalancedDisk != "" && foundPart.RebalancedDisk != capturedDisk {
									table.Parts[capturedDisk][idx] = *foundPart
									isRebalancedAfterHardLinks.Store(true)
								}
								atomic.AddUint64(&downloadedSize, uint64(size))
								if b.resume {
									if err := b.resumableState.AppendToState(tableRemoteFile, size); err != nil {
										return errors.Wrap(err, "resumableState.AppendToState")
									}
								}
								return nil
							}

						}
						if foundPart == nil {
							// continue here can be dangerous, we just not download this part
							log.Warn().Msgf("part %s not found in metadata for archive %s on disk %s, this part will be downloaded", partName, archiveFile, disk)
						}
					}
					retry := retrier.New(retrier.ExponentialBackoff(b.cfg.General.RetriesOnFailure, common.AddRandomJitter(b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter)), b)
					var downloadedBytes int64
					var downloadErr error
					err := retry.RunCtx(dataCtx, func(dataCtx context.Context) error {
						downloadedBytes, downloadErr = b.dst.DownloadCompressedStream(dataCtx, tableRemoteFile, tableLocalDir, b.cfg.General.DownloadMaxBytesPerSecond)
						if downloadErr != nil {
							return downloadErr
						}
						return nil
					})
					if err != nil {
						return errors.Wrap(err, "DownloadCompressedStream")
					}
					atomic.AddUint64(&downloadedSize, uint64(downloadedBytes))
					if b.resume {
						if err := b.resumableState.AppendToState(tableRemoteFile, downloadedBytes); err != nil {
							return errors.Wrap(err, "resumableState.AppendToState")
						}
					}
					log.Debug().Msgf("finish download %s", tableRemoteFile)
					return nil
				})
			}
		}
	} else {
		capacity := 0
		for disk := range table.Parts {
			capacity += len(table.Parts[disk])
		}
		log.Debug().Msgf("start %s.%s with concurrency=%d len(table.Parts[...])=%d", table.Database, table.Table, b.cfg.General.DownloadConcurrency, capacity)

		for disk, parts := range table.Parts {
			tableRemotePath := path.Join(remoteBackup.BackupName, "shadow", dbAndTableDir, disk)
			diskPath, diskExists := b.DiskToPathMap[disk]
			tableLocalPath := path.Join(diskPath, "backup", remoteBackup.BackupName, "shadow", dbAndTableDir, disk)
			if b.isEmbedded {
				tableLocalPath = path.Join(diskPath, remoteBackup.BackupName, b.embeddedClusterPrefix, "data", dbAndTableDir)
			}
			for i, part := range parts {
				if part.Required {
					continue
				}
				// When RebalancedDisk is set, always use it to determine the local path,
				// even if the original disk exists — this ensures data lands on the
				// rebalanced target disk instead of the original one
				if part.RebalancedDisk != "" {
					diskPath, diskExists = b.DiskToPathMap[part.RebalancedDisk]
					if !diskExists {
						return 0, errors.Errorf("downloadTableData: table: `%s`.`%s`, disk: %s, part.Name: %s, part.RebalancedDisk: %s not rebalanced", table.Table, table.Database, disk, part.Name, part.RebalancedDisk)
					}
					tableLocalPath = path.Join(diskPath, "backup", remoteBackup.BackupName, "shadow", dbAndTableDir, part.RebalancedDisk)
					if b.isEmbedded {
						tableLocalPath = path.Join(diskPath, remoteBackup.BackupName, b.embeddedClusterPrefix, "data", dbAndTableDir)
					}
				} else if !diskExists {
					return 0, errors.Errorf("downloadTableData: table: `%s`.`%s`, disk: %s, part.Name: %s not found and not rebalanced", table.Table, table.Database, disk, part.Name)
				}
				partRemotePath := path.Join(tableRemotePath, part.Name)
				partLocalPath := path.Join(tableLocalPath, part.Name)
				capturedPart := part
				capturedDisk := disk
				idx := i
				dataGroup.Go(func() error {
					log.Debug().Msgf("start %s -> %s", partRemotePath, partLocalPath)
					if b.resume {
						isProcesses, pathSize, resumeErr := b.resumableState.IsAlreadyProcessed(partRemotePath)
						if resumeErr != nil {
							return errors.Wrap(resumeErr, "resumableState.IsAlreadyProcessed")
						}
						atomic.AddUint64(&downloadedSize, uint64(pathSize))
						if isProcesses {
							return nil
						}
					}
					if hardlinkExistsFiles {
						found, size, err := b.hardlinkIfLocalPartExistsAndChecksumEqual(remoteBackup.BackupName, table, &capturedPart, disks, capturedDisk, dbAndTableDir)
						if err != nil {
							return errors.Wrap(err, "hardlinkIfLocalPartExistsAndChecksumEqual")
						}
						if found {
							if capturedPart.RebalancedDisk != "" && capturedPart.RebalancedDisk != capturedDisk {
								table.Parts[capturedDisk][idx] = capturedPart
								isRebalancedAfterHardLinks.Store(true)
							}
							atomic.AddUint64(&downloadedSize, uint64(size))
							if b.resume {
								if err := b.resumableState.AppendToState(partRemotePath, size); err != nil {
									return errors.Wrap(err, "resumableState.AppendToState")
								}
							}
							return nil
						}
					}

					// Try manifest-based download to avoid Walk (ListObjectsV2)
					if manifest != nil {
						manifestPrefix := path.Join("shadow", dbAndTableDir, capturedDisk, capturedPart.Name)
						manifestFiles, manifestErr := manifest.FilesUnderPrefix(manifestPrefix)
						if manifestErr != nil {
							log.Warn().Err(manifestErr).Msgf("manifest lookup failed for %s, will fall back to Walk", manifestPrefix)
						}
						if len(manifestFiles) > 0 {
							pathSize, downloadErr := b.dst.DownloadPathWithManifest(dataCtx, partRemotePath, partLocalPath, manifestFiles, b.cfg.General.RetriesOnFailure, b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter, b, b.cfg.General.DownloadMaxBytesPerSecond)
							if downloadErr != nil {
								return errors.WithMessage(downloadErr, "DownloadPathWithManifest")
							}
							atomic.AddUint64(&downloadedSize, uint64(pathSize))
							if b.resume {
								if err := b.resumableState.AppendToState(partRemotePath, pathSize); err != nil {
									return errors.Wrap(err, "resumableState.AppendToState")
								}
							}
							log.Debug().Msgf("finish %s -> %s (manifest, %d files)", partRemotePath, partLocalPath, len(manifestFiles))
							return nil
						}
					}
					// Fall back to Walk (ListObjectsV2) when no manifest is available
					pathSize, downloadErr := b.dst.DownloadPath(dataCtx, partRemotePath, partLocalPath, b.cfg.General.RetriesOnFailure, b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter, b, b.cfg.General.DownloadMaxBytesPerSecond)
					if downloadErr != nil {
						return errors.Wrap(downloadErr, "DownloadPath")
					}
					atomic.AddUint64(&downloadedSize, uint64(pathSize))
					if b.resume {
						if err := b.resumableState.AppendToState(partRemotePath, pathSize); err != nil {
							return errors.Wrap(err, "resumableState.AppendToState")
						}
					}
					log.Debug().Msgf("finish %s -> %s", partRemotePath, partLocalPath)
					return nil
				})
			}
		}
	}
	if err := dataGroup.Wait(); err != nil {
		return 0, errors.Wrap(err, "one of downloadTableData go-routine return error")
	}
	if isRebalancedAfterHardLinks.Load() {
		if _, saveErr := table.Save(table.LocalFile, false); saveErr != nil {
			return 0, errors.Wrap(saveErr, "save rebalanced table after hardlinks")
		}
	}
	if !b.isEmbedded && remoteBackup.RequiredBackup != "" {
		diffBytes, err := b.downloadDiffParts(ctx, remoteBackup, table, dbAndTableDir, disks, hardlinkExistsFiles)
		if err != nil {
			return 0, errors.Wrap(err, "downloadDiffParts")
		}
		downloadedSize += uint64(diffBytes)
	}

	return downloadedSize, nil
}

func (b *Backuper) hardlinkIfLocalPartExistsAndChecksumEqual(backupName string, table metadata.TableMetadata, part *metadata.Part, disks []clickhouse.Disk, diskName, dbAndTableDir string) (bool, int64, error) {
	diskType := ""
	for _, d := range disks {
		if d.Name == diskName {
			diskType = d.Type

			break
		}
	}
	if diskType == "" {
		return false, 0, errors.Errorf("can't find %s in disks=%v", diskName, disks)
	}
	if _, ok := table.HashOfAllFiles[part.Name]; ok {
		found, size, err := b.hardlinkByHashOfAllFiles(context.Background(), backupName, table, part, disks, diskName, dbAndTableDir)
		if err != nil {
			log.Warn().Err(err).Msgf("hardlinkByHashOfAllFiles failed for %s.%s/%s, falling back to CRC64", table.Database, table.Table, part.Name)
		} else if found {
			return true, size, nil
		}
	}
	existingPartPath, localDisk, err := b.findLocalPartWithSameChecksum(table, part, disks, diskType, dbAndTableDir)
	if err != nil || existingPartPath == "" || localDisk == nil {
		return false, 0, err
	}
	partLocalPath := path.Join(b.getLocalBackupDataPathForTable(backupName, localDisk.Name, dbAndTableDir), part.Name)
	log.Info().Msgf("Found existing part %s with matching checksum, creating hardlinks to %s", existingPartPath, partLocalPath)
	if err := b.makePartHardlinks(existingPartPath, partLocalPath); err != nil {
		return false, 0, errors.Wrapf(err, "failed to create hardlinks for %s", existingPartPath)
	}
	if diskName != localDisk.Name {
		part.RebalancedDisk = localDisk.Name
	}
	var partSize int64
	walkErr := filepath.Walk(existingPartPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return errors.Wrap(err, "walk existingPartPath")
		}
		if !info.IsDir() {
			partSize += info.Size()
		}
		return nil
	})
	if walkErr != nil {
		return false, 0, errors.Wrapf(walkErr, "failed to calculate size of %s", existingPartPath)
	}
	return true, partSize, nil
}

// findLocalPartWithSameChecksum searches local disks with the same diskType for an existing part
// directory whose CRC64 of checksums.txt matches table metadata, without creating hardlinks or
// mutating part, so it is reusable as a read-only probe for the free space check,
// https://github.com/Altinity/clickhouse-backup/issues/1268
func (b *Backuper) findLocalPartWithSameChecksum(table metadata.TableMetadata, part *metadata.Part, disks []clickhouse.Disk, diskType, dbAndTableDir string) (string, *clickhouse.Disk, error) {
	if _, exists := table.Checksums[part.Name]; !exists {
		return "", nil, nil
	}
	for dIdx := range disks {
		localDisk := &disks[dIdx]
		if localDisk.Type != diskType {
			continue
		}
		if localDisk.IsBackup {
			continue
		}
		var existingPartPaths []string
		p1 := path.Join(localDisk.Path, "data", dbAndTableDir, part.Name)
		if _, err := os.Stat(p1); err == nil {
			existingPartPaths = append(existingPartPaths, p1)
		}
		if len(existingPartPaths) == 0 && table.UUID != "" {
			p2 := path.Join(localDisk.Path, "store", table.UUID[:3], table.UUID, part.Name)
			if _, err := os.Stat(p2); err == nil {
				existingPartPaths = append(existingPartPaths, p2)
			}
		}
		// https://github.com/Altinity/clickhouse-backup/issues/1244
		if len(existingPartPaths) == 0 {
			globDir, globErr := filepath.Glob(path.Join(localDisk.Path, "backup", "*", "shadow", dbAndTableDir, localDisk.Name, part.Name))
			if globErr != nil {
				return "", nil, errors.Wrap(globErr, "filepath.Glob")
			}
			existingPartPaths = append(existingPartPaths, globDir...)
		}

		for i, existingPartPath := range existingPartPaths {
			checksum, err := common.CalculateChecksum(existingPartPath, "checksums.txt")
			if err != nil {
				log.Warn().Msgf("calculating checksum for %s failed: %v", existingPartPath, err)
				if i < len(existingPartPaths)-1 {
					continue
				}
				return "", nil, nil
			}
			if checksum == table.Checksums[part.Name] {
				return existingPartPath, localDisk, nil
			}
			log.Warn().Msgf("Found existing part %s but checksums do not match. Expected %d, got %d. Will download.", existingPartPath, table.Checksums[part.Name], checksum)
		}
	}
	return "", nil, nil
}

// checkFreeSpaceForDownload - https://github.com/Altinity/clickhouse-backup/issues/1268
// calculates required disk space from per-part `size` fields in already downloaded and filtered
// table metadata (so --tables and --partitions are respected) and compares it with the total free
// space. When hardlinkExistsFiles is true, parts which can be hardlinked from existing local parts
// (matched by hash_of_all_files via system.parts or by CRC64 of checksums.txt) are not counted.
func (b *Backuper) checkFreeSpaceForDownload(ctx context.Context, remoteBackup storage.Backup, tables ListOfTables, disks []clickhouse.Disk, hardlinkExistsFiles, isResumeExists bool) error {
	requiredSize := uint64(0)
	unknownSizeParts := 0
	diskTypeByName := make(map[string]string, len(disks))
	for _, d := range disks {
		diskTypeByName[d.Name] = d.Type
	}
	var hardlinkableByHash map[metadata.TableTitle]common.EmptyMap
	if hardlinkExistsFiles {
		var hashErr error
		hardlinkableByHash, hashErr = b.findHardlinkablePartsByHash(ctx, tables, disks)
		if hashErr != nil {
			log.Warn().Err(hashErr).Msg("can't lookup hash_of_all_files in system.parts, free space check will not count parts hardlinkable by hash")
		}
	}
	// required parts have size=0 in the current backup metadata, their size lives in the backup
	// of the required chain where the part is not required, resolve it the same way as
	// downloadDiffParts does, metadata downloaded here is cached on local disk and reused later
	requiredBackupMetadataCache := make(map[string]*metadata.BackupMetadata)
	requiredTableMetadataCache := make(map[string]*metadata.TableMetadata)
	resolveRequiredPartSize := func(requiredBackupName string, title metadata.TableTitle, partName string) (uint64, bool) {
		for requiredBackupName != "" {
			requiredBackupMetadata, exists := requiredBackupMetadataCache[requiredBackupName]
			if !exists {
				m, err := b.ReadBackupMetadataRemote(ctx, requiredBackupName)
				if err != nil {
					log.Warn().Err(err).Msgf("can't read %s metadata to resolve required part %s size", requiredBackupName, partName)
					return 0, false
				}
				requiredBackupMetadataCache[requiredBackupName] = m
				requiredBackupMetadata = m
			}
			tableMetadataCacheKey := path.Join(requiredBackupName, title.Database, title.Table)
			requiredTableMetadata, exists := requiredTableMetadataCache[tableMetadataCacheKey]
			if !exists {
				m, err := b.downloadTableMetadataIfNotExists(ctx, requiredBackupName, title)
				if err != nil {
					log.Warn().Err(err).Msgf("can't download %s table metadata to resolve required part %s size", tableMetadataCacheKey, partName)
					return 0, false
				}
				requiredTableMetadataCache[tableMetadataCacheKey] = m
				requiredTableMetadata = m
			}
			var foundPart *metadata.Part
			for _, requiredParts := range requiredTableMetadata.Parts {
				for i := range requiredParts {
					if requiredParts[i].Name == partName {
						foundPart = &requiredParts[i]
						break
					}
				}
				if foundPart != nil {
					break
				}
			}
			if foundPart == nil {
				return 0, false
			}
			if !foundPart.Required {
				return foundPart.Size, foundPart.Size > 0
			}
			requiredBackupName = requiredBackupMetadata.RequiredBackup
		}
		return 0, false
	}
	for _, t := range tables {
		if t == nil || t.MetadataOnly {
			continue
		}
		title := metadata.TableTitle{Database: t.Database, Table: t.Table}
		dbAndTableDir := path.Join(common.TablePathEncode(t.Database), common.TablePathEncode(t.Table))
		byHash := hardlinkableByHash[title]
		for diskName, parts := range t.Parts {
			for i := range parts {
				part := parts[i]
				if hardlinkExistsFiles {
					if _, ok := byHash[part.Name]; ok {
						continue
					}
					if existingPartPath, _, probeErr := b.findLocalPartWithSameChecksum(*t, &part, disks, diskTypeByName[diskName], dbAndTableDir); probeErr == nil && existingPartPath != "" {
						continue
					}
				}
				if !part.Required {
					if part.Size > 0 {
						requiredSize += part.Size
					} else {
						unknownSizeParts++
					}
					continue
				}
				// required part already present in the local required backup will be hardlinked
				// by downloadDiffParts without downloading, same path resolution as downloadDiffParts
				activeDisk := diskName
				if part.RebalancedDisk != "" {
					activeDisk = part.RebalancedDisk
				}
				if activeDiskPath, diskExists := b.DiskToPathMap[activeDisk]; diskExists {
					if _, statErr := os.Stat(path.Join(activeDiskPath, "backup", remoteBackup.RequiredBackup, "shadow", dbAndTableDir, activeDisk, part.Name)); statErr == nil {
						continue
					}
				}
				if size, sizeResolved := resolveRequiredPartSize(remoteBackup.RequiredBackup, title, part.Name); sizeResolved {
					requiredSize += size
				} else {
					unknownSizeParts++
				}
			}
		}
	}
	if requiredSize == 0 && unknownSizeParts == 0 {
		return nil
	}
	freeSize := uint64(0)
	for _, d := range disks {
		freeSize += d.FreeSpace
	}
	if freeSize <= requiredSize {
		errMsg := fmt.Sprintf("%s requires %s free space to download, but total free space is %s", remoteBackup.BackupName, utils.FormatBytes(requiredSize), utils.FormatBytes(freeSize))
		if !isResumeExists {
			return errors.New(errMsg)
		}
		log.Warn().Msg(errMsg)
		return nil
	}
	if unknownSizeParts > 0 {
		log.Warn().Msgf("%d parts in %s don't contain `size` field in metadata (backup created by older clickhouse-backup version), free space check is not precise: requires at least %s, total free space is %s", unknownSizeParts, remoteBackup.BackupName, utils.FormatBytes(requiredSize), utils.FormatBytes(freeSize))
	}
	return nil
}

// findHardlinkablePartsByHash returns per-table sets of part names for which an active part with
// identical hash_of_all_files already exists in system.parts on one of the known disks, resolved
// with batched queries instead of one query per part, https://github.com/Altinity/clickhouse-backup/issues/1268
func (b *Backuper) findHardlinkablePartsByHash(ctx context.Context, tables ListOfTables, disks []clickhouse.Disk) (map[metadata.TableTitle]common.EmptyMap, error) {
	result := make(map[metadata.TableTitle]common.EmptyMap)
	type partRef struct {
		title    metadata.TableTitle
		partName string
	}
	partsByHash := make(map[string][]partRef)
	hashes := make([]string, 0)
	for _, t := range tables {
		if t == nil || t.MetadataOnly {
			continue
		}
		title := metadata.TableTitle{Database: t.Database, Table: t.Table}
		for partName, h := range t.HashOfAllFiles {
			h = strings.ToLower(h)
			if _, exists := partsByHash[h]; !exists {
				hashes = append(hashes, h)
			}
			partsByHash[h] = append(partsByHash[h], partRef{title: title, partName: partName})
		}
	}
	if len(hashes) == 0 {
		return result, nil
	}
	knownDisks := make(common.EmptyMap, len(disks))
	for _, d := range disks {
		knownDisks[d.Name] = struct{}{}
	}
	const chunkSize = 1000
	for chunkStart := 0; chunkStart < len(hashes); chunkStart += chunkSize {
		chunk := hashes[chunkStart:min(chunkStart+chunkSize, len(hashes))]
		var rows []struct {
			Hash string `ch:"hash"`
			Disk string `ch:"disk_name"`
		}
		q := fmt.Sprintf("SELECT DISTINCT lower(hash_of_all_files) AS hash, disk_name FROM system.parts WHERE active AND lower(hash_of_all_files) IN (%s)", strings.TrimSuffix(strings.Repeat("?,", len(chunk)), ","))
		args := make([]interface{}, len(chunk))
		for i, h := range chunk {
			args[i] = h
		}
		if err := b.ch.SelectContext(ctx, &rows, q, args...); err != nil {
			return nil, errors.Wrap(err, "SELECT hash_of_all_files FROM system.parts")
		}
		for _, row := range rows {
			if _, diskExists := knownDisks[row.Disk]; !diskExists {
				continue
			}
			for _, ref := range partsByHash[row.Hash] {
				if _, exists := result[ref.title]; !exists {
					result[ref.title] = make(common.EmptyMap)
				}
				result[ref.title][ref.partName] = struct{}{}
			}
		}
	}
	return result, nil
}

// hardlinkByHashOfAllFiles looks up an existing live part in system.parts whose
// hash_of_all_files matches the expected value from backup metadata. If several
// candidates exist (e.g. copies of the same data under different part names),
// the one with the smallest Levenshtein distance to part.Name wins. On success
// it hardlinks the resolved on-disk directory into the backup shadow path.
func (b *Backuper) hardlinkByHashOfAllFiles(ctx context.Context, backupName string, table metadata.TableMetadata, part *metadata.Part, disks []clickhouse.Disk, diskName, dbAndTableDir string) (bool, int64, error) {
	expected, ok := table.HashOfAllFiles[part.Name]
	if !ok {
		return false, 0, nil
	}
	var rows []struct {
		Name     string `ch:"name"`
		Path     string `ch:"path"`
		Disk     string `ch:"disk_name"`
		Database string `ch:"database"`
		Table    string `ch:"table"`
	}
	// A part with an identical hash_of_all_files can live under a different
	// table name (e.g. the table was renamed, or the same data was inserted
	// into another table). A matching hash_of_all_files means the part files
	// are byte-identical, so the directory is safe to hardlink regardless of
	// which table currently owns it. See
	// https://github.com/Altinity/clickhouse-backup/issues/1398
	q := "SELECT name, path, disk_name, database, `table` FROM system.parts WHERE lower(hash_of_all_files)=? AND active"
	if err := b.ch.SelectContext(ctx, &rows, q, expected); err != nil {
		return false, 0, errors.Wrap(err, "system.parts lookup by hash_of_all_files")
	}
	if len(rows) == 0 {
		return false, 0, nil
	}
	sort.SliceStable(rows, func(i, j int) bool {
		// Prefer a candidate from the same table, then the closest part name.
		sameI := rows[i].Database == table.Database && rows[i].Table == table.Table
		sameJ := rows[j].Database == table.Database && rows[j].Table == table.Table
		if sameI != sameJ {
			return sameI
		}
		di := levenshtein(rows[i].Name, part.Name)
		dj := levenshtein(rows[j].Name, part.Name)
		if di != dj {
			return di < dj
		}
		return rows[i].Name < rows[j].Name
	})

	var localDisk *clickhouse.Disk
	for i := range disks {
		if disks[i].Name == rows[0].Disk {
			localDisk = &disks[i]
			break
		}
	}
	if localDisk == nil {
		return false, 0, errors.Errorf("disk %q from system.parts not found in disks=%v", rows[0].Disk, disks)
	}
	srcPath := strings.TrimRight(rows[0].Path, "/")
	partLocalPath := path.Join(b.getLocalBackupDataPathForTable(backupName, localDisk.Name, dbAndTableDir), part.Name)
	log.Info().Msgf("hash_of_all_files match: hardlink %s -> %s (live part %q from %s.%s)", srcPath, partLocalPath, rows[0].Name, rows[0].Database, rows[0].Table)
	if err := b.makePartHardlinks(srcPath, partLocalPath); err != nil {
		return false, 0, errors.Wrapf(err, "failed to create hardlinks for %s", srcPath)
	}
	if diskName != localDisk.Name {
		part.RebalancedDisk = localDisk.Name
	}
	var partSize int64
	walkErr := filepath.Walk(srcPath, func(_ string, info os.FileInfo, err error) error {
		if err != nil {
			return errors.Wrap(err, "walk srcPath")
		}
		if !info.IsDir() {
			partSize += info.Size()
		}
		return nil
	})
	if walkErr != nil {
		return false, 0, errors.Wrapf(walkErr, "failed to calculate size of %s", srcPath)
	}
	return true, partSize, nil
}

// levenshtein computes the edit distance between two strings.
func levenshtein(a, b string) int {
	ar, br := []rune(a), []rune(b)
	la, lb := len(ar), len(br)
	if la == 0 {
		return lb
	}
	if lb == 0 {
		return la
	}
	prev := make([]int, lb+1)
	curr := make([]int, lb+1)
	for j := 0; j <= lb; j++ {
		prev[j] = j
	}
	for i := 1; i <= la; i++ {
		curr[0] = i
		for j := 1; j <= lb; j++ {
			cost := 1
			if ar[i-1] == br[j-1] {
				cost = 0
			}
			d := prev[j] + 1
			if curr[j-1]+1 < d {
				d = curr[j-1] + 1
			}
			if prev[j-1]+cost < d {
				d = prev[j-1] + cost
			}
			curr[j] = d
		}
		prev, curr = curr, prev
	}
	return prev[lb]
}

func (b *Backuper) downloadDiffParts(ctx context.Context, remoteBackup metadata.BackupMetadata, table metadata.TableMetadata, dbAndTableDir string, disks []clickhouse.Disk, hardlinkExistsFiles bool) (int64, error) {
	log.Debug().
		Str("backup", remoteBackup.BackupName).
		Str("operation", "downloadDiffParts").
		Str("table", fmt.Sprintf("%s.%s", table.Database, table.Table)).
		Msg("start")
	start := time.Now()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	downloadedDiffBytes := int64(0)
	downloadedDiffParts := uint32(0)
	downloadDiffGroup, downloadDiffCtx := errgroup.WithContext(ctx)
	downloadDiffGroup.SetLimit(int(b.cfg.General.DownloadConcurrency))
	diffRemoteFilesCache := map[string]*sync.Mutex{}
	diffRemoteFilesLock := &sync.Mutex{}
	isRebalancedAfterHardLinks := false

	requiredBackup, err := b.ReadBackupMetadataRemote(ctx, remoteBackup.RequiredBackup)
	if err != nil {
		return 0, errors.Wrap(err, "ReadBackupMetadataRemote")
	}
	// https://github.com/Altinity/clickhouse-backup/issues/1373
	// tables created after the full backup have no Required parts; skip the
	// required-backup metadata fetch since it will fail with "not found".
	hasRequiredParts := false
	for _, diskParts := range table.Parts {
		for _, part := range diskParts {
			if part.Required {
				hasRequiredParts = true
				break
			}
		}
		if hasRequiredParts {
			break
		}
	}
	var requiredTable *metadata.TableMetadata
	if hasRequiredParts {
		requiredTable, err = b.downloadTableMetadataIfNotExists(ctx, requiredBackup.BackupName, metadata.TableTitle{Database: table.Database, Table: table.Table})
		if err != nil {
			log.Warn().Msgf("downloadTableMetadataIfNotExists %s / %s.%s return error", requiredBackup.BackupName, table.Database, table.Table)
			return 0, errors.Wrap(err, "downloadTableMetadataIfNotExists")
		}
	}

	for disk, parts := range table.Parts {
		diskPath, diskExists := b.DiskToPathMap[disk]
		for i, part := range parts {
			// Use per-iteration variable to avoid corrupting the outer loop variable
			activeDisk := disk
			activeDiskPath := diskPath
			if !diskExists && part.RebalancedDisk == "" {
				return 0, errors.Errorf("downloadDiffParts: table: `%s`.`%s`, disk: %s, part.Name: %s, part.RebalancedDisk: `%s` not rebalanced", table.Table, table.Database, disk, part.Name, part.RebalancedDisk)
			}
			if part.RebalancedDisk != "" {
				activeDiskPath, diskExists = b.DiskToPathMap[part.RebalancedDisk]
				if !diskExists {
					return 0, errors.Errorf("downloadDiffParts: table: `%s`.`%s`, disk: %s, part.Name: %s, part.RebalancedDisk: `%s` not rebalanced", table.Table, table.Database, disk, part.Name, part.RebalancedDisk)
				}
				activeDisk = part.RebalancedDisk
				if b.shouldDiskNameSkipByNameOrType(activeDisk, disks) {
					log.Warn().Str("database", table.Database).Str("table", table.Table).Str("rebalancedDisk", part.RebalancedDisk).Msg("skipped")
					continue
				}
			}
			newPath := path.Join(activeDiskPath, "backup", remoteBackup.BackupName, "shadow", dbAndTableDir, activeDisk, part.Name)
			if checkErr := b.checkNewPath(newPath, part); checkErr != nil {
				return 0, errors.Wrap(checkErr, "checkNewPath")
			}
			if !part.Required {
				continue
			}
			// existsPath must point at the active (rebalanced) disk because that's where
			// findDiffFileExist routes the source download for parts with RebalancedDisk set.
			// Using the original disk would yield a missing/relative path and produce a
			// cross-device hardlink later in makePartHardlinks.
			existsPath := path.Join(activeDiskPath, "backup", remoteBackup.RequiredBackup, "shadow", dbAndTableDir, activeDisk, part.Name)
			_, statErr := os.Stat(existsPath)
			if statErr != nil && !os.IsNotExist(statErr) {
				return 0, errors.Wrapf(statErr, "%s stat return error", existsPath)
			}
			if statErr != nil && os.IsNotExist(statErr) {
				//if existPath already processed then expect non-empty newPath
				if b.resume {
					isProcessed, pathDiffBytes, resumeErr := b.resumableState.IsAlreadyProcessed(existsPath)
					if resumeErr != nil {
						return 0, errors.Wrap(resumeErr, "resumableState.IsAlreadyProcessed")
					}
					if isProcessed {
						if newPathDirList, newPathDirErr := os.ReadDir(newPath); newPathDirErr != nil {
							newPathDirErr = errors.Wrapf(newPathDirErr, "os.ReadDir(%s) error", newPath)
							log.Error().Msg(newPathDirErr.Error())
							return 0, newPathDirErr
						} else if len(newPathDirList) == 0 {
							return 0, errors.Errorf("os.ReadDir(%s) unexpected empty", newPath)
						}
						downloadedDiffBytes += pathDiffBytes
						continue
					}
				}
				partForDownload := part
				// diskForDownload follows the active (rebalanced) disk so findDiffBackupFilesRemote
				// computes paths under the same physical disk as existsPath/newPath.
				diskForDownload := activeDisk
				capturedExistsPath := existsPath
				capturedNewPath := newPath
				// capturedDisk is the original map key for table.Parts; do not switch to activeDisk
				// or table.Parts[capturedDisk][idx] would index the wrong slice.
				capturedDisk := disk
				idx := i
				downloadDiffGroup.Go(func() error {
					if hardlinkExistsFiles {
						found, size, err := b.hardlinkIfLocalPartExistsAndChecksumEqual(remoteBackup.BackupName, table, &partForDownload, disks, capturedDisk, dbAndTableDir)
						if err != nil {
							return errors.Wrap(err, "hardlinkIfLocalPartExistsAndChecksumEqual")
						}
						if found {
							if partForDownload.RebalancedDisk != "" && partForDownload.RebalancedDisk != capturedDisk {
								table.Parts[capturedDisk][idx] = partForDownload
								isRebalancedAfterHardLinks = true
							}
							atomic.AddInt64(&downloadedDiffBytes, size)
							atomic.AddUint32(&downloadedDiffParts, 1)
							if b.resume {
								if err := b.resumableState.AppendToState(capturedExistsPath, size); err != nil {
									return errors.Wrap(err, "resumableState.AppendToState")
								}
							}
							return nil
						}
					}
					tableRemoteFiles, findErr := b.findDiffBackupFilesRemote(downloadDiffCtx, remoteBackup, requiredBackup, requiredTable, table, diskForDownload, partForDownload)
					if findErr != nil {
						return errors.Wrap(findErr, "findDiffBackupFilesRemote")
					}
					pathDiffBytes := int64(0)
					for tableRemoteFile, tableLocalDir := range tableRemoteFiles {
						fileDiffBytes, downloadErr := b.downloadDiffRemoteFile(downloadDiffCtx, diffRemoteFilesLock, diffRemoteFilesCache, tableRemoteFile, tableLocalDir)
						if downloadErr != nil {
							return errors.Wrap(downloadErr, "downloadDiffRemoteFile")
						}
						downloadedPartPath := path.Join(tableLocalDir, partForDownload.Name)
						if downloadedPartPath != capturedExistsPath {
							info, err := os.Stat(downloadedPartPath)
							if err == nil {
								if !info.IsDir() {
									return errors.Errorf("after downloadDiffRemoteFile %s exists but is not directory", downloadedPartPath)
								}
								if err = b.makePartHardlinks(downloadedPartPath, capturedExistsPath); err != nil {
									return errors.Wrapf(err, "can't to add link to rebalanced part %s -> %s error", downloadedPartPath, capturedExistsPath)
								}
							}
							if err != nil && !os.IsNotExist(err) {
								return errors.Wrapf(err, "after downloadDiffRemoteFile os.Stat(%s) return error", downloadedPartPath)
							}
						}
						pathDiffBytes += fileDiffBytes
						atomic.AddInt64(&downloadedDiffBytes, fileDiffBytes)
						atomic.AddUint32(&downloadedDiffParts, 1)
					}
					if err := b.makePartHardlinks(capturedExistsPath, capturedNewPath); err != nil {
						return errors.Wrapf(err, "can't to add link to exists part %s -> %s error", capturedNewPath, capturedExistsPath)
					}
					if b.resume {
						if err := b.resumableState.AppendToState(capturedExistsPath, pathDiffBytes); err != nil {
							return errors.Wrap(err, "resumableState.AppendToState")
						}
					}
					return nil
				})
			} else {
				existsAlreadyProcessed := false
				if b.resume {
					if existsAlreadyProcessed, statErr = b.resumableState.IsAlreadyProcessedBool(existsPath); statErr != nil {
						return 0, errors.Wrap(statErr, "resumableState.IsAlreadyProcessedBool")
					}
				}
				if !b.resume || !existsAlreadyProcessed {
					if statErr = b.makePartHardlinks(existsPath, newPath); statErr != nil {
						return 0, errors.Wrap(statErr, "can't to add exists part")
					}
				}
			}
		}
	}
	if err := downloadDiffGroup.Wait(); err != nil {
		return 0, errors.Wrap(err, "one of downloadDiffParts go-routine return error")
	}
	if isRebalancedAfterHardLinks {
		if _, saveErr := table.Save(table.LocalFile, false); saveErr != nil {
			return 0, errors.Wrap(saveErr, "save rebalanced table after hardlinks in downloadDiffParts")
		}
	}

	log.Info().
		Str("backup", remoteBackup.BackupName).
		Str("operation", "downloadDiffParts").
		Str("table", fmt.Sprintf("%s.%s", table.Database, table.Table)).
		Str("duration", utils.HumanizeDuration(time.Since(start))).
		Str("diff_parts", strconv.Itoa(int(downloadedDiffParts))).
		Str("diff_bytes", utils.FormatBytes(uint64(downloadedDiffBytes))).
		Msg("done")
	return downloadedDiffBytes, nil
}

func (b *Backuper) downloadDiffRemoteFile(ctx context.Context, diffRemoteFilesLock *sync.Mutex, diffRemoteFilesCache map[string]*sync.Mutex, tableRemoteFile string, tableLocalDir string) (int64, error) {
	if b.resume {
		isProcessed, downloadedBytes, resumeErr := b.resumableState.IsAlreadyProcessed(tableRemoteFile)
		if resumeErr != nil {
			return 0, errors.Wrap(resumeErr, "resumableState.IsAlreadyProcessed")
		}
		if isProcessed {
			return downloadedBytes, nil
		}
	}
	diffRemoteFilesLock.Lock()
	namedLock, isCached := diffRemoteFilesCache[tableRemoteFile]
	downloadedBytes := int64(0)
	if isCached {
		namedLock.Lock()
		log.Debug().Msgf("wait download begin %s", tableRemoteFile)
		diffRemoteFilesLock.Unlock()
		namedLock.Unlock()
		log.Debug().Msgf("wait download end %s", tableRemoteFile)
	} else {
		log.Debug().Msgf("start download from %s", tableRemoteFile)
		namedLock = &sync.Mutex{}
		diffRemoteFilesCache[tableRemoteFile] = namedLock
		namedLock.Lock()
		diffRemoteFilesLock.Unlock()
		if path.Ext(tableRemoteFile) != "" {
			retry := retrier.New(retrier.ExponentialBackoff(b.cfg.General.RetriesOnFailure, common.AddRandomJitter(b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter)), b)
			err := retry.RunCtx(ctx, func(ctx context.Context) error {
				var downloadErr error
				downloadedBytes, downloadErr = b.dst.DownloadCompressedStream(ctx, tableRemoteFile, tableLocalDir, b.cfg.General.DownloadMaxBytesPerSecond)
				return downloadErr
			})
			if err != nil {
				log.Warn().Msgf("DownloadCompressedStream %s -> %s return error: %v", tableRemoteFile, tableLocalDir, err)
				return 0, errors.Wrap(err, "DownloadCompressedStream")
			}
		} else {
			// remoteFile could be a directory
			if pathSize, err := b.dst.DownloadPath(ctx, tableRemoteFile, tableLocalDir, b.cfg.General.RetriesOnFailure, b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter, b, b.cfg.General.DownloadMaxBytesPerSecond); err != nil {
				log.Warn().Msgf("DownloadPath %s -> %s return error: %v", tableRemoteFile, tableLocalDir, err)
				return 0, errors.Wrap(err, "DownloadPath")
			} else {
				atomic.AddInt64(&downloadedBytes, pathSize)
			}
		}
		namedLock.Unlock()
		if b.resume {
			if err := b.resumableState.AppendToState(tableRemoteFile, downloadedBytes); err != nil {
				return 0, errors.Wrap(err, "resumableState.AppendToState")
			}
		}
		log.Debug().Str("tableRemoteFile", tableRemoteFile).Msgf("finish download")
	}
	return downloadedBytes, nil
}

func (b *Backuper) checkNewPath(newPath string, part metadata.Part) error {
	info, err := os.Stat(newPath)
	if err != nil && !os.IsNotExist(err) {
		return errors.Wrapf(err, "%s stat return error", newPath)
	}
	if os.IsNotExist(err) && !part.Required {
		return errors.Errorf("%s not found after download backup", newPath)
	}
	if err == nil && !info.IsDir() {
		return errors.Errorf("%s is not directory after download backup", newPath)
	}
	return nil
}

func (b *Backuper) findDiffBackupFilesRemote(ctx context.Context, backup metadata.BackupMetadata, requiredBackup *metadata.BackupMetadata, requiredTable *metadata.TableMetadata, table metadata.TableMetadata, disk string, part metadata.Part) (map[string]string, error) {
	log.Debug().Fields(map[string]interface{}{"database": table.Database, "table": table.Table, "part": part.Name, "logger": "findDiffBackupFilesRemote"}).Msg("start")
	var err error
	if requiredBackup == nil {
		requiredBackup, err = b.ReadBackupMetadataRemote(ctx, backup.RequiredBackup)
		if err != nil {
			return nil, errors.Wrap(err, "ReadBackupMetadataRemote")
		}
	}
	if requiredTable == nil {
		requiredTable, err = b.downloadTableMetadataIfNotExists(ctx, requiredBackup.BackupName, metadata.TableTitle{Database: table.Database, Table: table.Table})
		if err != nil {
			log.Warn().Msgf("downloadTableMetadataIfNotExists %s / %s.%s return error", requiredBackup.BackupName, table.Database, table.Table)
			return nil, errors.Wrap(err, "downloadTableMetadataIfNotExists")
		}
	}

	// recursive find if part in RequiredBackup also Required
	tableRemoteFiles, found, err := b.findDiffRecursive(ctx, requiredBackup, table, requiredTable, part, disk)
	if found {
		return tableRemoteFiles, nil
	}

	found = false
	// try to find part on the same disk
	tableRemoteFiles, err, found = b.findDiffOnePart(ctx, requiredBackup, table, disk, disk, part)
	if found {
		return tableRemoteFiles, nil
	}

	// try to find part on other disks
	for requiredDisk := range requiredBackup.Disks {
		if requiredDisk != disk {
			tableRemoteFiles, err, found = b.findDiffOnePart(ctx, requiredBackup, table, disk, requiredDisk, part)
			if found {
				return tableRemoteFiles, nil
			}
		}
	}
	// find one or multiple big files, disk_X.tar files by part.Name
	tableRemoteFiles = make(map[string]string)
	for requiredDisk, requiredParts := range requiredTable.Parts {
		for _, requiredPart := range requiredParts {
			if part.Name == requiredPart.Name {
				localTableDir := path.Join(b.DiskToPathMap[disk], "backup", requiredBackup.BackupName, "shadow", common.TablePathEncode(table.Database), common.TablePathEncode(table.Table), disk)
				for _, remoteFile := range requiredTable.Files[requiredDisk] {
					remoteFile = path.Join(requiredBackup.BackupName, "shadow", common.TablePathEncode(table.Database), common.TablePathEncode(table.Table), remoteFile)
					tableRemoteFiles[remoteFile] = localTableDir
				}
			}
		}
	}
	if len(tableRemoteFiles) > 0 {
		return tableRemoteFiles, nil
	}
	// not found
	return nil, errors.Errorf("%s.%s %s not found on %s and all required backups sequence", table.Database, table.Table, part.Name, requiredBackup.BackupName)
}

func (b *Backuper) findDiffRecursive(ctx context.Context, requiredBackup *metadata.BackupMetadata, table metadata.TableMetadata, requiredTable *metadata.TableMetadata, part metadata.Part, disk string) (map[string]string, bool, error) {
	log.Debug().Fields(map[string]interface{}{"database": table.Database, "table": table.Table, "part": part.Name, "logger": "findDiffRecursive"}).Msg("start")
	found := false
	for _, requiredParts := range requiredTable.Parts {
		for _, requiredPart := range requiredParts {
			if requiredPart.Name == part.Name {
				found = true
				if requiredPart.Required {
					// pass nil, nil to fetch the next level of the backup chain (requiredBackup.RequiredBackup)
					tableRemoteFiles, err := b.findDiffBackupFilesRemote(ctx, *requiredBackup, nil, nil, table, disk, part)
					if err != nil {
						found = false
						log.Warn().Msgf("try find %s.%s %s recursive return err: %v", table.Database, table.Table, part.Name, err)
					}
					return tableRemoteFiles, found, err
				}
				break
			}
		}
		if found {
			break
		}
	}
	return nil, false, nil
}

func (b *Backuper) findDiffOnePart(ctx context.Context, requiredBackup *metadata.BackupMetadata, table metadata.TableMetadata, localDisk, remoteDisk string, part metadata.Part) (map[string]string, error, bool) {
	log.Debug().Fields(map[string]interface{}{"database": table.Database, "table": table.Table, "part": part.Name, "logger": "findDiffOnePart"}).Msg("start")
	tableRemoteFiles := make(map[string]string)
	// find same disk and part name archive
	if requiredBackup.DataFormat != DirectoryFormat {
		if tableRemoteFile, tableLocalDir, err := b.findDiffOnePartArchive(ctx, requiredBackup, table, localDisk, remoteDisk, part); err == nil {
			tableRemoteFiles[tableRemoteFile] = tableLocalDir
			return tableRemoteFiles, nil, true
		}
	} else {
		// find same disk and part name directory
		if tableRemoteFile, tableLocalDir, err := b.findDiffOnePartDirectory(ctx, requiredBackup, table, localDisk, remoteDisk, part); err == nil {
			tableRemoteFiles[tableRemoteFile] = tableLocalDir
			return tableRemoteFiles, nil, true
		}
	}
	return nil, nil, false
}

func (b *Backuper) findDiffOnePartDirectory(ctx context.Context, requiredBackup *metadata.BackupMetadata, table metadata.TableMetadata, localDisk, remoteDisk string, part metadata.Part) (string, string, error) {
	log.Debug().Fields(map[string]interface{}{"database": table.Database, "table": table.Table, "part": part.Name, "logger": "findDiffOnePartDirectory"}).Msg("start")
	dbAndTableDir := path.Join(common.TablePathEncode(table.Database), common.TablePathEncode(table.Table))
	tableRemotePath := path.Join(requiredBackup.BackupName, "shadow", dbAndTableDir, remoteDisk, part.Name)
	tableRemoteFile := path.Join(tableRemotePath, "checksums.txt")
	return b.findDiffFileExist(ctx, requiredBackup, tableRemoteFile, tableRemotePath, localDisk, dbAndTableDir, part)
}

func (b *Backuper) findDiffOnePartArchive(ctx context.Context, requiredBackup *metadata.BackupMetadata, table metadata.TableMetadata, localDisk, remoteDisk string, part metadata.Part) (string, string, error) {
	log.Debug().Fields(map[string]interface{}{"database": table.Database, "table": table.Table, "part": part.Name, "logger": "findDiffOnePartArchive"}).Msg("start")
	dbAndTableDir := path.Join(common.TablePathEncode(table.Database), common.TablePathEncode(table.Table))
	remoteExt := config.ArchiveExtensions[requiredBackup.DataFormat]
	tableRemotePath := path.Join(requiredBackup.BackupName, "shadow", dbAndTableDir, fmt.Sprintf("%s_%s.%s", remoteDisk, common.TablePathEncode(part.Name), remoteExt))
	tableRemoteFile := tableRemotePath
	return b.findDiffFileExist(ctx, requiredBackup, tableRemoteFile, tableRemotePath, localDisk, dbAndTableDir, part)
}

func (b *Backuper) findDiffFileExist(ctx context.Context, requiredBackup *metadata.BackupMetadata, tableRemoteFile string, tableRemotePath string, localDisk string, dbAndTableDir string, part metadata.Part) (string, string, error) {
	_, err := b.dst.StatFile(ctx, tableRemoteFile)
	if err != nil {
		log.Debug().Fields(map[string]interface{}{"tableRemoteFile": tableRemoteFile, "tableRemotePath": tableRemotePath, "part": part.Name}).Msg("findDiffFileExist not found")
		return "", "", errors.Wrap(err, "StatFile")
	}
	tableLocalDir, diskExists := b.DiskToPathMap[localDisk]
	// Prioritize RebalancedDisk when set, so incremental diff files also
	// land on the correct rebalanced disk
	if part.RebalancedDisk != "" {
		tableLocalDir, diskExists = b.DiskToPathMap[part.RebalancedDisk]
		if !diskExists {
			return "", "", errors.Errorf("localDisk:%s, part.Name: %s, part.RebalancedDisk: %s is not found in system.disks", localDisk, part.Name, part.RebalancedDisk)
		}
		localDisk = part.RebalancedDisk
	} else if !diskExists {
		return "", "", errors.Errorf("localDisk:%s, part.Name: %s is not found in system.disks and not rebalanced", localDisk, part.Name)
	}

	if path.Ext(tableRemoteFile) == ".txt" {
		tableLocalDir = path.Join(tableLocalDir, "backup", requiredBackup.BackupName, "shadow", dbAndTableDir, localDisk, part.Name)
	} else {
		tableLocalDir = path.Join(tableLocalDir, "backup", requiredBackup.BackupName, "shadow", dbAndTableDir, localDisk)
	}
	log.Debug().Fields(map[string]interface{}{"tableRemoteFile": tableRemoteFile, "tableRemotePath": tableRemotePath, "part": part.Name}).Msg("findDiffFileExist found")
	return tableRemotePath, tableLocalDir, nil
}

func (b *Backuper) ReadBackupMetadataRemote(ctx context.Context, backupName string) (*metadata.BackupMetadata, error) {
	backupList, err := b.dst.BackupList(ctx, true, backupName)
	if err != nil {
		return nil, errors.Wrap(err, "BackupList")
	}
	for _, backup := range backupList {
		if backup.BackupName == backupName {
			// a Broken placeholder contains only BackupName, returning it would produce
			// confusing downstream errors about empty data_format/tables (e.g. a backup
			// being deleted or uploaded by a concurrent process)
			if backup.Broken != "" {
				return nil, errors.Errorf("%s is %s on remote storage", backupName, backup.Broken)
			}
			return &backup.BackupMetadata, nil
		}
	}
	return nil, errors.Errorf("%s not found on remote storage", backupName)
}

func (b *Backuper) makePartHardlinks(exists, new string) error {
	_, err := os.Stat(exists)
	if err != nil {
		return errors.Wrap(err, "Stat exists path")
	}
	if err = os.MkdirAll(new, 0750); err != nil {
		log.Warn().Msgf("MkDirAll(%s) error: %v", new, err)
		return errors.Wrap(err, "MkdirAll new path")
	}
	if walkErr := filepath.Walk(exists, func(fPath string, fInfo os.FileInfo, err error) error {
		if err != nil {
			return errors.Wrap(err, "walk hardlinks path")
		}
		fPath = strings.TrimPrefix(fPath, exists)
		existsF := path.Join(exists, fPath)
		newF := path.Join(new, fPath)
		if fInfo.IsDir() {
			if err = os.MkdirAll(newF, fInfo.Mode()); err != nil {
				log.Warn().Msgf("MkdirAll(%s) error: %v", fPath, err)
				return errors.Wrap(err, "MkdirAll in walk")
			}
			return nil
		}

		if err = os.Link(existsF, newF); err != nil {
			existsFInfo, existsStatErr := os.Stat(existsF)
			newFInfo, newStatErr := os.Stat(newF)
			if existsStatErr != nil || newStatErr != nil || !os.SameFile(existsFInfo, newFInfo) {
				log.Warn().Msgf("Link %s -> %s error: %v, existsStatErr: %v newStatErr: %v", existsF, newF, err, existsStatErr, newStatErr)
				return errors.Wrap(err, "Link in walk")
			}
		}
		if err = os.Chmod(newF, 0640); err != nil {
			return errors.Wrap(err, "Chmod in walk")
		}
		return nil
	}); walkErr != nil {
		log.Warn().Msgf("Link recursively %s -> %s return error: %v", new, exists, walkErr)
		return errors.Wrap(walkErr, "filepath.Walk")
	}
	return nil
}

func (b *Backuper) downloadSingleBackupFile(ctx context.Context, remoteFile string, localFile string, disks []clickhouse.Disk) (int64, error) {
	var size int64
	var isProcessed bool
	if b.resume {
		var resumeErr error
		if isProcessed, size, resumeErr = b.resumableState.IsAlreadyProcessed(remoteFile); resumeErr != nil {
			return 0, errors.Wrap(resumeErr, "resumableState.IsAlreadyProcessed")
		}
		if isProcessed {
			return size, nil
		}
	}
	retry := retrier.New(retrier.ExponentialBackoff(b.cfg.General.RetriesOnFailure, common.AddRandomJitter(b.cfg.General.RetriesDuration, b.cfg.General.RetriesJitter)), b)
	err := retry.RunCtx(ctx, func(ctx context.Context) error {
		remoteReader, err := b.dst.GetFileReader(ctx, remoteFile)
		if err != nil {
			return errors.Wrap(err, "GetFileReader")
		}
		defer func() {
			err = remoteReader.Close()
			if err != nil {
				log.Warn().Msgf("can't close remoteReader %s", remoteFile)
			}
		}()
		localWriter, err := os.OpenFile(localFile, os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0640)
		if err != nil {
			return errors.Wrap(err, "OpenFile localWriter")
		}

		defer func() {
			err = localWriter.Close()
			if err != nil {
				log.Warn().Msgf("can't close localWriter %s", localFile)
			}
		}()

		size, err = io.CopyBuffer(localWriter, remoteReader, nil)
		if err != nil {
			return errors.Wrap(err, "CopyBuffer")
		}

		if err = filesystemhelper.Chown(localFile, b.ch, disks, false); err != nil {
			return errors.Wrap(err, "Chown localFile")
		}
		return nil
	})
	if err != nil {
		return 0, errors.Wrap(err, "downloadSingleBackupFile")
	}
	if b.resume {
		if err = b.resumableState.AppendToState(remoteFile, size); err != nil {
			return 0, errors.Wrap(err, "resumableState.AppendToState")
		}
	}
	return size, nil
}

// filterDisksByStoragePolicyAndType - https://github.com/Altinity/clickhouse-backup/issues/561
func (b *Backuper) splitDisksByTypeAndStoragePolicy(disks []clickhouse.Disk) map[string]map[string][]clickhouse.Disk {
	disksByTypeAndPolicy := map[string]map[string][]clickhouse.Disk{}
	for _, d := range disks {
		if !d.IsBackup {
			if _, typeExists := disksByTypeAndPolicy[d.Type]; !typeExists {
				disksByTypeAndPolicy[d.Type] = map[string][]clickhouse.Disk{}
			}
			for _, policy := range d.StoragePolicies {
				if _, policyExists := disksByTypeAndPolicy[d.Type][policy]; !policyExists {
					disksByTypeAndPolicy[d.Type][policy] = []clickhouse.Disk{}
				}
				disksByTypeAndPolicy[d.Type][policy] = append(disksByTypeAndPolicy[d.Type][policy], d)
			}
		}
	}
	return disksByTypeAndPolicy
}

// getDownloadDiskForNonExistsDisk - https://github.com/Altinity/clickhouse-backup/issues/561
// allow to Restore to new server with different storage policy, different disk count,
// implements `least_used` for normal disk and `random` for Object disks
func (b *Backuper) getDownloadDiskForNonExistsDisk(notExistsDiskType string, filteredDisks []clickhouse.Disk, partSize uint64) (bool, string, uint64, error) {
	// random for non-local disks
	if notExistsDiskType != "local" {
		roundRobinIdx := rand.Intn(len(filteredDisks))
		return true, filteredDisks[roundRobinIdx].Name, 0, nil
	}
	// least_used for local
	freeSpace := partSize
	leastUsedIdx := -1
	for idx, d := range filteredDisks {
		if filteredDisks[idx].FreeSpace > freeSpace {
			freeSpace = d.FreeSpace
			leastUsedIdx = idx
		}
	}
	if leastUsedIdx < 0 {
		return false, "", 0, errors.Errorf("%s free space, not found in system.disks with `local` type", utils.FormatBytes(partSize))
	}
	return false, filteredDisks[leastUsedIdx].Name, filteredDisks[leastUsedIdx].FreeSpace - partSize, nil
}
