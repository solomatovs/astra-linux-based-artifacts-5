#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

GO_IMAGE="${GO_IMAGE:-golang:1.26-alpine}"
BORINGSSL_DIR="${BORINGSSL_DIR:-/tmp/boringssl}"
ACVP_TESTDATA_DIR="${ACVP_TESTDATA_DIR:-/tmp/acvp-testdata}"
BORINGSSL_COMMIT="${BORINGSSL_COMMIT:-baaf868e6e8f}"
ACVP_TESTDATA_COMMIT="${ACVP_TESTDATA_COMMIT:-d893de8b8b1c}"
CONFIG_PATH="${CONFIG_PATH:-/work/pkg/acvpwrapper/acvp_test_fips140v1.26.public.config.json}"
WRAPPER_BIN_PATH="${WRAPPER_BIN_PATH:-/work/.acvp/clickhouse-backup-acvp}"

echo "[1/4] Build ACVP wrapper binary"
docker run --rm \
  -v "${REPO_ROOT}:/work" \
  -w /work \
  "${GO_IMAGE}" \
  sh -lc "export PATH=\$PATH:/usr/local/go/bin && mkdir -p \"$(dirname "${WRAPPER_BIN_PATH}")\" && CGO_ENABLED=0 go build -o ${WRAPPER_BIN_PATH} ./cmd/clickhouse-backup"

echo "[2/4] Fetch pinned boringssl and acvp-testdata"
if [[ ! -d "${BORINGSSL_DIR}/.git" ]]; then
  rm -rf "${BORINGSSL_DIR}"
  git clone https://boringssl.googlesource.com/boringssl "${BORINGSSL_DIR}"
fi
git -C "${BORINGSSL_DIR}" fetch --all --tags
git -C "${BORINGSSL_DIR}" checkout "${BORINGSSL_COMMIT}"

if [[ ! -d "${ACVP_TESTDATA_DIR}/.git" ]]; then
  rm -rf "${ACVP_TESTDATA_DIR}"
  git clone https://github.com/geomys/acvp-testdata "${ACVP_TESTDATA_DIR}"
fi
git -C "${ACVP_TESTDATA_DIR}" fetch --all --tags
git -C "${ACVP_TESTDATA_DIR}" checkout "${ACVP_TESTDATA_COMMIT}"

echo "[3/4] Build pinned acvptool"
docker run --rm \
  -v "${BORINGSSL_DIR}:/src" \
  -w /src \
  "${GO_IMAGE}" \
  sh -lc 'export PATH=$PATH:/usr/local/go/bin && go build -o /src/acvptool-pinned ./util/fipstools/acvp/acvptool'

echo "[4/4] Run ACVP expected-output check"
docker run --rm \
  -e ACVP_WRAPPER=1 \
  -e GODEBUG=fips140=on \
  -v "${REPO_ROOT}:/work" \
  -v "${BORINGSSL_DIR}:/tmp/boringssl:ro" \
  -v "${ACVP_TESTDATA_DIR}:/tmp/acvp-testdata:rw" \
  -w /tmp/acvp-testdata \
  "${GO_IMAGE}" \
  sh -lc "export PATH=\$PATH:/usr/local/go/bin && go run /tmp/boringssl/util/fipstools/acvp/acvptool/test/check_expected.go -tool /tmp/boringssl/acvptool-pinned -module-wrappers go:${WRAPPER_BIN_PATH} -tests ${CONFIG_PATH}"
