package storage

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"hash/crc32"
	"io"
	"net/http"
	"net/url"
	"os"
	"path"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/Altinity/clickhouse-backup/v2/pkg/config"
	"github.com/aws/aws-sdk-go-v2/aws"
	v4 "github.com/aws/aws-sdk-go-v2/aws/signer/v4"
	awsV2Config "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/credentials/stscreds"
	"github.com/aws/aws-sdk-go-v2/feature/s3/transfermanager"
	tmtypes "github.com/aws/aws-sdk-go-v2/feature/s3/transfermanager/types"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	s3types "github.com/aws/aws-sdk-go-v2/service/s3/types"
	"github.com/aws/aws-sdk-go-v2/service/sts"
	"github.com/aws/smithy-go"
	smithyendpoints "github.com/aws/smithy-go/endpoints"
	awsV2Logging "github.com/aws/smithy-go/logging"
	"github.com/aws/smithy-go/middleware"
	smithyhttp "github.com/aws/smithy-go/transport/http"
	"github.com/pkg/errors"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"golang.org/x/sync/errgroup"
)

type S3LogToZeroLogAdapter struct {
	logger zerolog.Logger
}

func newS3Logger(logger zerolog.Logger) S3LogToZeroLogAdapter {
	return S3LogToZeroLogAdapter{
		logger: logger,
	}
}

func (adapter S3LogToZeroLogAdapter) Logf(severity awsV2Logging.Classification, msg string, args ...interface{}) {
	msg = fmt.Sprintf("[s3:%s] %s", severity, msg)
	if len(args) > 0 {
		adapter.logger.Info().Msgf(msg, args...)
	} else {
		adapter.logger.Info().Msg(msg)
	}
}

// RecalculateV4Signature allow GCS over S3, remove Accept-Encoding header from sign https://stackoverflow.com/a/74382598/1204665, https://github.com/aws/aws-sdk-go-v2/issues/1816
type RecalculateV4Signature struct {
	next      http.RoundTripper
	signer    *v4.Signer
	awsConfig aws.Config
}

func (lt *RecalculateV4Signature) RoundTrip(req *http.Request) (*http.Response, error) {
	// store for later use
	acceptEncodingValue := req.Header.Get("Accept-Encoding")

	// delete the header so the header doesn't account for in the signature
	req.Header.Del("Accept-Encoding")

	// sign with the same date
	timeString := req.Header.Get("X-Amz-Date")
	timeDate, _ := time.Parse("20060102T150405Z", timeString)

	creds, err := lt.awsConfig.Credentials.Retrieve(req.Context())
	if err != nil {
		return nil, err
	}
	err = lt.signer.SignHTTP(req.Context(), creds, req, v4.GetPayloadHash(req.Context()), "s3", lt.awsConfig.Region, timeDate)
	if err != nil {
		return nil, err
	}
	// Reset Accept-Encoding if desired
	req.Header.Set("Accept-Encoding", acceptEncodingValue)

	// follows up the original round tripper
	return lt.next.RoundTrip(req)
}

// S3 - presents methods for manipulate data on s3
type S3 struct {
	client          *s3.Client
	transferManager *transfermanager.Client
	Config          *config.S3Config
	Concurrency     int
	versioning      bool
}

func (s *S3) Kind() string {

	return "S3"
}

func (s *S3) ResolveEndpoint(ctx context.Context, params s3.EndpointParameters) (endpoint smithyendpoints.Endpoint, err error) {
	baseResolver := s3.NewDefaultEndpointResolverV2()
	if s.Config.Endpoint != "" {
		params.Endpoint = &s.Config.Endpoint
	}
	params.ForcePathStyle = &s.Config.ForcePathStyle

	resolvedEndpoint, err := baseResolver.ResolveEndpoint(ctx, params)
	if err != nil {
		return resolvedEndpoint, errors.Wrap(err, "S3 ResolveEndpoint")
	}
	return resolvedEndpoint, nil
}

// Connect - connect to s3
func (s *S3) Connect(ctx context.Context) error {
	var err error
	var awsConfig aws.Config
	awsConfig, err = awsV2Config.LoadDefaultConfig(
		ctx,
		awsV2Config.WithRetryMode(aws.RetryModeAdaptive),
	)
	if err != nil {
		return errors.Wrap(err, "S3 Connect LoadDefaultConfig")
	}
	if s.Config.Region != "" {
		awsConfig.Region = s.Config.Region
	}
	// AWS IRSA handling, look https://github.com/Altinity/clickhouse-backup/issues/798
	awsRoleARN := os.Getenv("AWS_ROLE_ARN")
	awsWebIdentityTokenFile := os.Getenv("AWS_WEB_IDENTITY_TOKEN_FILE")
	stsClient := sts.NewFromConfig(awsConfig)
	if awsRoleARN != "" && awsWebIdentityTokenFile != "" {
		awsConfig.Credentials = stscreds.NewWebIdentityRoleProvider(
			stsClient, awsRoleARN, stscreds.IdentityTokenFile(awsWebIdentityTokenFile),
		)
		// inherit IRSA and try to assume role https://github.com/Altinity/clickhouse-backup/issues/1191
		if s.Config.AssumeRoleARN != "" && s.Config.AssumeRoleARN != awsRoleARN {
			awsConfig.Credentials = aws.NewCredentialsCache(awsConfig.Credentials)
			stsClient = sts.NewFromConfig(awsConfig)
			awsConfig.Credentials = stscreds.NewAssumeRoleProvider(stsClient, s.Config.AssumeRoleARN)
		}
	} else if s.Config.AssumeRoleARN != "" {
		// backup role S3_ASSUME_ROLE_ARN have high priority than AWS_ROLE_ARN see https://github.com/Altinity/clickhouse-backup/issues/898
		awsConfig.Credentials = stscreds.NewAssumeRoleProvider(stsClient, s.Config.AssumeRoleARN)
	} else if awsRoleARN != "" {
		awsConfig.Credentials = stscreds.NewAssumeRoleProvider(stsClient, awsRoleARN)
	}

	if s.Config.AccessKey != "" && s.Config.SecretKey != "" {
		awsConfig.Credentials = credentials.StaticCredentialsProvider{
			Value: aws.Credentials{
				AccessKeyID:     s.Config.AccessKey,
				SecretAccessKey: s.Config.SecretKey,
			},
		}
	}

	if awsConfig.Credentials != nil {
		awsConfig.Credentials = aws.NewCredentialsCache(awsConfig.Credentials)
	}

	if s.Config.Debug {
		awsConfig.Logger = newS3Logger(log.Logger)
		awsConfig.ClientLogMode = aws.LogRetries | aws.LogRequest | aws.LogResponse
		if os.Getenv("S3_DEBUG_BODY") != "" {
			awsConfig.ClientLogMode = aws.LogRetries | aws.LogRequest | aws.LogResponse | aws.LogRequestWithBody | aws.LogResponseWithBody
		}
	}

	httpTransport := http.DefaultTransport
	// Build a custom HTTP transport only when cert verification is disabled or any HTTP tuning
	// knob is set, otherwise keep the AWS SDK default transport untouched.
	// See https://github.com/Altinity/clickhouse-backup/issues/1376
	needCustomTransport := s.Config.DisableCertVerification ||
		s.Config.HTTPMaxIdleConns > 0 || s.Config.HTTPMaxIdleConnsPerHost > 0 ||
		s.Config.HTTPMaxConnsPerHost > 0 || s.Config.HTTPWriteBufferSize > 0 ||
		s.Config.HTTPReadBufferSize > 0 || s.Config.HTTPIdleConnTimeout != ""
	if needCustomTransport {
		customTransport := http.DefaultTransport.(*http.Transport).Clone()
		if s.Config.DisableCertVerification {
			customTransport.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
		}
		if s.Config.HTTPMaxIdleConns > 0 {
			customTransport.MaxIdleConns = s.Config.HTTPMaxIdleConns
		}
		if s.Config.HTTPMaxIdleConnsPerHost > 0 {
			customTransport.MaxIdleConnsPerHost = s.Config.HTTPMaxIdleConnsPerHost
		}
		if s.Config.HTTPMaxConnsPerHost > 0 {
			customTransport.MaxConnsPerHost = s.Config.HTTPMaxConnsPerHost
		}
		if s.Config.HTTPWriteBufferSize > 0 {
			customTransport.WriteBufferSize = s.Config.HTTPWriteBufferSize
		}
		if s.Config.HTTPReadBufferSize > 0 {
			customTransport.ReadBufferSize = s.Config.HTTPReadBufferSize
		}
		if s.Config.HTTPIdleConnTimeout != "" {
			// already validated in config.ValidateConfig
			if d, parseErr := time.ParseDuration(s.Config.HTTPIdleConnTimeout); parseErr == nil {
				customTransport.IdleConnTimeout = d
			}
		}
		httpTransport = customTransport
		awsConfig.HTTPClient = &http.Client{Transport: httpTransport}
	}

	// The aws-sdk default (WhenSupported) adds an aws-chunked flexible-checksum trailer to streaming (unseekable) uploads.
	// Non-AWS S3-compatible providers reject it ("aws-chunked encoding is not supported...", GCS SignatureDoesNotMatch via
	// RecalculateV4Signature). Only emit a checksum when the user explicitly configures one via s3.CheckSumAlgorithm.
	awsConfig.RequestChecksumCalculation = aws.RequestChecksumCalculationWhenRequired
	awsConfig.ResponseChecksumValidation = aws.ResponseChecksumValidationWhenRequired

	// allow GCS over S3, remove Accept-Encoding header from sign https://stackoverflow.com/a/74382598/1204665, https://github.com/aws/aws-sdk-go-v2/issues/1816
	if strings.Contains(s.Config.Endpoint, "storage.googleapis.com") {
		// Assign custom client with our own transport
		awsConfig.HTTPClient = &http.Client{Transport: &RecalculateV4Signature{httpTransport, v4.NewSigner(func(signer *v4.SignerOptions) {
			signer.DisableURIPathEscaping = true
		}), awsConfig}}
	}
	s.client = s3.NewFromConfig(awsConfig, func(o *s3.Options) {
		o.UsePathStyle = s.Config.ForcePathStyle
		o.EndpointOptions.DisableHTTPS = s.Config.DisableSSL
		o.EndpointResolverV2 = s
	})

	// transferManager wraps the configured client, inheriting endpoint resolver, path-style and the GCS signature transport.
	// transfermanager.Options.RequestChecksumCalculation is a separate field from the S3 client's awsConfig one set above
	// aws-sdk-go-v2/feature/s3/transfermanager v0.3.1+ computes the checksum algorithm dynamically per call and defaults
	// to WhenSupported, forcing CRC32 regardless of ChecksumAlgorithm overrides, unless set to WhenRequired here too.
	s.transferManager = transfermanager.New(s.client, func(o *transfermanager.Options) {
		o.Concurrency = s.Concurrency
		o.RequestChecksumCalculation = aws.RequestChecksumCalculationWhenRequired
	})

	s.versioning = s.isVersioningEnabled(ctx)

	return nil
}

func (s *S3) Close(_ context.Context) error {
	return nil
}

func (s *S3) GetFileReader(ctx context.Context, key string) (io.ReadCloser, error) {
	return s.GetFileReaderAbsolute(ctx, path.Join(s.Config.Path, key))
}

func (s *S3) GetFileReaderAbsolute(ctx context.Context, key string) (io.ReadCloser, error) {
	params := &s3.GetObjectInput{
		Bucket: aws.String(s.Config.Bucket),
		Key:    aws.String(key),
	}
	s.enrichGetObjectParams(params)
	resp, err := s.client.GetObject(ctx, params)
	if err != nil {
		var opError *smithy.OperationError
		if errors.As(err, &opError) {
			var httpErr *smithyhttp.ResponseError
			if errors.As(opError.Err, &httpErr) {
				var stateErr *s3types.InvalidObjectState
				if errors.As(httpErr, &stateErr) {
					if strings.Contains(string(stateErr.StorageClass), "GLACIER") {
						log.Warn().Msgf("GetFileReader %s, storageClass %s receive error: %s", key, stateErr.StorageClass, stateErr.Error())
						if restoreErr := s.restoreObject(ctx, key); restoreErr != nil {
							log.Warn().Msgf("restoreObject %s, return error: %v", key, restoreErr)
							return nil, errors.Wrap(err, "S3 GetFileReaderAbsolute GLACIER restore")
						}
						if resp, err = s.client.GetObject(ctx, params); err != nil {
							log.Warn().Msgf("second GetObject %s, return error: %v", key, err)
							return nil, errors.Wrap(err, "S3 GetFileReaderAbsolute second GetObject")
						}
						return resp.Body, nil
					}
				}
			}
			return nil, errors.Wrap(err, "S3 GetFileReaderAbsolute")
		}
		return nil, errors.Wrap(err, "S3 GetFileReaderAbsolute")
	}
	return resp.Body, nil
}

// s3SSECustomerParams holds the SSE-C fields shared by every S3 request that accepts them
// (GetObject, HeadObject, PutObject, CreateMultipartUpload, CopyObject).
type s3SSECustomerParams struct {
	SSECustomerAlgorithm *string
	SSECustomerKey       *string
	SSECustomerKeyMD5    *string
}

func (s *S3) sseCustomerParams() s3SSECustomerParams {
	p := s3SSECustomerParams{}
	if s.Config.SSECustomerAlgorithm != "" {
		p.SSECustomerAlgorithm = aws.String(s.Config.SSECustomerAlgorithm)
	}
	if s.Config.SSECustomerKey != "" {
		p.SSECustomerKey = aws.String(s.Config.SSECustomerKey)
	}
	if s.Config.SSECustomerKeyMD5 != "" {
		p.SSECustomerKeyMD5 = aws.String(s.Config.SSECustomerKeyMD5)
	}
	return p
}

func (s *S3) requestPayer() s3types.RequestPayer {
	if s.Config.RequestPayer != "" {
		return s3types.RequestPayer(s.Config.RequestPayer)
	}
	return ""
}

func (s *S3) enrichGetObjectParams(params *s3.GetObjectInput) {
	sse := s.sseCustomerParams()
	params.SSECustomerAlgorithm = sse.SSECustomerAlgorithm
	params.SSECustomerKey = sse.SSECustomerKey
	params.SSECustomerKeyMD5 = sse.SSECustomerKeyMD5
	params.RequestPayer = s.requestPayer()
}

// calculatePartSize derives the multipart chunk size for a transfer of fullSize bytes,
// honoring the configured ChunkSize/MaxPartsCount and clamping to [minPartSize, 5GB].
func (s *S3) calculatePartSize(fullSize, minPartSize int64) int64 {
	var partSize int64
	if s.Config.ChunkSize > 0 && (fullSize+s.Config.ChunkSize-1)/s.Config.ChunkSize < s.Config.MaxPartsCount {
		// Use configured chunk size
		partSize = s.Config.ChunkSize
	} else {
		partSize = fullSize / s.Config.MaxPartsCount
		if fullSize%s.Config.MaxPartsCount > 0 {
			partSize += max(1, (fullSize%s.Config.MaxPartsCount)/s.Config.MaxPartsCount)
		}
	}
	return AdjustValueByRange(partSize, minPartSize, 5*1024*1024*1024)
}

func (s *S3) GetFileReaderWithLocalPath(ctx context.Context, key, localPath string, remoteSize int64) (io.ReadCloser, error) {
	/* unfortunately, multipart download require allocate additional disk space
	and don't allow us to decompress data directly from stream */
	if s.Config.AllowMultipartDownload {
		writer, err := os.CreateTemp(localPath, strings.ReplaceAll(key, "/", "_"))
		if err != nil {
			return nil, errors.Wrap(err, "S3 GetFileReaderWithLocalPath CreateTemp")
		}

		partSize := s.calculatePartSize(remoteSize, 5*1024*1024)

		_, err = s.transferManager.DownloadObject(ctx, &transfermanager.DownloadObjectInput{
			Bucket:   aws.String(s.Config.Bucket),
			Key:      aws.String(path.Join(s.Config.Path, key)),
			WriterAt: writer,
		}, func(o *transfermanager.Options) {
			o.Concurrency = s.Concurrency
			o.PartSizeBytes = partSize
		})
		if err != nil {
			return nil, errors.Wrap(err, "S3 GetFileReaderWithLocalPath Download")
		}
		return writer, nil
	}

	return s.GetFileReader(ctx, key)
}

func (s *S3) PutFile(ctx context.Context, key string, r io.ReadCloser, localSize int64) error {
	return s.PutFileAbsolute(ctx, path.Join(s.Config.Path, key), r, localSize)
}

// s3CommonObjectParams holds the config-derived fields shared by S3 write operations
// (PutObject, CreateMultipartUpload) to avoid duplicating the same enrichment logic per call site.
type s3CommonObjectParams struct {
	ChecksumAlgorithm       s3types.ChecksumAlgorithm
	ACL                     s3types.ObjectCannedACL
	Tagging                 *string
	ServerSideEncryption    s3types.ServerSideEncryption
	SSEKMSKeyId             *string
	SSECustomerAlgorithm    *string
	SSECustomerKey          *string
	SSECustomerKeyMD5       *string
	SSEKMSEncryptionContext *string
	RequestPayer            s3types.RequestPayer
}

func (s *S3) commonObjectParams() s3CommonObjectParams {
	p := s3CommonObjectParams{}
	if s.Config.CheckSumAlgorithm != "" {
		p.ChecksumAlgorithm = s3types.ChecksumAlgorithm(s.Config.CheckSumAlgorithm)
	}
	// ACL shall be optional, fix https://github.com/Altinity/clickhouse-backup/issues/785
	if s.Config.ACL != "" {
		p.ACL = s3types.ObjectCannedACL(s.Config.ACL)
	}
	// https://github.com/Altinity/clickhouse-backup/issues/588
	if len(s.Config.ObjectLabels) > 0 {
		tags := ""
		for k, v := range s.Config.ObjectLabels {
			if tags != "" {
				tags += "&"
			}
			tags += k + "=" + v
		}
		p.Tagging = aws.String(tags)
	}
	if s.Config.SSE != "" {
		p.ServerSideEncryption = s3types.ServerSideEncryption(s.Config.SSE)
	}
	if s.Config.SSEKMSKeyId != "" {
		p.SSEKMSKeyId = aws.String(s.Config.SSEKMSKeyId)
	}
	sse := s.sseCustomerParams()
	p.SSECustomerAlgorithm = sse.SSECustomerAlgorithm
	p.SSECustomerKey = sse.SSECustomerKey
	p.SSECustomerKeyMD5 = sse.SSECustomerKeyMD5
	if s.Config.SSEKMSEncryptionContext != "" {
		p.SSEKMSEncryptionContext = aws.String(s.Config.SSEKMSEncryptionContext)
	}
	p.RequestPayer = s.requestPayer()
	return p
}

func (s *S3) PutFileAbsolute(ctx context.Context, key string, r io.ReadCloser, localSize int64) error {
	common := s.commonObjectParams()
	params := s3.PutObjectInput{
		Bucket:                  aws.String(s.Config.Bucket),
		Key:                     aws.String(key),
		Body:                    r,
		StorageClass:            s3types.StorageClass(strings.ToUpper(s.Config.StorageClass)),
		ChecksumAlgorithm:       common.ChecksumAlgorithm,
		ACL:                     common.ACL,
		Tagging:                 common.Tagging,
		ServerSideEncryption:    common.ServerSideEncryption,
		SSEKMSKeyId:             common.SSEKMSKeyId,
		SSECustomerAlgorithm:    common.SSECustomerAlgorithm,
		SSECustomerKey:          common.SSECustomerKey,
		SSECustomerKeyMD5:       common.SSECustomerKeyMD5,
		SSEKMSEncryptionContext: common.SSEKMSEncryptionContext,
		RequestPayer:            common.RequestPayer,
	}
	partSize := s.calculatePartSize(localSize, 5*1024*1024)

	// transfermanager.UploadObject sends the part checksum as a trailer, which S3 Object Lock rejects on UploadPart. Fall back to manual multipart with per-part x-amz-checksum-crc32 header, fix https://github.com/Altinity/clickhouse-backup/issues/829
	if s.Config.CheckSumAlgorithm == string(s3types.ChecksumAlgorithmCrc32) && localSize > partSize {
		return s.putFileMultipartCRC32(ctx, s.client, &params, r, localSize, partSize)
	}

	uploadInput := &transfermanager.UploadObjectInput{
		Bucket:                  params.Bucket,
		Key:                     params.Key,
		Body:                    r,
		StorageClass:            tmtypes.StorageClass(params.StorageClass),
		ACL:                     tmtypes.ObjectCannedACL(params.ACL),
		Tagging:                 params.Tagging,
		ServerSideEncryption:    tmtypes.ServerSideEncryption(params.ServerSideEncryption),
		SSEKMSKeyID:             params.SSEKMSKeyId,
		SSEKMSEncryptionContext: params.SSEKMSEncryptionContext,
		SSECustomerAlgorithm:    params.SSECustomerAlgorithm,
		SSECustomerKey:          params.SSECustomerKey,
		SSECustomerKeyMD5:       params.SSECustomerKeyMD5,
		ChecksumAlgorithm:       tmtypes.ChecksumAlgorithm(params.ChecksumAlgorithm),
		RequestPayer:            tmtypes.RequestPayer(s.Config.RequestPayer),
	}
	if _, err := s.transferManager.UploadObject(ctx, uploadInput, func(o *transfermanager.Options) {
		o.PartSizeBytes = partSize
		o.MultipartUploadThreshold = partSize
		// transfermanager forces ChecksumAlgorithm=CRC32 at New(); honor only the configured algorithm instead.
		// Empty means no explicit checksum, leaving it to the client RequestChecksumCalculation policy (WhenRequired),
		// which avoids the aws-chunked checksum trailer that non-AWS S3-compatible providers reject.
		o.ChecksumAlgorithm = tmtypes.ChecksumAlgorithm(s.Config.CheckSumAlgorithm)
	}); err != nil {
		return errors.Wrap(err, "S3 PutFileAbsolute Upload")
	}
	return nil
}

// s3MultipartAPI is the subset of *s3.Client used by putFileMultipartCRC32, extracted for unit testing
type s3MultipartAPI interface {
	CreateMultipartUpload(ctx context.Context, params *s3.CreateMultipartUploadInput, optFns ...func(*s3.Options)) (*s3.CreateMultipartUploadOutput, error)
	UploadPart(ctx context.Context, params *s3.UploadPartInput, optFns ...func(*s3.Options)) (*s3.UploadPartOutput, error)
	CompleteMultipartUpload(ctx context.Context, params *s3.CompleteMultipartUploadInput, optFns ...func(*s3.Options)) (*s3.CompleteMultipartUploadOutput, error)
	AbortMultipartUpload(ctx context.Context, params *s3.AbortMultipartUploadInput, optFns ...func(*s3.Options)) (*s3.AbortMultipartUploadOutput, error)
}

func (s *S3) putFileMultipartCRC32(ctx context.Context, s3MultipartAPIClient s3MultipartAPI, putParams *s3.PutObjectInput, r io.Reader, localSize, partSize int64) error {
	createParams := &s3.CreateMultipartUploadInput{
		Bucket:       putParams.Bucket,
		Key:          putParams.Key,
		StorageClass: putParams.StorageClass,
	}
	s.enrichCreateMultipartUploadParams(createParams)

	initResp, err := s3MultipartAPIClient.CreateMultipartUpload(ctx, createParams)
	if err != nil {
		return errors.Wrap(err, "S3 putFileMultipartCRC32 CreateMultipartUpload")
	}
	uploadID := initResp.UploadId

	abort := func(cause error) error {
		abortParams := &s3.AbortMultipartUploadInput{
			Bucket:   putParams.Bucket,
			Key:      putParams.Key,
			UploadId: uploadID,
		}
		if s.Config.RequestPayer != "" {
			abortParams.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
		}
		if _, abortErr := s3MultipartAPIClient.AbortMultipartUpload(context.Background(), abortParams); abortErr != nil {
			return errors.Wrapf(cause, "aborting putFileMultipartCRC32 multipart upload: %v, original error was", abortErr)
		}
		return cause
	}

	// localSize is only a capacity hint: for compressed streams UploadCompressedStream declares the
	// sum of raw file sizes, while the actual tar stream is larger (headers/padding/trailer), so read
	// until EOF instead of stopping at localSize, fix https://github.com/Altinity/clickhouse-backup/issues/1471
	buf := make([]byte, partSize)
	parts := make([]s3types.CompletedPart, 0, (localSize+partSize-1)/partSize)
	var partNumber int32 = 1
	for {
		n, readErr := io.ReadFull(r, buf)
		if readErr != nil && readErr != io.EOF && readErr != io.ErrUnexpectedEOF {
			return abort(errors.Wrapf(readErr, "S3 putFileMultipartCRC32 read part=%d", partNumber))
		}
		if n > 0 {
			h := crc32.NewIEEE()
			if _, writeErr := h.Write(buf[:n]); writeErr != nil {
				return errors.Wrapf(writeErr, "S3 putFileMultipartCRC32 write part=%d", partNumber)
			}
			uploadParams := &s3.UploadPartInput{
				Bucket:            putParams.Bucket,
				Key:               putParams.Key,
				UploadId:          uploadID,
				PartNumber:        aws.Int32(partNumber),
				Body:              bytes.NewReader(buf[:n]),
				ChecksumAlgorithm: s3types.ChecksumAlgorithmCrc32,
				ChecksumCRC32:     aws.String(base64.StdEncoding.EncodeToString(h.Sum(nil))),
			}
			if s.Config.RequestPayer != "" {
				uploadParams.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
			}
			partResp, uploadErr := s3MultipartAPIClient.UploadPart(ctx, uploadParams)
			if uploadErr != nil {
				return abort(errors.Wrapf(uploadErr, "S3 putFileMultipartCRC32 UploadPart part=%d", partNumber))
			}
			parts = append(parts, s3types.CompletedPart{
				ETag:          partResp.ETag,
				PartNumber:    aws.Int32(partNumber),
				ChecksumCRC32: partResp.ChecksumCRC32,
			})
			partNumber++
		}
		if readErr != nil {
			break
		}
	}

	if _, completeErr := s3MultipartAPIClient.CompleteMultipartUpload(ctx, &s3.CompleteMultipartUploadInput{
		Bucket:          putParams.Bucket,
		Key:             putParams.Key,
		UploadId:        uploadID,
		MultipartUpload: &s3types.CompletedMultipartUpload{Parts: parts},
	}); completeErr != nil {
		return abort(errors.Wrap(completeErr, "S3 putFileMultipartCRC32 CompleteMultipartUpload"))
	}
	return nil
}

func (s *S3) deleteKey(ctx context.Context, key string) error {
	params := &s3.DeleteObjectInput{
		Bucket: aws.String(s.Config.Bucket),
		Key:    aws.String(key),
	}
	if s.Config.RequestPayer != "" {
		params.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
	}
	if s.versioning {
		identifiers, err := s.getObjectAllVersions(ctx, key)
		if err != nil {
			return errors.Wrapf(err, "deleteKey, obtaining object version bucket: %s key: %s", s.Config.Bucket, key)
		}
		for _, id := range identifiers {
			params.VersionId = id.VersionId
			if _, err := s.client.DeleteObject(ctx, params); err != nil {
				return errors.Wrapf(err, "deleteKey, deleting object bucket: %s key: %s version: %v", s.Config.Bucket, key, params.VersionId)
			}
		}
		// Either we drained all versions+markers, or there was nothing to delete.
		// In both cases avoid a key-only DeleteObject which would create a fresh delete-marker.
		return nil
	}
	if _, err := s.client.DeleteObject(ctx, params); err != nil {
		return errors.Wrapf(err, "deleteKey, deleting object bucket: %s key: %s version: %v", s.Config.Bucket, key, params.VersionId)
	}
	return nil
}

func (s *S3) DeleteFile(ctx context.Context, key string) error {
	key = path.Join(s.Config.Path, key)
	return s.deleteKey(ctx, key)
}

func (s *S3) DeleteFileFromObjectDiskBackup(ctx context.Context, key string) error {
	key = path.Join(s.Config.ObjectDiskPath, key)
	return s.deleteKey(ctx, key)
}

// DeleteKeysBatch implements BatchDeleter interface for S3
// Uses DeleteObjects API to delete up to 1000 keys per request
func (s *S3) DeleteKeysBatch(ctx context.Context, keys []string) error {
	if len(keys) == 0 {
		return nil
	}
	// Prepend path to all keys
	fullKeys := make([]string, len(keys))
	for i, key := range keys {
		fullKeys[i] = path.Join(s.Config.Path, key)
	}
	return s.deleteKeys(ctx, fullKeys)
}

// DeleteKeysFromObjectDiskBackupBatch implements BatchDeleter interface for S3
func (s *S3) DeleteKeysFromObjectDiskBackupBatch(ctx context.Context, keys []string) error {
	if len(keys) == 0 {
		return nil
	}
	// Prepend object disk path to all keys
	fullKeys := make([]string, len(keys))
	for i, key := range keys {
		fullKeys[i] = path.Join(s.Config.ObjectDiskPath, key)
	}
	return s.deleteKeys(ctx, fullKeys)
}

// deleteKeys performs batch deletion using DeleteObjects API
// Uses S3Config.DeleteConcurrency for parallel version listing (for versioned buckets)
// AWS S3 DeleteObjects API limit is 1000 keys per request
func (s *S3) deleteKeys(ctx context.Context, keys []string) error {
	const maxBatchSize = 1000 // AWS S3 limit
	concurrency := s.Config.DeleteConcurrency

	// Build list of objects to delete, handling versioning
	var objectsToDelete []s3types.ObjectIdentifier
	if s.versioning {
		// For versioned buckets, we need to get all versions of each key
		// Use concurrency for version listing
		g, ctx := errgroup.WithContext(ctx)
		g.SetLimit(concurrency)
		var mu sync.Mutex

		for _, key := range keys {
			key := key
			g.Go(func() error {
				identifiers, err := s.getObjectAllVersions(ctx, key)
				if err != nil {
					// If we can't list versions, try deleting without version ID
					log.Warn().Msgf("S3 deleteKeys: can't get versions for %s: %v, will try without version", key, err)
					mu.Lock()
					objectsToDelete = append(objectsToDelete, s3types.ObjectIdentifier{
						Key: aws.String(key),
					})
					mu.Unlock()
					return nil
				}
				if len(identifiers) == 0 {
					// Already absent (e.g. retry of an earlier successful delete).
					// Skip — issuing a key-only delete here would create a new delete-marker.
					return nil
				}
				mu.Lock()
				objectsToDelete = append(objectsToDelete, identifiers...)
				mu.Unlock()
				return nil
			})
		}
		if err := g.Wait(); err != nil {
			return errors.Wrap(err, "S3 deleteKeys version listing")
		}
	} else {
		// Non-versioned: simple key list
		for _, key := range keys {
			objectsToDelete = append(objectsToDelete, s3types.ObjectIdentifier{
				Key: aws.String(key),
			})
		}
	}

	if len(objectsToDelete) == 0 {
		return nil
	}

	// Process in batches of maxBatchSize (AWS limit)
	var allFailures []KeyError
	for i := 0; i < len(objectsToDelete); i += maxBatchSize {
		end := i + maxBatchSize
		if end > len(objectsToDelete) {
			end = len(objectsToDelete)
		}
		batch := objectsToDelete[i:end]

		failures, err := s.executeBatchDelete(ctx, batch)
		if err != nil {
			// Entire batch failed
			return errors.Wrapf(err, "S3 batch delete failed for batch starting at index %d", i)
		}
		allFailures = append(allFailures, failures...)
	}

	if len(allFailures) > 0 {
		return &BatchDeleteError{
			Message:  fmt.Sprintf("S3 batch delete: %d keys deleted, %d failed", len(objectsToDelete)-len(allFailures), len(allFailures)),
			Failures: allFailures,
		}
	}

	log.Debug().Msgf("S3 batch delete: successfully deleted %d objects", len(objectsToDelete))
	return nil
}

// withContentMD5 removes all flexible checksum procedures from an operation,
// instead computing an MD5 checksum for the request payload.
// This is needed for S3-compatible storage that requires Content-MD5 header.
// See https://github.com/aws/aws-sdk-go-v2/discussions/2960
func withContentMD5(o *s3.Options) {
	o.APIOptions = append(o.APIOptions, func(stack *middleware.Stack) error {
		_, _ = stack.Initialize.Remove("AWSChecksum:SetupInputContext")
		_, _ = stack.Build.Remove("AWSChecksum:RequestMetricsTracking")
		_, _ = stack.Finalize.Remove("AWSChecksum:ComputeInputPayloadChecksum")
		_, _ = stack.Finalize.Remove("addInputChecksumTrailer")
		return smithyhttp.AddContentChecksumMiddleware(stack)
	})
}

func isDeleteObjectsMissingContentMD5Error(err error) bool {
	var apiErr smithy.APIError
	if errors.As(err, &apiErr) {
		return apiErr.ErrorCode() == "InvalidRequest" && strings.Contains(apiErr.ErrorMessage(), "Content-MD5")
	}
	return strings.Contains(err.Error(), "Missing required header for this request: Content-MD5")
}

// executeBatchDelete executes a single batch delete operation
func (s *S3) executeBatchDelete(ctx context.Context, objects []s3types.ObjectIdentifier) ([]KeyError, error) {
	params := &s3.DeleteObjectsInput{
		Bucket: aws.String(s.Config.Bucket),
		Delete: &s3types.Delete{
			Objects: objects,
			Quiet:   aws.Bool(true), // Only return errors, not successes
		},
	}

	if s.Config.RequestPayer != "" {
		params.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
	}
	if s.Config.CheckSumAlgorithm != "" {
		params.ChecksumAlgorithm = s3types.ChecksumAlgorithm(s.Config.CheckSumAlgorithm)
	}

	callDeleteObjects := func(requestContentMD5 bool) (*s3.DeleteObjectsOutput, error) {
		if requestContentMD5 {
			return s.client.DeleteObjects(ctx, params, withContentMD5)
		}
		return s.client.DeleteObjects(ctx, params)
	}

	output, err := callDeleteObjects(s.Config.RequestContentMD5)
	if err != nil {
		// Some S3-compatible providers require Content-MD5 for DeleteObjects.
		// Retry once with MD5 middleware even when request_content_md5 is disabled.
		if !s.Config.RequestContentMD5 && isDeleteObjectsMissingContentMD5Error(err) {
			log.Info().Msg("S3 DeleteObjects returned missing Content-MD5, retrying batch delete with Content-MD5")
			output, err = callDeleteObjects(true)
		}
		if err != nil {
			return nil, errors.Wrap(err, "DeleteObjects API call failed")
		}
	}

	// Parse per-object failures
	var failures []KeyError
	for _, delErr := range output.Errors {
		key := aws.ToString(delErr.Key)
		code := aws.ToString(delErr.Code)
		message := aws.ToString(delErr.Message)
		log.Warn().Msgf("S3 batch delete: failed to delete %s: %s - %s", key, code, message)
		failures = append(failures, KeyError{
			Key: key,
			Err: errors.Errorf("%s: %s", code, message),
		})
	}

	return failures, nil
}

func (s *S3) isVersioningEnabled(ctx context.Context) bool {
	output, err := s.client.GetBucketVersioning(ctx, &s3.GetBucketVersioningInput{
		Bucket: aws.String(s.Config.Bucket),
	})
	if err != nil {
		return false
	}
	return output.Status == s3types.BucketVersioningStatusEnabled
}

// getObjectAllVersions returns ObjectIdentifier entries for every object version
// AND every delete-marker that belongs exactly to the given key.
// Deleting delete-markers by VersionId removes them, preventing accumulation
// of empty delete-markers across retries and prior partial deletions.
func (s *S3) getObjectAllVersions(ctx context.Context, key string) ([]s3types.ObjectIdentifier, error) {
	listParams := &s3.ListObjectVersionsInput{
		Bucket: aws.String(s.Config.Bucket),
		Prefix: aws.String(key),
	}
	if s.Config.RequestPayer != "" {
		listParams.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
	}
	var identifiers []s3types.ObjectIdentifier
	pager := s3.NewListObjectVersionsPaginator(s.client, listParams)
	for pager.HasMorePages() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return nil, errors.Wrapf(err, "listing object versions bucket: %s key: %s", s.Config.Bucket, key)
		}
		for _, version := range page.Versions {
			if version.Key != nil && *version.Key == key {
				identifiers = append(identifiers, s3types.ObjectIdentifier{
					Key:       aws.String(key),
					VersionId: version.VersionId,
				})
			}
		}
		for _, marker := range page.DeleteMarkers {
			if marker.Key != nil && *marker.Key == key {
				identifiers = append(identifiers, s3types.ObjectIdentifier{
					Key:       aws.String(key),
					VersionId: marker.VersionId,
				})
			}
		}
	}
	return identifiers, nil
}

func (s *S3) StatFile(ctx context.Context, key string) (RemoteFile, error) {
	return s.StatFileAbsolute(ctx, path.Join(s.Config.Path, key))
}

func (s *S3) StatFileAbsolute(ctx context.Context, key string) (RemoteFile, error) {
	params := &s3.HeadObjectInput{
		Bucket: aws.String(s.Config.Bucket),
		Key:    aws.String(key),
	}
	s.enrichHeadParams(params)
	head, err := s.client.HeadObject(ctx, params)
	if err != nil {
		var opError *smithy.OperationError
		if errors.As(err, &opError) {
			var httpErr *smithyhttp.ResponseError
			if errors.As(opError.Err, &httpErr) {
				if httpErr.Response.StatusCode == http.StatusNotFound {
					return nil, NewErrNotFound(key)
				}
			}
		}
		return nil, errors.Wrap(err, "S3 StatFileAbsolute HeadObject")
	}
	return &s3File{*head.ContentLength, *head.LastModified, string(head.StorageClass), key}, nil
}

func (s *S3) Walk(ctx context.Context, s3Path string, recursive bool, process func(ctx context.Context, r RemoteFile) error) error {
	prefix := path.Join(s.Config.Path, s3Path)
	return s.WalkAbsolute(ctx, prefix, recursive, process)
}

func (s *S3) WalkAbsolute(ctx context.Context, prefix string, recursive bool, process func(ctx context.Context, r RemoteFile) error) error {
	g, ctx := errgroup.WithContext(ctx)
	s3Files := make(chan *s3File)
	g.Go(func() error {
		defer close(s3Files)
		return s.remotePager(ctx, prefix, recursive, func(page *s3.ListObjectsV2Output) {
			for _, cp := range page.CommonPrefixes {
				s3Files <- &s3File{
					name: strings.TrimPrefix(*cp.Prefix, prefix),
				}
			}
			for _, c := range page.Contents {
				s3Files <- &s3File{
					*c.Size,
					*c.LastModified,
					string(c.StorageClass),
					strings.TrimPrefix(*c.Key, prefix),
				}
			}
		})
	})
	g.Go(func() error {
		var err error
		for s3FileItem := range s3Files {
			if err == nil {
				err = process(ctx, s3FileItem)
			}
		}
		if err != nil {
			return errors.Wrap(err, "S3 WalkAbsolute process")
		}
		return nil
	})
	return g.Wait()
}

func (s *S3) remotePager(ctx context.Context, s3Path string, recursive bool, process func(page *s3.ListObjectsV2Output)) error {
	prefix := s3Path + "/"
	if s3Path == "" || s3Path == "/" {
		prefix = ""
	}
	params := &s3.ListObjectsV2Input{
		Bucket:  aws.String(s.Config.Bucket), // Required
		MaxKeys: aws.Int32(1000),
		Prefix:  aws.String(prefix),
	}
	if !recursive {
		params.Delimiter = aws.String("/")
	}
	pager := s3.NewListObjectsV2Paginator(s.client, params, func(o *s3.ListObjectsV2PaginatorOptions) {
		o.Limit = 1000
	})
	for pager.HasMorePages() {
		page, err := pager.NextPage(ctx)
		if err != nil {
			return errors.Wrap(err, "S3 remotePager NextPage")
		}
		process(page)
	}
	return nil
}

// s3CopySource - the `x-amz-copy-source` header must be URL-encoded, the SDK passes it as is,
// otherwise keys containing literal `%` or `#` (e.g. TablePathEncode names in shadow paths)
// are decoded on the server side into a different key and CopyObject fails with NoSuchKey
func s3CopySource(srcBucket, srcKey string) string {
	return (&url.URL{Path: path.Join(srcBucket, srcKey)}).EscapedPath()
}

// CopyObject server-side copy from srcBucket/srcKey to s.Config.Bucket/dstKey, both keys are absolute inside the bucket
func (s *S3) CopyObject(ctx context.Context, srcSize int64, srcBucket, srcKey, dstKey string) (int64, error) {
	log.Debug().Msgf("S3->CopyObject %s/%s -> %s/%s", srcBucket, srcKey, s.Config.Bucket, dstKey)
	// just copy object without multipart
	if srcSize < 5*1024*1024*1024 || strings.Contains(s.Config.Endpoint, "storage.googleapis.com") {
		params := &s3.CopyObjectInput{
			Bucket:       aws.String(s.Config.Bucket),
			Key:          aws.String(dstKey),
			CopySource:   aws.String(s3CopySource(srcBucket, srcKey)),
			StorageClass: s3types.StorageClass(strings.ToUpper(s.Config.StorageClass)),
		}
		s.enrichCopyObjectParams(params)
		_, err := s.client.CopyObject(ctx, params)
		if err != nil {
			return 0, errors.Wrapf(err, "S3->CopyObject %s/%s -> %s/%s return error", srcBucket, srcKey, s.Config.Bucket, dstKey)
		}
		return srcSize, nil
	}
	// Initiate a multipart upload
	createMultipartUploadParams := &s3.CreateMultipartUploadInput{
		Bucket:       aws.String(s.Config.Bucket),
		Key:          aws.String(dstKey),
		StorageClass: s3types.StorageClass(strings.ToUpper(s.Config.StorageClass)),
	}
	s.enrichCreateMultipartUploadParams(createMultipartUploadParams)
	initResp, err := s.client.CreateMultipartUpload(ctx, createMultipartUploadParams)
	if err != nil {
		return 0, errors.Wrapf(err, "S3->CopyObject %s/%s -> %s/%s, CreateMultipartUpload return error", srcBucket, srcKey, s.Config.Bucket, dstKey)
	}

	// Get the upload ID
	uploadID := initResp.UploadId

	// Set the part size (128 MB minimum for CopyObject, or use configured chunk size)
	partSize := s.calculatePartSize(srcSize, 128*1024*1024)

	// Calculate the number of parts
	numParts := (srcSize + partSize - 1) / partSize

	copyPartErrGroup, ctx := errgroup.WithContext(ctx)
	copyPartErrGroup.SetLimit(s.Config.Concurrency)

	var mu sync.Mutex
	var parts []s3types.CompletedPart

	// Copy each part of the object
	for partNumber := int64(1); partNumber <= numParts; partNumber++ {
		// Calculate the byte range for the part
		start := (partNumber - 1) * partSize
		end := partNumber * partSize
		if end > srcSize {
			end = srcSize
		}
		currentPartNumber := int32(partNumber)

		copyPartErrGroup.Go(func() error {
			// Copy the part
			uploadPartParams := &s3.UploadPartCopyInput{
				Bucket:          aws.String(s.Config.Bucket),
				Key:             aws.String(dstKey),
				CopySource:      aws.String(s3CopySource(srcBucket, srcKey)),
				CopySourceRange: aws.String(fmt.Sprintf("bytes=%d-%d", start, end-1)),
				UploadId:        uploadID,
				PartNumber:      aws.Int32(currentPartNumber),
			}
			if s.Config.RequestPayer != "" {
				uploadPartParams.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
			}
			partResp, err := s.client.UploadPartCopy(ctx, uploadPartParams)
			if err != nil {
				return errors.Wrapf(err, "S3->CopyObject %s/%s -> %s/%s, UploadPartCopy start=%d, end=%d return error", srcBucket, srcKey, s.Config.Bucket, dstKey, start, end-1)
			}
			mu.Lock()
			parts = append(parts, s3types.CompletedPart{
				ETag:           partResp.CopyPartResult.ETag,
				PartNumber:     aws.Int32(currentPartNumber),
				ChecksumCRC32:  partResp.CopyPartResult.ChecksumCRC32,
				ChecksumCRC32C: partResp.CopyPartResult.ChecksumCRC32C,
				ChecksumSHA1:   partResp.CopyPartResult.ChecksumSHA1,
				ChecksumSHA256: partResp.CopyPartResult.ChecksumSHA256,
			})
			mu.Unlock()
			return nil
		})
	}
	if wgWaitErr := copyPartErrGroup.Wait(); wgWaitErr != nil {
		abortParams := &s3.AbortMultipartUploadInput{
			Bucket:   aws.String(s.Config.Bucket),
			Key:      aws.String(dstKey),
			UploadId: uploadID,
		}
		if s.Config.RequestPayer != "" {
			abortParams.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
		}
		_, abortErr := s.client.AbortMultipartUpload(context.Background(), abortParams)
		if abortErr != nil {
			return 0, errors.Wrapf(wgWaitErr, "aborting CopyObject multipart upload: %v, original error was", abortErr)
		}
		return 0, errors.Wrap(wgWaitErr, "one of CopyObject/Multipart go-routine return error")
	}
	// Parts must be ordered by part number.
	sort.Slice(parts, func(i int, j int) bool {
		return *parts[i].PartNumber < *parts[j].PartNumber
	})
	// Complete the multipart upload
	completeMultipartUploadParams := &s3.CompleteMultipartUploadInput{
		Bucket:          aws.String(s.Config.Bucket),
		Key:             aws.String(dstKey),
		UploadId:        uploadID,
		MultipartUpload: &s3types.CompletedMultipartUpload{Parts: parts},
	}
	if s.Config.RequestPayer != "" {
		completeMultipartUploadParams.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
	}
	_, err = s.client.CompleteMultipartUpload(context.Background(), completeMultipartUploadParams)
	if err != nil {
		return 0, errors.Wrap(err, "complete CopyObject multipart upload")
	}
	return srcSize, nil
}

func (s *S3) enrichCreateMultipartUploadParams(params *s3.CreateMultipartUploadInput) {
	common := s.commonObjectParams()
	params.ChecksumAlgorithm = common.ChecksumAlgorithm
	params.ACL = common.ACL
	params.Tagging = common.Tagging
	params.ServerSideEncryption = common.ServerSideEncryption
	params.SSEKMSKeyId = common.SSEKMSKeyId
	params.SSECustomerAlgorithm = common.SSECustomerAlgorithm
	params.SSECustomerKey = common.SSECustomerKey
	params.SSECustomerKeyMD5 = common.SSECustomerKeyMD5
	params.SSEKMSEncryptionContext = common.SSEKMSEncryptionContext
	params.RequestPayer = common.RequestPayer
}

func (s *S3) enrichCopyObjectParams(params *s3.CopyObjectInput) {
	common := s.commonObjectParams()
	params.ChecksumAlgorithm = common.ChecksumAlgorithm
	params.ACL = common.ACL
	params.Tagging = common.Tagging
	params.ServerSideEncryption = common.ServerSideEncryption
	params.SSEKMSKeyId = common.SSEKMSKeyId
	params.SSECustomerAlgorithm = common.SSECustomerAlgorithm
	params.SSECustomerKey = common.SSECustomerKey
	params.SSECustomerKeyMD5 = common.SSECustomerKeyMD5
	params.SSEKMSEncryptionContext = common.SSEKMSEncryptionContext
	params.RequestPayer = common.RequestPayer
}

func (s *S3) restoreObject(ctx context.Context, key string) error {
	restoreRequest := &s3.RestoreObjectInput{
		Bucket: aws.String(s.Config.Bucket),
		Key:    aws.String(path.Join(s.Config.Path, key)),
		RestoreRequest: &s3types.RestoreRequest{
			Days: aws.Int32(1),
			GlacierJobParameters: &s3types.GlacierJobParameters{
				Tier: s3types.Tier("Expedited"),
			},
		},
	}
	if s.Config.RequestPayer != "" {
		restoreRequest.RequestPayer = s3types.RequestPayer(s.Config.RequestPayer)
	}
	_, err := s.client.RestoreObject(ctx, restoreRequest)
	if err != nil {
		return errors.Wrap(err, "S3 restoreObject RestoreObject")
	}
	i := 0
	for {
		restoreHeadParams := &s3.HeadObjectInput{
			Bucket: aws.String(s.Config.Bucket),
			Key:    aws.String(path.Join(s.Config.Path, key)),
		}
		s.enrichHeadParams(restoreHeadParams)
		res, err := s.client.HeadObject(ctx, restoreHeadParams)
		if err != nil {
			return errors.Wrapf(err, "restoreObject: failed to head %s object metadata", path.Join(s.Config.Path, key))
		}

		if res.Restore != nil && *res.Restore == "ongoing-request=\"true\"" {
			i += 1
			log.Warn().Msgf("%s still not restored, will wait %d seconds", key, i*5)
			time.Sleep(time.Duration(i*5) * time.Second)
		} else {
			return nil
		}
	}
}

func (s *S3) enrichHeadParams(headParams *s3.HeadObjectInput) {
	headParams.RequestPayer = s.requestPayer()
	sse := s.sseCustomerParams()
	headParams.SSECustomerAlgorithm = sse.SSECustomerAlgorithm
	headParams.SSECustomerKey = sse.SSECustomerKey
	headParams.SSECustomerKeyMD5 = sse.SSECustomerKeyMD5
}

type s3File struct {
	size         int64
	lastModified time.Time
	storageClass string
	name         string
}

func (f *s3File) Size() int64 {
	return f.size
}

func (f *s3File) Name() string {
	return f.name
}

func (f *s3File) LastModified() time.Time {
	return f.lastModified
}

func (f *s3File) StorageClass() string {
	return f.storageClass
}
