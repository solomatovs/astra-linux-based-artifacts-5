package storage

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/textproto"
	"os"
	"path"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/Altinity/clickhouse-backup/v2/pkg/config"
	"github.com/jlaffaye/ftp"
	"github.com/jolestar/go-commons-pool/v2"
	"github.com/pkg/errors"
	"github.com/rs/zerolog/log"
	"golang.org/x/sync/errgroup"
)

type FTP struct {
	clients       *pool.ObjectPool
	Config        *config.FTPConfig
	dirCache      map[string]bool
	dirCacheMutex sync.RWMutex
	// CopyObject server-side copy methods probed once and remembered when the server replies `command not implemented`
	siteCopyUnsupported atomic.Bool
	fxpUnsupported      atomic.Bool
}

func (f *FTP) Kind() string {
	return "FTP"
}

func (f *FTP) Connect(ctx context.Context) error {
	timeout, err := time.ParseDuration(f.Config.Timeout)
	if err != nil {
		return errors.Wrap(err, "FTP Connect ParseDuration")
	}
	options := make([]ftp.DialOption, 0)
	options = append(options, ftp.DialWithContext(ctx))
	if timeout > 0 {
		options = append(options, ftp.DialWithTimeout(timeout))
	}
	if f.Config.Debug {
		options = append(options, ftp.DialWithDebugOutput(os.Stderr))
	}
	if f.Config.TLS {
		tlsConfig := tls.Config{InsecureSkipVerify: f.Config.SkipTLSVerify}
		options = append(options, ftp.DialWithTLS(&tlsConfig))
	}
	f.clients = pool.NewObjectPoolWithDefaultConfig(ctx, &ftpPoolFactory{options: options, ftp: f})
	// Enable connection validation on borrow to detect stale connections
	f.clients.Config.TestOnBorrow = true
	if f.Config.Concurrency > 1 {
		f.clients.Config.MaxTotal = int(f.Config.Concurrency) * 4
	}

	f.dirCacheMutex.Lock()
	f.dirCache = map[string]bool{}
	f.dirCacheMutex.Unlock()
	return nil
}

func (f *FTP) Close(ctx context.Context) error {
	f.clients.Close(ctx)
	return nil
}

// getConnectionFromPool *ftp.ServerConn is not thread-safe, so we need implements connection pool
func (f *FTP) getConnectionFromPool(ctx context.Context, where string) (*ftp.ServerConn, error) {
	log.Debug().Msgf("getConnectionFromPool(%s) active=%d idle=%d", where, f.clients.GetNumActive(), f.clients.GetNumIdle())
	client, err := f.clients.BorrowObject(ctx)
	if err != nil {
		log.Error().Msgf("can't BorrowObject(%s) from FTP Connection Pool: %v", where, err)
		return nil, errors.Wrap(err, "FTP getConnectionFromPool BorrowObject")
	}
	return client.(*ftp.ServerConn), nil
}

func (f *FTP) returnConnectionToPool(ctx context.Context, where string, client *ftp.ServerConn) {
	log.Debug().Msgf("returnConnectionToPool(%s) active=%d idle=%d", where, f.clients.GetNumActive(), f.clients.GetNumIdle())
	if client != nil {
		err := f.clients.ReturnObject(ctx, client)
		if err != nil {
			log.Error().Msgf("can't ReturnObject(%s) to FTP Connection Pool: %v", where, err)
		}
	}
}

func (f *FTP) StatFile(ctx context.Context, key string) (RemoteFile, error) {
	return f.StatFileAbsolute(ctx, path.Join(f.Config.Path, key))
}

func (f *FTP) StatFileAbsolute(ctx context.Context, key string) (RemoteFile, error) {
	// can't list files, so check the dir
	dir := path.Dir(key)
	client, err := f.getConnectionFromPool(ctx, fmt.Sprintf("StatFile, key=%s", key))
	if err != nil {
		return nil, errors.Wrap(err, "FTP StatFileAbsolute getConnection")
	}
	defer f.returnConnectionToPool(ctx, fmt.Sprintf("StatFile, key=%s", key), client)
	entries, err := client.List(dir)
	if err != nil {
		// proftpd return 550 error if `dir` not exists
		if strings.HasPrefix(err.Error(), "550") {
			return nil, NewErrNotFound(key)
		}
		return nil, errors.Wrap(err, "FTP StatFileAbsolute List")
	}
	file := path.Base(key)
	for i := range entries {
		if file == entries[i].Name {
			// file found, return it
			return &ftpFile{
				size:         int64(entries[i].Size),
				lastModified: entries[i].Time,
				name:         entries[i].Name,
			}, nil
		}
	}

	return nil, NewErrNotFound(key)
}

func (f *FTP) DeleteFile(ctx context.Context, key string) error {
	where := fmt.Sprintf("DeleteFile->%s", key)
	client, err := f.getConnectionFromPool(ctx, where)
	defer f.returnConnectionToPool(ctx, where, client)
	if err != nil {
		return errors.Wrap(err, "FTP DeleteFile getConnection")
	}
	filePath := path.Join(f.Config.Path, key)
	// goftp RemoveDirRecur calls ChangeDir which fails on files.
	// Try DELE first for files, fall back to RemoveDirRecur for directories.
	if err := client.Delete(filePath); err == nil {
		return nil
	}
	if err := client.RemoveDirRecur(filePath); err != nil {
		return errors.Wrap(err, "FTP DeleteFile RemoveDirRecur")
	}
	return nil
}

func (f *FTP) Walk(ctx context.Context, ftpPath string, recursive bool, process func(context.Context, RemoteFile) error) error {
	prefix := path.Join(f.Config.Path, ftpPath)
	return f.WalkAbsolute(ctx, prefix, recursive, process)
}

func (f *FTP) WalkAbsolute(ctx context.Context, prefix string, recursive bool, process func(context.Context, RemoteFile) error) error {
	client, err := f.getConnectionFromPool(ctx, "Walk")
	if err != nil {
		return errors.Wrap(err, "FTP WalkAbsolute getConnection")
	}
	if !recursive {
		entries, err := client.List(prefix)
		f.returnConnectionToPool(ctx, "Walk", client)
		if err != nil {
			// proftpd return 550 error if prefix not exits
			if strings.HasPrefix(err.Error(), "550") {
				return nil
			}
			return errors.Wrap(err, "FTP WalkAbsolute List")
		}
		for _, entry := range entries {
			if entry.Name == "." || entry.Name == ".." {
				continue
			}
			if err := process(ctx, &ftpFile{
				size:         int64(entry.Size),
				lastModified: entry.Time,
				name:         entry.Name,
			}); err != nil {
				return errors.Wrap(err, "FTP WalkAbsolute process entry")
			}
		}
		return nil
	}
	defer f.returnConnectionToPool(ctx, "Walk", client)
	walker := client.Walk(prefix)
	for walker.Next() {
		if err := walker.Err(); err != nil {
			return errors.Wrap(err, "FTP WalkAbsolute walker.Err")
		}
		entry := walker.Stat()
		if entry == nil {
			continue
		}
		// walker emits folder entries while descending, process only files like object storages do
		if entry.Type == ftp.EntryTypeFolder {
			continue
		}
		if err := process(ctx, &ftpFile{
			size:         int64(entry.Size),
			lastModified: entry.Time,
			name:         strings.TrimPrefix(walker.Path(), prefix),
		}); err != nil {
			return errors.Wrap(err, "FTP WalkAbsolute process")
		}
	}
	return nil
}

func (f *FTP) GetFileReader(ctx context.Context, key string) (io.ReadCloser, error) {
	return f.GetFileReaderAbsolute(ctx, path.Join(f.Config.Path, key))
}
func (f *FTP) GetFileReaderAbsolute(ctx context.Context, key string) (io.ReadCloser, error) {
	where := fmt.Sprintf("GetFileReaderAbsolute->%s", key)
	client, err := f.getConnectionFromPool(ctx, where)
	if err != nil {
		return nil, errors.Wrap(err, "FTP GetFileReaderAbsolute getConnection")
	}
	resp, err := client.Retr(key)
	return &FTPFileReader{
		Response: resp,
		pool:     f,
		ctx:      ctx,
		client:   client,
	}, err
}

func (f *FTP) GetFileReaderWithLocalPath(ctx context.Context, key, _ string, _ int64) (io.ReadCloser, error) {
	return f.GetFileReader(ctx, key)
}

func (f *FTP) PutFile(ctx context.Context, key string, r io.ReadCloser, localSize int64) error {
	return f.PutFileAbsolute(ctx, path.Join(f.Config.Path, key), r, localSize)
}

func (f *FTP) PutFileAbsolute(ctx context.Context, key string, r io.ReadCloser, _ int64) error {
	where := fmt.Sprintf("PutFileReaderAbsolute->%s", key)
	client, err := f.getConnectionFromPool(ctx, where)
	defer f.returnConnectionToPool(ctx, where, client)
	if err != nil {
		return errors.Wrap(err, "FTP PutFileAbsolute getConnection")
	}
	err = f.MkdirAll(path.Dir(key), client)
	if err != nil {
		return errors.Wrap(err, "FTP PutFileAbsolute MkdirAll")
	}
	if err := client.Stor(key, r); err != nil {
		return errors.Wrap(err, "FTP PutFileAbsolute Stor")
	}
	return nil
}

// CopyObject copy file inside the same FTP server (like `cp` command), srcBucket is ignored,
// tries ProFTPD mod_copy `SITE CPFR`/`SITE CPTO` server-side copy first,
// then FXP (PASV+PORT, server transfers to itself without client bandwidth),
// falls back to streaming RETR from one pooled connection into STOR on another
func (f *FTP) CopyObject(ctx context.Context, srcSize int64, srcBucket, srcKey, dstKey string) (int64, error) {
	// non-empty srcBucket means the source lives in a bucket-based storage (object disk),
	// copy inside the FTP server is impossible, fail fast so callers fall back to streaming
	if srcBucket != "" {
		return 0, errors.Errorf("CopyObject from bucket %s not supported for %s", srcBucket, f.Kind())
	}
	log.Debug().Msgf("FTP->CopyObject %s -> %s", srcKey, dstKey)
	where := fmt.Sprintf("CopyObject->%s", dstKey)
	client, err := f.getConnectionFromPool(ctx, where)
	if err != nil {
		return 0, errors.Wrap(err, "FTP CopyObject getConnection")
	}
	mkdirErr := f.MkdirAll(path.Dir(dstKey), client)
	f.returnConnectionToPool(ctx, where, client)
	if mkdirErr != nil {
		return 0, errors.Wrap(mkdirErr, "FTP CopyObject MkdirAll")
	}
	timeout, err := time.ParseDuration(f.Config.Timeout)
	if err != nil {
		return 0, errors.Wrap(err, "FTP CopyObject ParseDuration")
	}
	if !f.siteCopyUnsupported.Load() {
		siteCopyErr := f.copyViaSiteCopy(srcKey, dstKey, timeout)
		if siteCopyErr == nil {
			return srcSize, nil
		}
		if isFTPCommandUnsupported(siteCopyErr) {
			f.siteCopyUnsupported.Store(true)
		}
		log.Warn().Msgf("FTP CopyObject SITE CPFR/CPTO %s -> %s error: %v, will try FXP", srcKey, dstKey, siteCopyErr)
	}
	if !f.fxpUnsupported.Load() {
		fxpErr := f.copyViaFXP(srcKey, dstKey, timeout)
		if fxpErr == nil {
			return srcSize, nil
		}
		if isFTPCommandUnsupported(fxpErr) {
			f.fxpUnsupported.Store(true)
		}
		log.Warn().Msgf("FTP CopyObject FXP %s -> %s error: %v, will stream through two pool connections", srcKey, dstKey, fxpErr)
	}
	reader, err := f.GetFileReaderAbsolute(ctx, srcKey)
	if err != nil {
		return 0, errors.Wrapf(err, "FTP CopyObject GetFileReaderAbsolute(%s)", srcKey)
	}
	defer func() {
		if closeErr := reader.Close(); closeErr != nil {
			log.Warn().Msgf("FTP CopyObject can't close reader for %s error: %v", srcKey, closeErr)
		}
	}()
	if err = f.PutFileAbsolute(ctx, dstKey, reader, srcSize); err != nil {
		return 0, errors.Wrapf(err, "FTP CopyObject PutFileAbsolute(%s)", dstKey)
	}
	return srcSize, nil
}

// copyViaSiteCopy server-side copy via ProFTPD mod_copy `SITE CPFR`/`SITE CPTO` commands,
// jlaffaye/ftp doesn't expose raw commands, so open a dedicated control connection
func (f *FTP) copyViaSiteCopy(srcKey, dstKey string, timeout time.Duration) error {
	text, err := f.openRawConn(timeout)
	if err != nil {
		return errors.Wrap(err, "openRawConn")
	}
	defer func() {
		if closeErr := text.Close(); closeErr != nil {
			log.Warn().Msgf("FTP copyViaSiteCopy close error: %v", closeErr)
		}
	}()
	if _, _, err = ftpRawCmd(text, 350, "SITE CPFR %s", srcKey); err != nil {
		return errors.Wrapf(err, "SITE CPFR %s", srcKey)
	}
	if _, _, err = ftpRawCmd(text, 250, "SITE CPTO %s", dstKey); err != nil {
		return errors.Wrapf(err, "SITE CPTO %s", dstKey)
	}
	return nil
}

var ftpPasvRE = regexp.MustCompile(`\((\d+),(\d+),(\d+),(\d+),(\d+),(\d+)\)`)

// copyViaFXP server-to-itself transfer: PASV on the dst control connection opens a data listener,
// PORT points the src control connection at it, then RETR/STOR make the server move the data internally
func (f *FTP) copyViaFXP(srcKey, dstKey string, timeout time.Duration) error {
	srcText, err := f.openRawConn(timeout)
	if err != nil {
		return errors.Wrap(err, "openRawConn src")
	}
	defer func() {
		if closeErr := srcText.Close(); closeErr != nil {
			log.Warn().Msgf("FTP copyViaFXP close src error: %v", closeErr)
		}
	}()
	dstText, err := f.openRawConn(timeout)
	if err != nil {
		return errors.Wrap(err, "openRawConn dst")
	}
	defer func() {
		if closeErr := dstText.Close(); closeErr != nil {
			log.Warn().Msgf("FTP copyViaFXP close dst error: %v", closeErr)
		}
	}()
	if _, _, err = ftpRawCmd(srcText, 200, "TYPE I"); err != nil {
		return errors.Wrap(err, "TYPE I src")
	}
	if _, _, err = ftpRawCmd(dstText, 200, "TYPE I"); err != nil {
		return errors.Wrap(err, "TYPE I dst")
	}
	_, pasvMsg, err := ftpRawCmd(dstText, 227, "PASV")
	if err != nil {
		return errors.Wrap(err, "PASV")
	}
	pasvAddr := ftpPasvRE.FindStringSubmatch(pasvMsg)
	if pasvAddr == nil {
		return errors.Errorf("can't parse PASV response %q", pasvMsg)
	}
	if _, _, err = ftpRawCmd(srcText, 200, "PORT %s", strings.Join(pasvAddr[1:], ",")); err != nil {
		return errors.Wrap(err, "PORT")
	}
	// send both transfer commands before reading replies, preliminary 150 can be deferred
	// until the data connection is established between the two server sessions
	storId, err := dstText.Cmd("STOR %s", dstKey)
	if err != nil {
		return errors.Wrap(err, "STOR")
	}
	retrId, err := srcText.Cmd("RETR %s", srcKey)
	if err != nil {
		return errors.Wrap(err, "RETR")
	}
	if err = ftpReadTransferResponse(dstText, storId, "STOR"); err != nil {
		return err
	}
	return ftpReadTransferResponse(srcText, retrId, "RETR")
}

// ftpReadTransferResponse reads the preliminary 1xx reply (when sent) and the final 2xx transfer reply
func ftpReadTransferResponse(text *textproto.Conn, cmdId uint, operation string) error {
	text.StartResponse(cmdId)
	defer text.EndResponse(cmdId)
	code, msg, err := text.ReadResponse(-1)
	if err != nil {
		return errors.Wrapf(err, "%s response", operation)
	}
	if code/100 == 1 {
		if code, msg, err = text.ReadResponse(-1); err != nil {
			return errors.Wrapf(err, "%s final response", operation)
		}
	}
	if code/100 != 2 {
		return &textproto.Error{Code: code, Msg: fmt.Sprintf("%s: %s", operation, msg)}
	}
	return nil
}

// openRawConn dial a dedicated FTP control connection and log in, mirrors the pool factory connection options
func (f *FTP) openRawConn(timeout time.Duration) (*textproto.Conn, error) {
	var conn net.Conn
	conn, err := net.DialTimeout("tcp", f.Config.Address, timeout)
	if err != nil {
		return nil, errors.Wrap(err, "DialTimeout")
	}
	if timeout > 0 {
		if err = conn.SetDeadline(time.Now().Add(timeout)); err != nil {
			_ = conn.Close()
			return nil, errors.Wrap(err, "SetDeadline")
		}
	}
	if f.Config.TLS {
		conn = tls.Client(conn, &tls.Config{InsecureSkipVerify: f.Config.SkipTLSVerify})
	}
	text := textproto.NewConn(conn)
	if _, _, err = text.ReadResponse(220); err != nil {
		_ = text.Close()
		return nil, errors.Wrap(err, "read greeting")
	}
	code, msg, err := ftpRawCmd(text, -1, "USER %s", f.Config.Username)
	if err != nil {
		_ = text.Close()
		return nil, errors.Wrap(err, "USER")
	}
	if code == 331 {
		if _, _, err = ftpRawCmd(text, 230, "PASS %s", f.Config.Password); err != nil {
			_ = text.Close()
			return nil, errors.Wrap(err, "PASS")
		}
	} else if code != 230 {
		_ = text.Close()
		return nil, errors.Errorf("unexpected USER response %d %s", code, msg)
	}
	return text, nil
}

func ftpRawCmd(text *textproto.Conn, expectCode int, format string, args ...interface{}) (int, string, error) {
	cmdId, err := text.Cmd(format, args...)
	if err != nil {
		return 0, "", err
	}
	text.StartResponse(cmdId)
	defer text.EndResponse(cmdId)
	return text.ReadResponse(expectCode)
}

// isFTPCommandUnsupported detects permanent `command not implemented` replies,
// so unsupported server-side copy methods are probed only once per connection lifetime
func isFTPCommandUnsupported(err error) bool {
	var tpErr *textproto.Error
	if errors.As(err, &tpErr) {
		return tpErr.Code == 500 || tpErr.Code == 502 || tpErr.Code == 504
	}
	return false
}

func (f *FTP) DeleteFileFromObjectDiskBackup(ctx context.Context, key string) error {
	where := fmt.Sprintf("DeleteFileFromObjectDiskBackup->%s", key)
	client, err := f.getConnectionFromPool(ctx, where)
	defer f.returnConnectionToPool(ctx, where, client)
	if err != nil {
		return errors.Wrap(err, "FTP DeleteFileFromObjectDiskBackup getConnection")
	}
	filePath := path.Join(f.Config.ObjectDiskPath, key)
	// goftp RemoveDirRecur calls ChangeDir which fails on files (not directories).
	// Try DELE first for files, fall back to RemoveDirRecur for directories.
	if err := client.Delete(filePath); err == nil {
		return nil
	}
	if err := client.RemoveDirRecur(filePath); err != nil {
		return errors.Wrap(err, "FTP DeleteFileFromObjectDiskBackup RemoveDirRecur")
	}
	return nil
}

// DeleteKeys implements BatchDeleter interface for FTP
// Uses concurrent deletion with connection pool
func (f *FTP) DeleteKeys(ctx context.Context, keys []string) error {
	if len(keys) == 0 {
		return nil
	}
	// Prepend path to all keys
	fullKeys := make([]string, len(keys))
	for i, key := range keys {
		fullKeys[i] = path.Join(f.Config.Path, key)
	}
	return f.deleteKeysConcurrent(ctx, fullKeys)
}

// DeleteKeysFromObjectDiskBackup implements BatchDeleter interface for FTP
func (f *FTP) DeleteKeysFromObjectDiskBackup(ctx context.Context, keys []string) error {
	if len(keys) == 0 {
		return nil
	}
	// Prepend object disk path to all keys
	fullKeys := make([]string, len(keys))
	for i, key := range keys {
		fullKeys[i] = path.Join(f.Config.ObjectDiskPath, key)
	}
	return f.deleteKeysConcurrent(ctx, fullKeys)
}

// deleteKeysConcurrent performs concurrent deletion using connection pool
func (f *FTP) deleteKeysConcurrent(ctx context.Context, keys []string) error {
	concurrency := int(f.Config.Concurrency)
	if concurrency < 1 {
		concurrency = 5 // Default concurrency for FTP
	}

	log.Debug().Msgf("FTP batch delete: deleting %d keys with concurrency %d", len(keys), concurrency)

	g, ctx := errgroup.WithContext(ctx)
	g.SetLimit(concurrency)

	var mu sync.Mutex
	var failures []KeyError
	deletedCount := 0

	for _, key := range keys {
		key := key // capture for goroutine
		g.Go(func() error {
			where := fmt.Sprintf("DeleteKeys->%s", key)
			client, err := f.getConnectionFromPool(ctx, where)
			if err != nil {
				mu.Lock()
				failures = append(failures, KeyError{Key: key, Err: errors.Wrap(err, "failed to get connection")})
				mu.Unlock()
				return nil
			}
			defer f.returnConnectionToPool(ctx, where, client)

			err = client.RemoveDirRecur(key)
			if err != nil {
				// Check if it's a "not found" error - that's OK
				if strings.HasPrefix(err.Error(), "550") {
					mu.Lock()
					deletedCount++
					mu.Unlock()
					return nil
				}
				mu.Lock()
				failures = append(failures, KeyError{Key: key, Err: err})
				mu.Unlock()
				return nil
			}
			mu.Lock()
			deletedCount++
			mu.Unlock()
			return nil
		})
	}

	if err := g.Wait(); err != nil {
		return errors.Wrap(err, "FTP concurrent delete failed")
	}

	if len(failures) > 0 {
		return &BatchDeleteError{
			Message:  fmt.Sprintf("FTP batch delete: %d keys deleted, %d failed", deletedCount, len(failures)),
			Failures: failures,
		}
	}

	log.Debug().Msgf("FTP batch delete: successfully deleted %d keys", deletedCount)
	return nil
}

type ftpFile struct {
	size         int64
	lastModified time.Time
	name         string
}

func (f *ftpFile) Size() int64 {
	return f.size
}

func (f *ftpFile) LastModified() time.Time {
	return f.lastModified
}

func (f *ftpFile) Name() string {
	return f.name
}

func (f *FTP) MkdirAll(key string, client *ftp.ServerConn) error {
	dirs := strings.Split(key, "/")
	err := client.ChangeDir("/")
	if err != nil {
		return errors.Wrap(err, "FTP MkdirAll ChangeDir")
	}

	for i := range dirs {
		d := path.Join(dirs[:i+1]...)
		if d != "" {
			f.dirCacheMutex.RLock()
			if _, exists := f.dirCache[d]; exists {
				f.dirCacheMutex.RUnlock()
				log.Debug().Msgf("MkdirAll %s exists in dirCache", d)
				continue
			}
			f.dirCacheMutex.RUnlock()

			f.dirCacheMutex.Lock()
			err = client.MakeDir(d)
			if err != nil {
				log.Warn().Msgf("MkdirAll MakeDir(%s) return error: %v", d, err)
			} else {
				f.dirCache[d] = true
			}
			f.dirCacheMutex.Unlock()
		}
	}
	return nil
}

type FTPFileReader struct {
	*ftp.Response
	pool   *FTP
	ctx    context.Context
	client *ftp.ServerConn
}

func (fr *FTPFileReader) Close() error {
	defer fr.pool.returnConnectionToPool(fr.ctx, "FTPFileReader.Close", fr.client)
	if err := fr.Response.Close(); err != nil {
		return errors.Wrap(err, "FTPFileReader Close")
	}
	return nil
}

type ftpPoolFactory struct {
	options []ftp.DialOption
	ftp     *FTP
}

func (f *ftpPoolFactory) MakeObject(ctx context.Context) (*pool.PooledObject, error) {
	// Retry logic for transient connection failures (FTP server may reject connections under load)
	var c *ftp.ServerConn
	var err error
	maxRetries := 3
	for attempt := 0; attempt < maxRetries; attempt++ {
		if attempt > 0 {
			// Wait before retry with exponential backoff
			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(time.Duration(attempt*100) * time.Millisecond):
			}
		}
		c, err = ftp.Dial(f.ftp.Config.Address, f.options...)
		if err != nil {
			log.Debug().Msgf("ftpPoolFactory->MakeObject Dial attempt %d failed: %v", attempt+1, err)
			continue
		}
		if err = c.Login(f.ftp.Config.Username, f.ftp.Config.Password); err != nil {
			log.Debug().Msgf("ftpPoolFactory->MakeObject Login attempt %d failed: %v", attempt+1, err)
			// Close the connection before retry
			_ = c.Quit()
			continue
		}
		// Success
		return pool.NewPooledObject(c), nil
	}
	// All retries failed
	if err != nil {
		return nil, errors.Wrapf(err, "ftpPoolFactory->MakeObject failed after %d attempts", maxRetries)
	}
	return nil, errors.Errorf("ftpPoolFactory->MakeObject failed after %d attempts", maxRetries)
}

func (f *ftpPoolFactory) DestroyObject(_ context.Context, object *pool.PooledObject) error {
	if err := object.Object.(*ftp.ServerConn).Quit(); err != nil {
		log.Warn().Msgf("ftpPoolFactory->Destroy Quit error: %v", err)
		return errors.Wrap(err, "ftpPoolFactory DestroyObject Quit")
	}
	return nil
}

func (f *ftpPoolFactory) ValidateObject(_ context.Context, object *pool.PooledObject) bool {
	// Validate connection by sending NOOP command
	conn := object.Object.(*ftp.ServerConn)
	if err := conn.NoOp(); err != nil {
		// Some FTP servers (like pure-ftpd) don't support NOOP command and return "500 Unknown command"
		// This still means the connection is alive (server received and responded to command)
		if strings.HasPrefix(err.Error(), "500") {
			log.Debug().Msgf("ftpPoolFactory->ValidateObject NoOp returned 500 (command not supported), connection still valid")
			return true
		}
		log.Debug().Msgf("ftpPoolFactory->ValidateObject NoOp failed: %v", err)
		return false
	}
	return true
}

func (f *ftpPoolFactory) ActivateObject(_ context.Context, _ *pool.PooledObject) error {
	return nil
}

func (f *ftpPoolFactory) PassivateObject(_ context.Context, _ *pool.PooledObject) error {
	return nil
}
