//go:build integration

package main

import (
	"testing"
	"time"
)

// TestSkipEmptyTables tests the --skip-empty-tables flag for restore and restore_remote commands
// https://github.com/Altinity/clickhouse-backup/issues/1265
func TestSkipEmptyTables(t *testing.T) {
	env, r := NewTestEnvironment(t)
	defer env.Cleanup(t, r)
	env.connectWithWait(t, r, 0*time.Second, 1*time.Second, 1*time.Minute)

	// Clean up any leftover state from previous failed runs
	_ = env.dropDatabase("test_skip_empty", true)

	// Create test database with tables - one with data and one empty
	env.queryWithNoError(t, r, "CREATE DATABASE IF NOT EXISTS test_skip_empty")
	env.queryWithNoError(t, r, "CREATE TABLE IF NOT EXISTS test_skip_empty.table_with_data (id UInt64) ENGINE=MergeTree() ORDER BY id")
	env.queryWithNoError(t, r, "CREATE TABLE IF NOT EXISTS test_skip_empty.empty_table (id UInt64) ENGINE=MergeTree() ORDER BY id")
	env.queryWithNoError(t, r, "INSERT INTO test_skip_empty.table_with_data SELECT number FROM numbers(100)")

	// Create backup
	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "create", "test_skip_empty_backup")
	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "upload", "test_skip_empty_backup")

	// Drop tables
	r.NoError(env.dropDatabase("test_skip_empty", false))
	// Wait for all ON CLUSTER DDL tasks to finish before recreating the database,
	// to prevent stale CREATE TABLE tasks from replaying when the DB is recreated.
	// Break immediately on error (table may not exist on older ClickHouse versions).
	for attempt := 0; attempt < 30; attempt++ {
		var pendingDDL uint64
		if err := env.ch.SelectSingleRowNoCtx(&pendingDDL, "SELECT count() FROM system.distributed_ddl_queue WHERE status!='Finished'"); err != nil || pendingDDL == 0 {
			break
		}
		time.Sleep(500 * time.Millisecond)
	}

	// Test restore without --skip-empty-tables (should restore both tables)
	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "restore", "--rm", "test_skip_empty_backup")

	tables := make([]struct {
		Name string `ch:"name"`
	}, 0)
	r.NoError(env.ch.Select(&tables, "SELECT name FROM system.tables WHERE database='test_skip_empty' ORDER BY name"))
	tableNames := make([]string, 0, len(tables))
	for _, t := range tables {
		tableNames = append(tableNames, t.Name)
	}
	r.Equal([]string{"empty_table", "table_with_data"}, tableNames, "Both tables should be restored without --skip-empty-tables")

	// Verify data in table_with_data
	var dataCount uint64
	r.NoError(env.ch.SelectSingleRowNoCtx(&dataCount, "SELECT count() FROM test_skip_empty.table_with_data"))
	r.Equal(uint64(100), dataCount, "table_with_data should have 100 rows")

	// Verify empty_table is empty
	var emptyCount uint64
	r.NoError(env.ch.SelectSingleRowNoCtx(&emptyCount, "SELECT count() FROM test_skip_empty.empty_table"))
	r.Equal(uint64(0), emptyCount, "empty_table should have 0 rows")

	// Drop tables and test with --skip-empty-tables
	r.NoError(env.dropDatabase("test_skip_empty", false))
	// Wait for all ON CLUSTER DDL tasks to finish before recreating the database,
	// to prevent stale CREATE TABLE tasks from replaying when the DB is recreated.
	// Break immediately on error (table may not exist on older ClickHouse versions).
	for attempt := 0; attempt < 30; attempt++ {
		var pendingDDL uint64
		if err := env.ch.SelectSingleRowNoCtx(&pendingDDL, "SELECT count() FROM system.distributed_ddl_queue WHERE status!='Finished'"); err != nil || pendingDDL == 0 {
			break
		}
		time.Sleep(500 * time.Millisecond)
	}

	// Test restore with --skip-empty-tables (should skip empty_table completely - both schema and data)
	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "restore", "--rm", "--skip-empty-tables", "test_skip_empty_backup")

	tables = make([]struct {
		Name string `ch:"name"`
	}, 0)
	r.NoError(env.ch.Select(&tables, "SELECT name FROM system.tables WHERE database='test_skip_empty' ORDER BY name"))
	tableNames = make([]string, 0, len(tables))
	for _, t := range tables {
		tableNames = append(tableNames, t.Name)
	}
	r.Equal([]string{"table_with_data"}, tableNames, "Only table_with_data should be created with --skip-empty-tables")

	// Verify data in table_with_data
	r.NoError(env.ch.SelectSingleRowNoCtx(&dataCount, "SELECT count() FROM test_skip_empty.table_with_data"))
	r.Equal(uint64(100), dataCount, "table_with_data should have 100 rows with --skip-empty-tables")

	// Test restore_remote with --skip-empty-tables
	r.NoError(env.dropDatabase("test_skip_empty", false))
	// Wait for all ON CLUSTER DDL tasks to finish before recreating the database,
	// to prevent stale CREATE TABLE tasks from replaying when the DB is recreated.
	// Break immediately on error (table may not exist on older ClickHouse versions).
	for attempt := 0; attempt < 30; attempt++ {
		var pendingDDL uint64
		if err := env.ch.SelectSingleRowNoCtx(&pendingDDL, "SELECT count() FROM system.distributed_ddl_queue WHERE status!='Finished'"); err != nil || pendingDDL == 0 {
			break
		}
		time.Sleep(500 * time.Millisecond)
	}
	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "delete", "local", "test_skip_empty_backup")

	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "restore_remote", "--rm", "--skip-empty-tables", "test_skip_empty_backup")

	tables = make([]struct {
		Name string `ch:"name"`
	}, 0)
	r.NoError(env.ch.Select(&tables, "SELECT name FROM system.tables WHERE database='test_skip_empty' ORDER BY name"))
	tableNames = make([]string, 0, len(tables))
	for _, t := range tables {
		tableNames = append(tableNames, t.Name)
	}
	r.Equal([]string{"table_with_data"}, tableNames, "Only table_with_data should be created with restore_remote --skip-empty-tables")

	// Verify data in table_with_data
	r.NoError(env.ch.SelectSingleRowNoCtx(&dataCount, "SELECT count() FROM test_skip_empty.table_with_data"))
	r.Equal(uint64(100), dataCount, "table_with_data should have 100 rows with restore_remote --skip-empty-tables")

	// Clean up
	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "delete", "local", "test_skip_empty_backup")
	env.DockerExecNoError(r, "clickhouse-backup", "clickhouse-backup", "-c", "/etc/clickhouse-backup/config-s3.yml", "delete", "remote", "test_skip_empty_backup")
	r.NoError(env.dropDatabase("test_skip_empty", false))
}
